package com.robertsworks.robertsbuildingpack.gui;

import com.google.common.collect.Lists;
import com.robertsworks.robertsbuildingpack.block.woodworkingBench.WoodworkingBench;
import com.robertsworks.robertsbuildingpack.block.woodworkingBench.WoodworkingBenchBlockEntity;
import com.robertsworks.robertsbuildingpack.init.ModBlocks;
import com.robertsworks.robertsbuildingpack.init.ModMenus;
import com.robertsworks.robertsbuildingpack.recipe.WoodworkingBenchRecipe;
import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import com.robertsworks.robertsbuildingpack.util.enums.DeskPart;
import com.robertsworks.robertsbuildingpack.util.other.IngredientWithCount;
import com.robertsworks.robertsbuildingpack.util.properties.RBPProperties;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.items.ItemStackHandler;
import net.neoforged.neoforge.items.SlotItemHandler;

public class WoodworkingBenchMenu extends AbstractContainerMenu {
   private final Level level;
   private final BlockPos blockPos;
   private WoodworkingBenchBlockEntity blockEntity;
   private List<WoodworkingBenchRecipe> recipes = Lists.newArrayList();
   private WoodworkingBenchRecipe currentRecipe = null;
   private List<IngredientWithCount> ingredientWithCounts = Lists.newArrayList();
   long lastSoundTime;
   private ItemStackHandler resultItemHandler = null;
   private SlotItemHandler resultSlotHandler = null;

   public WoodworkingBenchMenu(int id, Inventory playerInventory, final Level level, BlockPos pos) {
      super((MenuType)ModMenus.WOODWORKING_BENCH.get(), id);
      this.level = level;
      BlockState state = level.getBlockState(pos);
      if (state.getValue(RBPProperties.DESKPART) == DeskPart.RIGHT) {
         pos = WoodworkingBench.getNeighbourPos(state, pos);
      }

      this.blockPos = pos;
      this.blockEntity = (WoodworkingBenchBlockEntity)level.getBlockEntity(pos);
      this.recipes = RBPHelper.getAllWoodworkingBenchRecipes(level.getRecipeManager());
      this.resultItemHandler = new ItemStackHandler(1);
      this.resultSlotHandler = new SlotItemHandler(this.resultItemHandler, 0, 134, 64) {
         public boolean mayPlace(ItemStack stack) {
            return false;
         }

         public boolean mayPickup(Player player) {
            return WoodworkingBenchMenu.this.isAllIngredientEnough();
         }

         public void onTake(Player player, ItemStack stack) {
            List<IngredientWithCount> ingredientWithCountss = WoodworkingBenchMenu.this.getIngredients();

            for (int i = 0; i < WoodworkingBenchMenu.this.ingredientWithCounts.size(); i++) {
               IngredientWithCount ingredientWithCount = ingredientWithCountss.get(i);
               WoodworkingBenchMenu.this.blockEntity.consumeIngredient(ingredientWithCount);
            }

            this.set(WoodworkingBenchMenu.this.currentRecipe.assemble());
            long l = level.getGameTime();
            if (WoodworkingBenchMenu.this.lastSoundTime != l) {
               level.playSound((Player)null, WoodworkingBenchMenu.this.blockPos, SoundEvents.UI_STONECUTTER_SELECT_RECIPE, SoundSource.BLOCKS, 1.0F, 1.0F);
               WoodworkingBenchMenu.this.lastSoundTime = l;
            }
         }
      };
      this.addSlot(this.resultSlotHandler);

      for (int i = 0; i < 9; i++) {
         this.addSlot(new Slot(this.blockEntity, i, 8 + i * 18, 86));
      }

      for (int i = 0; i < 3; i++) {
         for (int j = 0; j < 9; j++) {
            this.addSlot(new Slot(playerInventory, 9 + j + i * 9, 8 + j * 18, 108 + i * 18));
         }
      }

      for (int k = 0; k < 9; k++) {
         this.addSlot(new Slot(playerInventory, k, 8 + k * 18, 166));
      }

      this.setSelectedRecipeIndex(this.getSelectedRecipeIndex());
   }

   public int getSelectedRecipeIndex() {
      return this.blockEntity.getSelectedIndex();
   }

   public void setSelectedRecipeIndex(int value) {
      this.blockEntity.setSelectedIndex(value);
      this.currentRecipe = this.recipes.get(value);
      this.ingredientWithCounts = this.currentRecipe.getIngredientWithCounts();
      this.resultSlotHandler.set(this.currentRecipe.assemble());
   }

   public List<WoodworkingBenchRecipe> getRecipes() {
      return this.recipes;
   }

   public List<IngredientWithCount> getIngredients() {
      return this.ingredientWithCounts;
   }

   public boolean IsIngredientEnough(IngredientWithCount ingredient) {
      return this.blockEntity.hasEnoughIngredient(ingredient);
   }

   public boolean isAllIngredientEnough() {
      List<IngredientWithCount> ingredientWithCountss = this.getIngredients();

      for (int i = 0; i < this.ingredientWithCounts.size(); i++) {
         IngredientWithCount ingredientWithCount = ingredientWithCountss.get(i);
         if (!this.blockEntity.hasEnoughIngredient(ingredientWithCount)) {
            return false;
         }
      }

      return true;
   }

   public boolean isValidRecipeIndex(int index) {
      return index >= 0 && index < this.recipes.size();
   }

   public MenuType<?> getType() {
      return (MenuType<?>)ModMenus.WOODWORKING_BENCH.get();
   }

   public boolean canTakeItemForPickAll(ItemStack stack, Slot slot) {
      return slot.container != this.resultSlotHandler && super.canTakeItemForPickAll(stack, slot);
   }

   public boolean clickMenuButton(Player player, int index) {
      if (this.isValidRecipeIndex(index)) {
         this.setSelectedRecipeIndex(index);
      }

      return true;
   }

   public boolean stillValid(Player player) {
      return stillValid(ContainerLevelAccess.create(this.level, this.blockPos), player, (Block)ModBlocks.SIMPLE_WOODWORKING_BENCH.get());
   }

   public ItemStack quickMoveStack(Player player, int index) {
      ItemStack itemstack = ItemStack.EMPTY;
      Slot slot = (Slot)this.slots.get(index);
      if (slot != null && slot.hasItem()) {
         ItemStack itemstack1 = slot.getItem();
         itemstack = itemstack1.copy();
         if (index == 0) {
            if (!this.isAllIngredientEnough()) {
               return ItemStack.EMPTY;
            }

            if (!this.moveItemStackTo(itemstack1, 1, 45, true)) {
               return ItemStack.EMPTY;
            }
         } else if (index >= 1 && index <= 9) {
            if (!this.moveItemStackTo(itemstack1, 10, 45, false)) {
               return ItemStack.EMPTY;
            }
         } else if (index >= 10 && index <= 36) {
            if (!this.moveItemStackTo(itemstack1, 1, 9, false)) {
               return ItemStack.EMPTY;
            }
         } else if (index >= 37 && index <= 45 && !this.moveItemStackTo(itemstack1, 1, 9, false)) {
            return ItemStack.EMPTY;
         }

         if (itemstack1.isEmpty()) {
            slot.setByPlayer(ItemStack.EMPTY);
         }

         slot.setChanged();
         if (itemstack1.getCount() == itemstack.getCount()) {
            return ItemStack.EMPTY;
         }

         slot.onTake(player, itemstack1);
         this.broadcastChanges();
      }

      return itemstack;
   }
}
