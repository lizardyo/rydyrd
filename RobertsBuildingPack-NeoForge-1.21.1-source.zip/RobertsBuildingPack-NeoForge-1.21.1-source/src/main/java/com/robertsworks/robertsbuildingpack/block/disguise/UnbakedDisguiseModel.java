package com.robertsworks.robertsbuildingpack.block.disguise;

import com.robertsworks.robertsbuildingpack.block.disguise.bakedModels.BakedDisguiseBlockModel;
import com.robertsworks.robertsbuildingpack.block.disguise.bakedModels.BakedDisguiseCubeModel;
import java.util.function.Function;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.Material;
import net.minecraft.client.resources.model.ModelBaker;
import net.minecraft.client.resources.model.ModelState;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.client.model.geometry.IGeometryBakingContext;
import net.neoforged.neoforge.client.model.geometry.IUnbakedGeometry;

public class UnbakedDisguiseModel implements IUnbakedGeometry<UnbakedDisguiseModel> {
   private String shape = null;

   public UnbakedDisguiseModel(String shape) {
      this.shape = shape;
   }

   @Override
   public BakedModel bake(
      IGeometryBakingContext context,
      ModelBaker baker,
      Function<Material, TextureAtlasSprite> spriteGetter,
      ModelState transform,
      ItemOverrides overrides
   ) {
      return (BakedModel)(this.shape.equals("disguise_block") ? new BakedDisguiseCubeModel() : new BakedDisguiseBlockModel(this.shape));
   }
}
