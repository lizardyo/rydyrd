package com.robertsworks.robertsbuildingpack.block.disguise.bakedModels;

import com.robertsworks.robertsbuildingpack.block.disguise.DisguiseBlockEntity;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.client.ChunkRenderTypeSet;
import net.neoforged.neoforge.client.model.data.ModelData;

public abstract class AbstractBakedDisguiseBlockModel implements BakedModel {
   private final BlockColors blockColors = Minecraft.getInstance().getBlockColors();

   public boolean useAmbientOcclusion() {
      return true;
   }

   public boolean isGui3d() {
      return false;
   }

   public boolean usesBlockLight() {
      return true;
   }

   public boolean isCustomRenderer() {
      return true;
   }

   public TextureAtlasSprite getParticleIcon() {
      return this.getParticleIcon(ModelData.EMPTY);
   }

   public TextureAtlasSprite getParticleIcon(ModelData data) {
      return (TextureAtlasSprite)Minecraft.getInstance()
         .getTextureAtlas(InventoryMenu.BLOCK_ATLAS)
         .apply(ResourceLocation.parse("roberts_building_pack:block/disguise_block_16_16_normal"));
   }

   public ItemOverrides getOverrides() {
      return ItemOverrides.EMPTY;
   }

   public ChunkRenderTypeSet getRenderTypes(BlockState state, RandomSource rand, ModelData data) {
      BlockState disguiseState = (BlockState)data.get(DisguiseBlockEntity.DISGUISE_STATE);
      return DisguiseBlockEntity.isDisguised(disguiseState)
         ? ChunkRenderTypeSet.of(new RenderType[]{ItemBlockRenderTypes.getChunkRenderType(disguiseState)})
         : ChunkRenderTypeSet.of(new RenderType[]{RenderType.cutoutMipped()});
   }

   public List<RenderType> getRenderTypes(ItemStack itemStack, boolean fabulous) {
      return Collections.singletonList(RenderType.cutoutMipped());
   }

   public List<BakedQuad> getQuads(BlockState state, Direction side, RandomSource rand, ModelData data, RenderType renderType) {
      return this.onGetQuads(state, side, rand, data, renderType);
   }

   public List<BakedQuad> getQuads(BlockState state, Direction side, RandomSource rand) {
      return this.getQuads(state, side, rand, ModelData.EMPTY, RenderType.cutoutMipped());
   }

   public abstract List<BakedQuad> onGetQuads(BlockState var1, Direction var2, RandomSource var3, ModelData var4, RenderType var5);

   public List<BakedQuad> getModelQuads(BlockState state, Direction side, RandomSource rand, ModelData data, RenderType renderType) {
      BakedModel targetModel = Minecraft.getInstance().getBlockRenderer().getBlockModel(state);
      return targetModel.getQuads(state, side, rand, data, renderType);
   }
}
