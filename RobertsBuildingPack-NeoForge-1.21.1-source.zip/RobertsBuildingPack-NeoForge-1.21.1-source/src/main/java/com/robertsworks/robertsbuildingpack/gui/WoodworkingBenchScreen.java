package com.robertsworks.robertsbuildingpack.gui;

import com.robertsworks.robertsbuildingpack.recipe.WoodworkingBenchRecipe;
import com.robertsworks.robertsbuildingpack.util.other.IngredientWithCount;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

public class WoodworkingBenchScreen extends AbstractContainerScreen<WoodworkingBenchMenu> {
   private static final ResourceLocation BG_LOCATION = ResourceLocation.fromNamespaceAndPath("roberts_building_pack", "textures/gui/woodworking_bench.png");
   private static final int SCROLLER_WIDTH = 8;
   private static final int SCROLLER_HEIGHT = 15;
   private static final int RECIPES_COLUMNS = 5;
   private static final int RECIPES_ROWS = 4;
   private static final int ITEM_BG_WIDTH = 18;
   private static final int ITEM_BG_HEIGHT = 18;
   private static final int SCROLLER_FULL_HEIGHT = 54;
   private static final int RECIPES_X = 8;
   private static final int RECIPES_Y = 7;
   private static final int INGREDIENTS_X = 116;
   private static final int INGREDIENTS_Y = 8;
   private float scrollOffs;
   private boolean scrolling;
   private int startIndex;

   public WoodworkingBenchScreen(WoodworkingBenchMenu menu, Inventory playerInventory, Component title) {
      super(menu, playerInventory, title);
      this.imageHeight = 190;
   }

   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
      super.render(graphics, mouseX, mouseY, partialTick);
      this.renderTooltip(graphics, mouseX, mouseY);
   }

   protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
   }

   protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
      int x = this.leftPos;
      int y = this.topPos;
      graphics.blit(BG_LOCATION, x, y, 0, 0, this.imageWidth, this.imageHeight);
      int k = (int)(41.0F * this.scrollOffs);
      graphics.blit(BG_LOCATION, x + 100, y + 8 + k, 176 + (this.isScrollBarActive() ? 0 : 8), 0, 8, 15);
      this.renderListItemBg(graphics, mouseX, mouseY);
      this.renderListItems(graphics, mouseX, mouseY);
      this.renderIngredients(graphics);
   }

   private void renderListItemBg(GuiGraphics graphics, int mouseX, int mouseY) {
      int count = ((WoodworkingBenchMenu)this.menu).getRecipes().size();
      int limit = this.startIndex + 20;
      int selectedRecipeIndex = ((WoodworkingBenchMenu)this.menu).getSelectedRecipeIndex();

      for (int i = this.startIndex; i < limit && i < count; i++) {
         int j = i - this.startIndex;
         int x = this.leftPos + 8 + j % 5 * 18;
         int y = this.topPos + 7 + 2 + j / 5 * 18;
         int j1 = 0;
         if (i == selectedRecipeIndex) {
            j1 += 18;
         } else if (mouseX >= x && mouseY >= y && mouseX < x + 18 && mouseY < y + 18) {
            j1 += 36;
         }

         graphics.blit(BG_LOCATION, x, y - 1, this.imageWidth + 16, j1, 18, 18);
      }
   }

   private void renderListItems(GuiGraphics graphics, int mouseX, int mouseY) {
      List<WoodworkingBenchRecipe> list = ((WoodworkingBenchMenu)this.menu).getRecipes();
      int count = list.size();
      int limit = this.startIndex + 20;
      RegistryAccess registryAccess = this.minecraft.level.registryAccess();

      for (int i = this.startIndex; i < limit && i < count; i++) {
         WoodworkingBenchRecipe recipe = list.get(i);
         ItemStack resultItem = recipe.getResultItem(registryAccess);
         int j = i - this.startIndex;
         int x = this.leftPos + 8 + j % 5 * 18;
         int y = this.topPos + 7 + 2 + j / 5 * 18;
         graphics.renderItem(resultItem, x + 1, y);
      }
   }

   private void renderIngredients(GuiGraphics graphics) {
      List<IngredientWithCount> ingredientWithCounts = ((WoodworkingBenchMenu)this.menu).getIngredients();
      int count = ingredientWithCounts.size();

      for (int row = 0; row < 2; row++) {
         for (int column = 0; column < 3; column++) {
            int index = row * 3 + column;
            if (index >= count) {
               break;
            }

            IngredientWithCount ingredient = ingredientWithCounts.get(index);
            ItemStack item = ingredient.ingredient().getItems()[0];
            int x = this.leftPos + 116 + column * 18;
            int y = this.topPos + 8 + row * (18 + 9);
            graphics.renderItem(item, x, y);
            String label = "x" + ingredient.count();
            int labelX = x + (18 - this.font.width(label)) / 2;
            int labelY = y + 18 - 1;
            int color = ((WoodworkingBenchMenu)this.menu).IsIngredientEnough(ingredient) ? 16777215 : 16729156;
            graphics.drawString(this.font, label, labelX, labelY, color);
         }
      }
   }

   protected void renderTooltip(GuiGraphics graphics, int mouseX, int mouseY) {
      super.renderTooltip(graphics, mouseX, mouseY);
      List<WoodworkingBenchRecipe> list = ((WoodworkingBenchMenu)this.menu).getRecipes();
      int count = list.size();
      int limit = this.startIndex + 20;

      for (int i = this.startIndex; i < limit && i < count; i++) {
         int j = i - this.startIndex;
         int x = this.leftPos + 8 + j % 5 * 18;
         int y = this.topPos + 7 + 2 + j / 5 * 18;
         if (mouseX >= x && mouseX < x + 18 && mouseY >= y && mouseY < y + 18) {
            graphics.renderItemDecorations(this.font, list.get(i).getResult(), mouseX, mouseY);
         }
      }

      List<IngredientWithCount> ingredientWithCountss = ((WoodworkingBenchMenu)this.menu).getIngredients();
      count = ingredientWithCountss.size();

      for (int row = 0; row < 2; row++) {
         for (int column = 0; column < 3; column++) {
            int index = row * 3 + column;
            if (index >= count) {
               break;
            }

            IngredientWithCount ingredient = ingredientWithCountss.get(index);
            ItemStack item = ingredient.ingredient().getItems()[0];
            int x = this.leftPos + 116 + column * 18;
            int y = this.topPos + 8 + row * (18 + 9);
            if (mouseX >= x && mouseX < x + 18 && mouseY >= y && mouseY < y + 18) {
               graphics.renderItemDecorations(this.font, item, mouseX, mouseY);
            }
         }
      }
   }

   public boolean mouseClicked(double mouseX, double mouseY, int button) {
      this.scrolling = false;
      int x = this.leftPos + 8;
      int y = this.topPos + 7;
      int limit = this.startIndex + 20;

      for (int i = this.startIndex; i < limit; i++) {
         int i1 = i - this.startIndex;
         double d0 = mouseX - (double)(x + i1 % 5 * 18);
         double d1 = mouseY - (double)(y + i1 / 5 * 18);
         if (d0 >= 0.0 && d1 >= 0.0 && d0 < 18.0 && d1 < 18.0 && ((WoodworkingBenchMenu)this.menu).clickMenuButton(this.minecraft.player, i)) {
            Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_STONECUTTER_TAKE_RESULT, 1.0F));
            this.minecraft.gameMode.handleInventoryButtonClick(((WoodworkingBenchMenu)this.menu).containerId, i);
            return true;
         }
      }

      x = this.leftPos + 75;
      y = this.topPos + 9;
      if (mouseX >= (double)x && mouseX < (double)(x + 8) && mouseY >= (double)y && mouseY < (double)(y + 54)) {
         this.scrolling = true;
      }

      return super.mouseClicked(mouseX, mouseY, button);
   }

   public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
      if (this.scrolling && this.isScrollBarActive()) {
         int i = this.topPos + 7;
         int j = i + 54;
         this.scrollOffs = ((float)mouseY - (float)i - 7.5F) / ((float)(j - i) - 15.0F);
         this.scrollOffs = Mth.clamp(this.scrollOffs, 0.0F, 1.0F);
         this.startIndex = (int)((double)(this.scrollOffs * (float)this.getOffscreenRows()) + 0.5) * 5;
         return true;
      } else {
         return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
      }
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
      if (this.isScrollBarActive()) {
         int i = this.getOffscreenRows();
         float f = (float)scrollY / (float)i;
         this.scrollOffs = Mth.clamp(this.scrollOffs - f, 0.0F, 1.0F);
         this.startIndex = (int)((double)(this.scrollOffs * (float)i) + 0.5) * 5;
      }

      return true;
   }

   private boolean isScrollBarActive() {
      return ((WoodworkingBenchMenu)this.menu).getRecipes().size() > 20;
   }

   protected int getOffscreenRows() {
      return (((WoodworkingBenchMenu)this.menu).getRecipes().size() + 5 - 1) / 5 - 4;
   }
}
