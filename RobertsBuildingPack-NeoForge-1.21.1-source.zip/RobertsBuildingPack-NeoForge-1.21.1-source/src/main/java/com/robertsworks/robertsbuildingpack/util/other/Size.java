package com.robertsworks.robertsbuildingpack.util.other;

public record Size(float width, float height) {
}
