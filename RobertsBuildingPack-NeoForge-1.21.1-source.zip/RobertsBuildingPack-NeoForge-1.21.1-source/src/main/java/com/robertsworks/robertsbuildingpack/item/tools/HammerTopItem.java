package com.robertsworks.robertsbuildingpack.item.tools;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item.Properties;

public class HammerTopItem extends Item {
   public HammerTopItem() {
      super(new Properties().stacksTo(64).rarity(Rarity.COMMON));
   }
}
