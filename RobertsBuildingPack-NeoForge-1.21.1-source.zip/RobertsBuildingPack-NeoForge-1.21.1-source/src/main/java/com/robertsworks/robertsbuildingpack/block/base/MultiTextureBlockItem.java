package com.robertsworks.robertsbuildingpack.block.base;

import com.robertsworks.robertsbuildingpack.init.ModDataComponents;
import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

public abstract class MultiTextureBlockItem extends BlockItem {
   public static final String PLACEMENT_MODE = "placement_mode";
   private final int textureCount;

   public MultiTextureBlockItem(Block block, Properties properties, int textureCount) {
      super(block, properties);
      this.textureCount = textureCount;
   }

   public abstract int getDefaultPlacementMode();

   public abstract int getNextPlacementMode(int var1);

   public abstract int getTextureForPlacement(ItemStack var1, BlockPos var2, RandomSource var3, Direction var4);

   public abstract Component getPlacementModeName(int var1);

   public abstract Component getPlacementModeDesciption(int var1);

   public int getTextureCount() {
      return this.textureCount;
   }

   public static int getPlacementMode(ItemStack stack) {
      return stack.getOrDefault(ModDataComponents.PLACEMENT_MODE.get(), 0);
   }

   public static void setPlacementMode(ItemStack stack, int mode) {
      stack.set(ModDataComponents.PLACEMENT_MODE.get(), mode);
   }

   @Override
   public ItemStack getDefaultInstance() {
      ItemStack stack = super.getDefaultInstance();
      setPlacementMode(stack, 0);
      return stack;
   }

   public Component getName(ItemStack stack) {
      int mode = getPlacementMode(stack);
      return (Component)(!RBPHelper.isShiftKeyDown()
         ? Component.translatable(
            "%s [%s]", new Object[]{Component.translatable(this.getDescriptionId(stack)).withStyle(ChatFormatting.WHITE), this.getPlacementModeName(mode)}
         )
         : super.getName(stack));
   }

   public void appendHoverText(ItemStack stack, net.minecraft.world.item.Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
      super.appendHoverText(stack, context, tooltip, flag);
      tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.texture_count", new Object[]{this.textureCount}).withStyle(ChatFormatting.GREEN));
      tooltip.add(Component.literal(" "));
      if (!RBPHelper.isShiftKeyDown()) {
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.show_more_info").withStyle(ChatFormatting.GRAY));
      } else {
         int mode = getPlacementMode(stack);
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.placement_mode_current").withStyle(ChatFormatting.GRAY));
         tooltip.add(Component.translatable("[%s]", new Object[]{this.getPlacementModeName(mode)}));
         tooltip.add(this.getPlacementModeDesciption(mode));
         tooltip.add(Component.literal(" "));
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.interaction_methods").withStyle(ChatFormatting.GRAY));
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.multi_texture_block_item_interaction_1").withStyle(ChatFormatting.WHITE));
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.multi_texture_block_item_interaction_2").withStyle(ChatFormatting.WHITE));
         tooltip.add(Component.literal(" "));
      }
   }

   public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
      if (!level.isClientSide && hand == InteractionHand.MAIN_HAND) {
         ItemStack stack = player.getItemInHand(hand);
         int newMode = this.getNextPlacementMode(getPlacementMode(stack));
         setPlacementMode(stack, newMode);
      }

      return super.use(level, player, hand);
   }
}
