package com.robertsworks.robertsbuildingpack.item.tools;

import java.util.List;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.Item.Properties;

public class PlanerItem extends AbstractBuildingTool {
   public static float DURABILITY_RATE = 1.0F;

   public PlanerItem(Tier tier, float damage, float attackSpeed) {
      super(tier, DURABILITY_RATE, damage, attackSpeed, new Properties());
   }

}
