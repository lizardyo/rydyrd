package com.robertsworks.robertsbuildingpack.init;

import com.robertsworks.robertsbuildingpack.block.disguise.DisguiseBlockEntity;
import com.robertsworks.robertsbuildingpack.block.woodworkingBench.WoodworkingBenchBlockEntity;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlockEntities {
   // NOTE: the namespace "yourmodid" is intentionally kept from the original 1.20.1 mod so that
   // block entity ids stay identical to the original release.
   public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, "yourmodid");

   public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<DisguiseBlockEntity>> DISGUISE_BLOCK_ENTITY = REGISTRY.register(
      "disguise_block",
      () -> BlockEntityType.Builder.of(
               DisguiseBlockEntity::new,
               new Block[]{
                  ModBlocks.DISGUISE_BLOCK.get(),
                  ModBlocks.DISGUISE_STAIR.get(),
                  ModBlocks.DISGUISE_HORIZONTAL_HALF_SLAB.get(),
                  ModBlocks.DISGUISE_VERTICAL_HALF_SLAB.get(),
                  ModBlocks.DISGUISE_HORIZONTAL_QUARTER_SLAB.get(),
                  ModBlocks.DISGUISE_VERTICAL_QUARTER_SLAB.get(),
                  ModBlocks.DISGUISE_HORIZONTAL_ONE_EIGHTH_SLAB.get(),
                  ModBlocks.DISGUISE_VERTICAL_ONE_EIGHTH_SLAB.get(),
                  ModBlocks.DISGUISE_HORIZONTAL_ONE_SIXTEENTH_SLAB.get(),
                  ModBlocks.DISGUISE_VERTICAL_ONE_SIXTEENTH_SLAB.get()
               }
            )
            .build(null)
   );

   public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<WoodworkingBenchBlockEntity>> WOODWORKING_BENCH_BLOCK_ENTITY = REGISTRY.register(
      "woodworking_bench",
      () -> BlockEntityType.Builder.of(WoodworkingBenchBlockEntity::new, new Block[]{ModBlocks.SIMPLE_WOODWORKING_BENCH.get()}).build(null)
   );
}
