package com.robertsworks.robertsbuildingpack.block.woodworkingBench;

import com.robertsworks.robertsbuildingpack.gui.WoodworkingBenchMenu;
import com.robertsworks.robertsbuildingpack.init.ModBlockEntities;
import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import com.robertsworks.robertsbuildingpack.util.enums.DeskPart;
import com.robertsworks.robertsbuildingpack.util.other.IngredientWithCount;
import com.robertsworks.robertsbuildingpack.util.properties.RBPProperties;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.items.IItemHandlerModifiable;
import net.neoforged.neoforge.items.wrapper.InvWrapper;

public class WoodworkingBenchBlockEntity extends BaseContainerBlockEntity {
   private static int STORAGESIZE = 9;
   public static String TAG_SELECTEDINDEX = "RBP_WBBE_SELECTEDINDEX";
   public static String TAG_ITEMS = "RBP_WBBE_ITEMS";
   private int selectedIndex = 0;
   private NonNullList<ItemStack> items = NonNullList.withSize(9, ItemStack.EMPTY);

   public WoodworkingBenchBlockEntity(BlockPos pos, BlockState state) {
      super(ModBlockEntities.WOODWORKING_BENCH_BLOCK_ENTITY.get(), pos, state);
   }

   @Override
   protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
      super.saveAdditional(tag, registries);
      tag.putInt(TAG_SELECTEDINDEX, this.selectedIndex);
      ContainerHelper.saveAllItems(tag, this.items, registries);
   }

   @Override
   protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
      super.loadAdditional(tag, registries);
      if (tag.contains(TAG_SELECTEDINDEX)) {
         this.selectedIndex = tag.getInt(TAG_SELECTEDINDEX);
      }
      this.items = NonNullList.withSize(this.getContainerSize(), ItemStack.EMPTY);
      ContainerHelper.loadAllItems(tag, this.items, registries);
   }

   /** Copies the stored items of another bench half into this one. */
   public void loadFromAnother(WoodworkingBenchBlockEntity another) {
      this.items = NonNullList.withSize(this.getContainerSize(), ItemStack.EMPTY);
      for (int i = 0; i < this.items.size() && i < another.items.size(); i++) {
         this.items.set(i, another.items.get(i).copy());
      }
      this.setChanged();
   }

   /** Exposes the bench inventory (of the main half) to hoppers and other item handlers. */
   public IItemHandlerModifiable getItemHandler() {
      BlockState state = this.getBlockState();
      BlockPos pos = this.getBlockPos();
      DeskPart part = state.getValue(RBPProperties.DESKPART);
      if (part == DeskPart.LEFT || this.level == null) {
         return new InvWrapper(this);
      } else {
         BlockPos npos = WoodworkingBench.getNeighbourPos(state, pos);
         if (this.level.getBlockEntity(npos) instanceof WoodworkingBenchBlockEntity ne) {
            return new InvWrapper(ne);
         }
         return new InvWrapper(this);
      }
   }

   @Override
   public NonNullList<ItemStack> getItems() {
      return this.items;
   }

   @Override
   protected void setItems(NonNullList<ItemStack> items) {
      this.items = items;
   }

   public int getSelectedIndex() {
      return this.selectedIndex;
   }

   public void setSelectedIndex(int value) {
      this.selectedIndex = value;
      this.setChanged();
   }

   /** Stores the bench contents on the item (replaces the old NBT tag RBP_WBBE_ITEMS). */
   public void saveItemsToStack(ItemStack stack) {
      if (RBPHelper.hasItem(this.getItems())) {
         stack.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(this.getItems()));
      }
   }

   public WoodworkingBenchBlockEntity getMainBlockEntity() {
      BlockPos pos = this.getBlockPos();
      BlockState state = this.getBlockState();
      DeskPart part = state.getValue(RBPProperties.DESKPART);
      if (part == DeskPart.RIGHT) {
         BlockPos npos = WoodworkingBench.getNeighbourPos(state, pos);
         return (WoodworkingBenchBlockEntity)this.level.getBlockEntity(npos);
      } else {
         return this;
      }
   }

   public boolean hasEnoughIngredient(IngredientWithCount ingredient) {
      return RBPHelper.hasEnoughIngredient(this.getItems(), ingredient);
   }

   public boolean consumeIngredient(IngredientWithCount ingredient) {
      boolean res = RBPHelper.consumeIngredient(this.getItems(), ingredient);
      this.setChanged();
      return res;
   }

   @Override
   public int getContainerSize() {
      return STORAGESIZE;
   }

   @Override
   public boolean isEmpty() {
      return RBPHelper.hasItem(this.getItems());
   }

   @Override
   public ItemStack getItem(int slot) {
      return this.getItems().get(slot);
   }

   @Override
   public ItemStack removeItem(int slot, int count) {
      ItemStack itemstack = ContainerHelper.removeItem(this.getItems(), slot, count);
      if (!itemstack.isEmpty()) {
         this.setChanged();
      }
      return itemstack;
   }

   @Override
   public ItemStack removeItemNoUpdate(int slot) {
      return ContainerHelper.takeItem(this.getItems(), slot);
   }

   @Override
   public void setItem(int slot, ItemStack stack) {
      this.getItems().set(slot, stack);
      if (stack.getCount() > this.getMaxStackSize()) {
         stack.setCount(this.getMaxStackSize());
      }
      this.setChanged();
   }

   @Override
   public boolean stillValid(Player player) {
      return Container.stillValidBlockEntity(this, player);
   }

   @Override
   public void clearContent() {
      this.getItems().clear();
   }

   @Override
   protected Component getDefaultName() {
      return this.getBlockState().getBlock().getName();
   }

   @Override
   protected AbstractContainerMenu createMenu(int id, Inventory inventory) {
      return new WoodworkingBenchMenu(id, inventory, this.level, this.getBlockPos());
   }
}
