package com.robertsworks.robertsbuildingpack.item.tools;

import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Tier;

/**
 * Base class for the building tools. In 1.20.1 this class contained a hard-coded enchantment whitelist;
 * in 1.21 enchantments are data driven, so the whitelist is now expressed through the item tags in
 * data/minecraft/tags/item/enchantable/.
 */
public abstract class AbstractBuildingTool extends DiggerItem {
   public AbstractBuildingTool(Tier tier, float durabilityRate, float damage, float attackSpeed, Item.Properties properties) {
      super(
         new ScaledTier(tier, durabilityRate),
         BlockTags.MINEABLE_WITH_PICKAXE,
         properties.attributes(DiggerItem.createAttributes(tier, damage, attackSpeed - 4.0F))
      );
   }
}
