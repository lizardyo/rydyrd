package com.robertsworks.robertsbuildingpack.block.paintedWall;

import java.util.Collections;
import java.util.List;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.storage.loot.LootParams.Builder;

public class PaintedWallBlock extends Block {
   public PaintedWallBlock() {
      super(Properties.ofFullCopy(Blocks.STONE));
   }

   public List<ItemStack> getDrops(BlockState state, Builder builder) {
      return Collections.singletonList(new ItemStack(this));
   }
}
