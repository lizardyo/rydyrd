package com.robertsworks.robertsbuildingpack.block.disguise.blocks;

import com.robertsworks.robertsbuildingpack.util.enums.PillarPos;
import com.robertsworks.robertsbuildingpack.util.properties.RBPProperties;
import java.util.Collections;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public abstract class AbstractDisguisePillar extends Block implements IDisguiseBlock, SimpleWaterloggedBlock {
   public AbstractDisguisePillar() {
      super(Properties.ofFullCopy(Blocks.OAK_PLANKS).noOcclusion());
      this.registerDefaultState(
         (BlockState)((BlockState)((BlockState)this.getBaseBlockState(this.stateDefinition).setValue(RBPProperties.FACING, Direction.NORTH))
               .setValue(RBPProperties.PILLAR_POS, PillarPos.CENTER))
            .setValue(RBPProperties.WATERLOGGED, false)
      );
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      super.createBlockStateDefinition(builder);
      this.addDisguiseBlockStateDefinition(builder);
      builder.add(new Property[]{RBPProperties.FACING, RBPProperties.PILLAR_POS, RBPProperties.WATERLOGGED});
   }

   public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
      PillarPos pillarPos = (PillarPos)state.getValue(RBPProperties.PILLAR_POS);
      return this.getPillarShape(pillarPos);
   }

   public BlockState getStateForPlacement(BlockPlaceContext context) {
      Direction direction = context.getClickedFace();
      BlockPos pos = context.getClickedPos();
      Vec3 clickLocation = context.getClickLocation().subtract((double)pos.getX(), (double)pos.getY(), (double)pos.getZ());
      Direction facing = context.getHorizontalDirection();
      FluidState fluidstate = context.getLevel().getFluidState(pos);
      PillarPos side = PillarPos.CENTER;
      if (direction == Direction.UP || direction == Direction.DOWN) {
         side = PillarPos.CENTER;
      } else if (direction == Direction.SOUTH) {
         if (clickLocation.x < 0.5) {
            side = PillarPos.TOP_LEFT;
         } else {
            side = PillarPos.TOP_RIGHT;
         }
      } else if (direction == Direction.NORTH) {
         if (clickLocation.x < 0.5) {
            side = PillarPos.BOTTOM_LEFT;
         } else {
            side = PillarPos.BOTTOM_RIGHT;
         }
      } else if (direction == Direction.WEST) {
         if (clickLocation.z < 0.5) {
            side = PillarPos.TOP_RIGHT;
         } else {
            side = PillarPos.BOTTOM_RIGHT;
         }
      } else if (direction == Direction.EAST) {
         if (clickLocation.z < 0.5) {
            side = PillarPos.TOP_LEFT;
         } else {
            side = PillarPos.BOTTOM_LEFT;
         }
      }

      return (BlockState)((BlockState)((BlockState)this.defaultBlockState().setValue(RBPProperties.FACING, facing)).setValue(RBPProperties.PILLAR_POS, side))
         .setValue(RBPProperties.WATERLOGGED, fluidstate.getType() == Fluids.WATER);
   }

   @Override
   public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
      BlockState result = super.playerWillDestroy(level, pos, state, player);
      this.processPlayerWillDestroy(level, pos, state, player);
      return result;
   }

   public List<ItemStack> getDrops(BlockState state, net.minecraft.world.level.storage.loot.LootParams.Builder params) {
      return Collections.singletonList(new ItemStack(this));
   }

   public FluidState getFluidState(BlockState state) {
      return state.getValue(RBPProperties.WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
   }

   public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
      if ((Boolean)state.getValue(RBPProperties.WATERLOGGED)) {
         level.scheduleTick(pos, Fluids.WATER, Fluids.WATER.getTickDelay(level));
      }

      return super.updateShape(state, direction, neighborState, level, pos, neighborPos);
   }

   public abstract VoxelShape getPillarShape(PillarPos var1);
}
