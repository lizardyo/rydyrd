package com.robertsworks.robertsbuildingpack.recipe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.robertsworks.robertsbuildingpack.util.other.IngredientWithCount;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeSerializer;

public class WoodworkingBenchRecipeSerializer implements RecipeSerializer<WoodworkingBenchRecipe> {
   private static final MapCodec<WoodworkingBenchRecipe> CODEC = RecordCodecBuilder.mapCodec(
      instance -> instance.group(
            ItemStack.CODEC.fieldOf("result").forGetter(WoodworkingBenchRecipe::getResult),
            IngredientWithCount.CODEC.listOf().fieldOf("ingredients").forGetter(WoodworkingBenchRecipe::getIngredientWithCounts),
            Codec.INT.optionalFieldOf("sortIndex", 99999).forGetter(WoodworkingBenchRecipe::getSortIndex)
         )
         .apply(instance, WoodworkingBenchRecipe::new)
   );

   private static final StreamCodec<RegistryFriendlyByteBuf, WoodworkingBenchRecipe> STREAM_CODEC = StreamCodec.composite(
      ItemStack.STREAM_CODEC,
      WoodworkingBenchRecipe::getResult,
      IngredientWithCount.STREAM_CODEC.apply(ByteBufCodecs.list()),
      WoodworkingBenchRecipe::getIngredientWithCounts,
      ByteBufCodecs.VAR_INT,
      WoodworkingBenchRecipe::getSortIndex,
      WoodworkingBenchRecipe::new
   );

   @Override
   public MapCodec<WoodworkingBenchRecipe> codec() {
      return CODEC;
   }

   @Override
   public StreamCodec<RegistryFriendlyByteBuf, WoodworkingBenchRecipe> streamCodec() {
      return STREAM_CODEC;
   }
}
