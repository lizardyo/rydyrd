package com.robertsworks.robertsbuildingpack.block.disguise.blocks;

import com.robertsworks.robertsbuildingpack.util.enums.PillarPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.shapes.VoxelShape;

public class DisguisePillar_4_4_16 extends AbstractDisguisePillar {
   private static VoxelShape SHAPE_CENTER = Block.box(6.0, 0.0, 6.0, 10.0, 16.0, 10.0);
   private static VoxelShape SHAPE_TOP_LEFT = Block.box(0.0, 0.0, 0.0, 4.0, 16.0, 4.0);
   private static VoxelShape SHAPE_TOP_RIGHT = Block.box(12.0, 0.0, 0.0, 16.0, 16.0, 4.0);
   private static VoxelShape SHAPE_BOTTOM_LEFT = Block.box(0.0, 0.0, 12.0, 4.0, 16.0, 16.0);
   private static VoxelShape SHAPE_BOTTOM_RIGHT = Block.box(12.0, 0.0, 12.0, 16.0, 16.0, 16.0);

   @Override
   public VoxelShape getPillarShape(PillarPos pillarPos) {
      return switch (pillarPos) {
         case CENTER -> SHAPE_CENTER;
         case TOP_LEFT -> SHAPE_TOP_LEFT;
         case TOP_RIGHT -> SHAPE_TOP_RIGHT;
         case BOTTOM_LEFT -> SHAPE_BOTTOM_LEFT;
         case BOTTOM_RIGHT -> SHAPE_BOTTOM_RIGHT;
         default -> SHAPE_CENTER;
      };
   }
}
