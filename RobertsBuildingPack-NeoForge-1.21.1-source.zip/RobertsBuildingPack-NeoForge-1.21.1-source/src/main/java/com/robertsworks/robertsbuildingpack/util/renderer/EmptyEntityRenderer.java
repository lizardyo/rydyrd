package com.robertsworks.robertsbuildingpack.util.renderer;

import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;

public class EmptyEntityRenderer<T extends Entity> extends EntityRenderer<T> {
   public EmptyEntityRenderer(Context context) {
      super(context);
   }

   public ResourceLocation getTextureLocation(T entity) {
      return ResourceLocation.parse("textures/block/stone.png");
   }

   public boolean shouldRender(T entity, Frustum frustum, double camX, double camY, double camZ) {
      return false;
   }
}
