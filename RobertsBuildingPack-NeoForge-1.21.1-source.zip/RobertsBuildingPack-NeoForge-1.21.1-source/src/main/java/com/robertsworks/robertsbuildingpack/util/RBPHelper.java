package com.robertsworks.robertsbuildingpack.util;

import com.robertsworks.robertsbuildingpack.block.base.MultiTextureBlockItem;
import com.robertsworks.robertsbuildingpack.init.ModRecipeTypes;
import com.robertsworks.robertsbuildingpack.recipe.WoodworkingBenchRecipe;
import com.robertsworks.robertsbuildingpack.util.other.IngredientWithCount;
import com.robertsworks.robertsbuildingpack.util.other.QuadInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class RBPHelper {
   public static int findMin(int... numbers) {
      if (numbers.length == 0) {
         throw new IllegalArgumentException("\u81f3\u5c11\u9700\u8981\u4f20\u5165\u4e00\u4e2a\u53c2\u6570");
      } else {
         int min = numbers[0];

         for (int num : numbers) {
            if (num < min) {
               min = num;
            }
         }

         return min;
      }
   }

   public static int findMax(int... numbers) {
      if (numbers.length == 0) {
         throw new IllegalArgumentException("\u81f3\u5c11\u9700\u8981\u4f20\u5165\u4e00\u4e2a\u53c2\u6570");
      } else {
         int max = numbers[0];

         for (int num : numbers) {
            if (num > max) {
               max = num;
            }
         }

         return max;
      }
   }

   public static float findMin(float... numbers) {
      if (numbers.length == 0) {
         throw new IllegalArgumentException("\u81f3\u5c11\u9700\u8981\u4f20\u5165\u4e00\u4e2a\u53c2\u6570");
      } else {
         float min = numbers[0];

         for (float num : numbers) {
            if (num < min) {
               min = num;
            }
         }

         return min;
      }
   }

   public static float findMax(float... numbers) {
      if (numbers.length == 0) {
         throw new IllegalArgumentException("\u81f3\u5c11\u9700\u8981\u4f20\u5165\u4e00\u4e2a\u53c2\u6570");
      } else {
         float max = numbers[0];

         for (float num : numbers) {
            if (num > max) {
               max = num;
            }
         }

         return max;
      }
   }

   public static int setMinMax(int value, int min, int max) {
      int res = value;
      if (value > max) {
         res = max;
      }

      if (res < min) {
         res = min;
      }

      return res;
   }

   public static float setMinMax(float value, float min, float max) {
      float res = value;
      if (value > max) {
         res = max;
      }

      if (res < min) {
         res = min;
      }

      return res;
   }

   public static boolean isShiftKeyDown() {
      return Minecraft.getInstance().screen == null ? false : Screen.hasShiftDown();
   }

   public static boolean hasItem(NonNullList<ItemStack> items) {
      for (int i = 0; i < items.size(); i++) {
         ItemStack item = (ItemStack)items.get(i);
         if (!item.isEmpty()) {
            return true;
         }
      }

      return false;
   }

   public static int countItem(NonNullList<ItemStack> items) {
      int count = 0;

      for (int i = 0; i < items.size(); i++) {
         ItemStack item = (ItemStack)items.get(i);
         if (!item.isEmpty()) {
            count++;
         }
      }

      return count;
   }

   public static boolean tryGiveItemToPlayerMainHand(Inventory inventory, ItemStack returnStack) {
      try {
         int selectedIndex = inventory.selected;
         if (selectedIndex < 0) {
            return false;
         } else {
            ItemStack handItem = inventory.getItem(selectedIndex);
            if (handItem.isEmpty()) {
               inventory.setItem(inventory.selected, returnStack);
               return true;
            } else if (ItemStack.isSameItemSameComponents(handItem, returnStack) && handItem.getCount() < handItem.getMaxStackSize()) {
               handItem.grow(1);
               return true;
            } else {
               return false;
            }
         }
      } catch (Exception var4) {
         return false;
      }
   }

   public static boolean tryGiveItemToPlayerHotbar(Inventory inventory, ItemStack returnStack) {
      try {
         int sameItemIndex = -1;
         int emptyIndex = -1;

         for (int i = 0; i < 9; i++) {
            ItemStack stack = inventory.getItem(i);
            if (sameItemIndex < 0 && ItemStack.isSameItemSameComponents(stack, returnStack)) {
               sameItemIndex = i;
            }

            if (emptyIndex < 0 && stack.isEmpty()) {
               emptyIndex = i;
            }
         }

         if (sameItemIndex >= 0) {
            ((ItemStack)inventory.items.get(sameItemIndex)).grow(1);
            return true;
         } else if (emptyIndex >= 0) {
            inventory.setItem(emptyIndex, returnStack);
            return true;
         } else {
            return false;
         }
      } catch (Exception var6) {
         return false;
      }
   }

   public static boolean tryGiveItemToPlayerBackpack(Inventory inventory, ItemStack returnStack) {
      try {
         int sameItemIndex = -1;
         int emptyIndex = -1;

         for (int i = 9; i < inventory.items.size(); i++) {
            ItemStack stack = inventory.getItem(i);
            if (sameItemIndex < 0 && ItemStack.isSameItemSameComponents(stack, returnStack)) {
               sameItemIndex = i;
            }

            if (emptyIndex < 0 && stack.isEmpty()) {
               emptyIndex = i;
            }
         }

         if (sameItemIndex >= 0) {
            ((ItemStack)inventory.items.get(sameItemIndex)).grow(1);
            return true;
         } else if (emptyIndex >= 0) {
            inventory.setItem(emptyIndex, returnStack);
            return true;
         } else {
            return false;
         }
      } catch (Exception var6) {
         return false;
      }
   }

   public static void playBlockSound(Level level, BlockPos pos, SoundEvent soundEvent, float volume, float pitch) {
      level.playSound(null, pos, soundEvent, SoundSource.BLOCKS, volume, pitch);
   }

   public static void getAllBlockPosInChunk(LevelAccessor level, ChunkAccess chunk, Consumer<BlockPos> eachPos) {
      int minY = level.getMinBuildHeight();
      int maxY = level.getMaxBuildHeight();
      ChunkPos chunkPos = chunk.getPos();

      for (int x = 0; x < 16; x++) {
         for (int z = 0; z < 16; z++) {
            for (int y = minY; y < maxY; y++) {
               BlockPos pos = new BlockPos(chunkPos.getMinBlockX() + x, y, chunkPos.getMinBlockZ() + z);
               eachPos.accept(pos);
            }
         }
      }
   }

   public static VoxelShape getShapeByFacing(VoxelShape baseShape, Direction facing) {
      AABB bounds = baseShape.bounds();
      double startY = bounds.minY;
      double endY = bounds.maxY;

      return switch (facing) {
         case EAST -> Shapes.box(1.0 - bounds.maxZ, startY, bounds.minX, 1.0 - bounds.minZ, endY, bounds.maxX);
         case SOUTH -> Shapes.box(1.0 - bounds.maxX, startY, 1.0 - bounds.maxZ, 1.0 - bounds.minX, endY, 1.0 - bounds.minZ);
         case WEST -> Shapes.box(bounds.minZ, startY, 1.0 - bounds.maxX, bounds.maxZ, endY, 1.0 - bounds.minX);
         default -> baseShape;
      };
   }

   public static List<BakedQuad> processQuads(List<BakedQuad> originalQuads, Consumer<QuadInfo> processor) {
      List<BakedQuad> newQuads = new ArrayList<>();

      for (BakedQuad originalQuad : originalQuads) {
         QuadInfo quadInfo = new QuadInfo();
         quadInfo.loadFromBakedQuad(originalQuad);
         processor.accept(quadInfo);
         newQuads.add(quadInfo.makeBakedQuad());
      }

      return newQuads;
   }

   public static BlockState copyProperties(BlockState source, BlockState target) {
      BlockState result = target;

      for (Property<?> property : source.getProperties()) {
         if (target.hasProperty(property)) {
            result = copyPropertyValue(source, result, property);
         }
      }

      return result;
   }

   private static <T extends Comparable<T>> BlockState copyPropertyValue(BlockState source, BlockState target, Property<T> property) {
      T value = (T)source.getValue(property);
      return (BlockState)target.setValue(property, value);
   }

   public static boolean hasEnoughIngredient(NonNullList<ItemStack> items, IngredientWithCount ingredient) {
      int hasCount = 0;
      int size = items.size();

      for (int i = 0; i < size; i++) {
         ItemStack item = (ItemStack)items.get(i);
         ItemStack[] ingredientItems = ingredient.ingredient().getItems();

         for (int j = 0; j < ingredientItems.length; j++) {
            if (ItemStack.isSameItem(item, ingredientItems[j])) {
               hasCount += item.getCount();
            }
         }
      }

      return hasCount >= ingredient.count();
   }

   public static boolean consumeIngredient(NonNullList<ItemStack> items, IngredientWithCount ingredient) {
      int consumeTotal = ingredient.count();
      if (consumeTotal <= 0) {
         return true;
      } else {
         int rest = consumeTotal;
         int size = items.size();

         for (int i = 0; i < size; i++) {
            ItemStack item = (ItemStack)items.get(i);
            ItemStack[] ingredientItems = ingredient.ingredient().getItems();

            for (int j = 0; j < ingredientItems.length; j++) {
               if (ItemStack.isSameItem(item, ingredientItems[j])) {
                  int count = item.getCount();
                  if (count == rest) {
                     items.set(i, ItemStack.EMPTY);
                     return true;
                  }

                  if (count > rest) {
                     item.setCount(count - rest);
                     items.set(i, item);
                     return true;
                  }

                  items.set(i, ItemStack.EMPTY);
                  rest -= count;
               }
            }
         }

         return rest == 0;
      }
   }

   public static List<WoodworkingBenchRecipe> getAllWoodworkingBenchRecipes(RecipeManager recipeManager) {
      List<WoodworkingBenchRecipe> recipes = new ArrayList<>();
      for (RecipeHolder<WoodworkingBenchRecipe> holder : recipeManager.getAllRecipesFor(ModRecipeTypes.WOODWORKING_BENCH.get())) {
         recipes.add(holder.value());
      }
      return copyAndSortWoodworkingBenchRecipes(recipes);
   }
   public static List<WoodworkingBenchRecipe> copyAndSortWoodworkingBenchRecipes(List<WoodworkingBenchRecipe> recipes) {
      List<WoodworkingBenchRecipe> sortedRecipes = new ArrayList<>(recipes);
      sortedRecipes.sort((r1, r2) -> {
         int s1 = r1.getSortIndex();
         int s2 = r2.getSortIndex();
         if (s1 == s2) {
            return 0;
         } else {
            return s1 > s2 ? 1 : -1;
         }
      });
      return sortedRecipes;
   }

   public static void returnDisguiseItem(BlockState disguisState, Player player, Level level) {
      Item returnItem = disguisState.getBlock().asItem();
      ItemStack returnStack = new ItemStack(returnItem);
      if (returnItem instanceof MultiTextureBlockItem) {
         MultiTextureBlockItem.setPlacementMode(returnStack, 0);
      }

      Inventory inventory = player.getInventory();
      if (!tryGiveItemToPlayerMainHand(inventory, returnStack)
         && !tryGiveItemToPlayerHotbar(inventory, returnStack)
         && !tryGiveItemToPlayerBackpack(inventory, returnStack)) {
         level.addFreshEntity(new ItemEntity(level, player.getX(), player.getY(), player.getZ(), returnStack));
      }
   }
}
