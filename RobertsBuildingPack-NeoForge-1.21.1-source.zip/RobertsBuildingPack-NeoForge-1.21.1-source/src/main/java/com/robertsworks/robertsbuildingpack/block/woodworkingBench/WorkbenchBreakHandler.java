package com.robertsworks.robertsbuildingpack.block.woodworkingBench;

import com.robertsworks.robertsbuildingpack.util.enums.DeskPart;
import com.robertsworks.robertsbuildingpack.util.properties.RBPProperties;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.event.level.BlockEvent.BreakEvent;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;

@EventBusSubscriber(
   modid = "roberts_building_pack"
)
public class WorkbenchBreakHandler {
   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public static void onBlockBreak(BreakEvent event) {
      LevelAccessor level = event.getLevel();
      if (!level.isClientSide()) {
         BlockState state = event.getState();
         if (state.getBlock() instanceof WoodworkingBench) {
            BlockPos pos = event.getPos();
            if (level.getBlockEntity(pos) instanceof WoodworkingBenchBlockEntity wbbe) {
               DeskPart part = (DeskPart)state.getValue(RBPProperties.DESKPART);
               if (part == DeskPart.RIGHT) {
                  BlockPos npos = WoodworkingBench.getNeighbourPos(state, pos);
                  if (level.getBlockEntity(npos) instanceof WoodworkingBenchBlockEntity nwbbe) {
                     wbbe.loadFromAnother(nwbbe);
                  }
               }
            }
         }
      }
   }
}
