package com.robertsworks.robertsbuildingpack.block.woodworkingBench;

import com.robertsworks.robertsbuildingpack.gui.WoodworkingBenchMenu;
import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import com.robertsworks.robertsbuildingpack.util.enums.DeskPart;
import com.robertsworks.robertsbuildingpack.util.properties.RBPProperties;
import java.util.Collections;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.level.LevelReader;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class WoodworkingBench extends HorizontalDirectionalBlock implements EntityBlock {
   public static final MapCodec<WoodworkingBench> CODEC = MapCodec.unit(WoodworkingBench::new);

   @Override
   protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
      return CODEC;
   }

   public WoodworkingBench() {
      super(Properties.ofFullCopy(Blocks.OAK_PLANKS).noOcclusion());
      this.registerDefaultState(
         (BlockState)((BlockState)((BlockState)this.stateDefinition.any()).setValue(FACING, Direction.NORTH)).setValue(RBPProperties.DESKPART, DeskPart.LEFT)
      );
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{FACING}).add(new Property[]{RBPProperties.DESKPART});
   }

   public BlockState getStateForPlacement(BlockPlaceContext context) {
      Direction facing = context.getHorizontalDirection();
      BlockPos pos = context.getClickedPos();
      BlockPos rightPos = pos.relative(facing.getClockWise());
      Level level = context.getLevel();
      return level.getBlockState(rightPos).canBeReplaced(context) && level.getWorldBorder().isWithinBounds(rightPos)
         ? (BlockState)((BlockState)this.defaultBlockState().setValue(FACING, facing)).setValue(RBPProperties.DESKPART, DeskPart.LEFT)
         : null;
   }

   public static BlockPos getNeighbourPos(DeskPart part, Direction facing, BlockPos pos) {
      Direction direction = part == DeskPart.LEFT ? facing.getClockWise() : facing.getCounterClockWise();
      return pos.relative(direction);
   }

   public static BlockPos getNeighbourPos(BlockState state, BlockPos pos) {
      Direction facing = (Direction)state.getValue(FACING);
      DeskPart part = (DeskPart)state.getValue(RBPProperties.DESKPART);
      return getNeighbourPos(part, facing, pos);
   }

   public void setPlacedBy(Level level, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
      super.setPlacedBy(level, pos, state, placer, stack);
      WoodworkingBenchBlockEntity wbbe = level.getBlockEntity(pos) instanceof WoodworkingBenchBlockEntity w ? w : null;
      ItemContainerContents contents = stack.get(DataComponents.CONTAINER);
      if (wbbe != null && contents != null) {
         contents.copyInto(wbbe.getItems());
         wbbe.setChanged();
      }
      if (!level.isClientSide) {
         Direction facing = (Direction)state.getValue(FACING);
         BlockPos neighbourPos = getNeighbourPos(DeskPart.LEFT, facing, pos);
         level.setBlock(neighbourPos, (BlockState)state.setValue(RBPProperties.DESKPART, DeskPart.RIGHT), 3);
         level.blockUpdated(pos, Blocks.AIR);
         state.updateIndirectNeighbourShapes(level, pos, 3);
      }
   }

   public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
      Direction facing = (Direction)state.getValue(FACING);
      return RBPHelper.getShapeByFacing(box(0.0, 0.0, 1.0, 16.0, 10.0, 15.0), facing);
   }

   public List<ItemStack> getDrops(BlockState state, net.minecraft.world.level.storage.loot.LootParams.Builder builder) {
      BlockEntity blockEntity = (BlockEntity)builder.getParameter(LootContextParams.BLOCK_ENTITY);
      ItemStack stack = this.getCloneItemStack(blockEntity);
      return Collections.singletonList(stack);
   }

   @Override
   protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
      if (level.isClientSide) {
         return InteractionResult.SUCCESS;
      } else {
         MenuProvider menuProvider = this.getMenuProvider(state, level, pos);
         ((ServerPlayer)player).openMenu(menuProvider, pos);
         player.awardStat(Stats.INTERACT_WITH_STONECUTTER);
         return InteractionResult.CONSUME;
      }
   }

   public MenuProvider getMenuProvider(BlockState state, Level level, BlockPos pos) {
      MutableComponent title = state.getBlock().getName();
      return new SimpleMenuProvider((id, inventory, player) -> new WoodworkingBenchMenu(id, inventory, level, pos), title);
   }

   public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
      return new WoodworkingBenchBlockEntity(pos, state);
   }

   public ItemStack getCloneItemStack(BlockEntity blockEntity) {
      ItemStack itemStack = new ItemStack(this);
      if (blockEntity instanceof WoodworkingBenchBlockEntity wbbe) {
         WoodworkingBenchBlockEntity mwbbe = wbbe.getMainBlockEntity();
         if (mwbbe != null) {
            mwbbe.saveItemsToStack(itemStack);
         } else {
            wbbe.saveItemsToStack(itemStack);
         }
      }

      return itemStack;
   }

   public ItemStack getCloneItemStack(LevelReader level, BlockPos pos, BlockState state) {
      BlockEntity blockEntity = level.getBlockEntity(pos);
      return this.getCloneItemStack(blockEntity);
   }

   public ItemStack getCloneItemStack(BlockState state, HitResult target, LevelReader level, BlockPos pos, Player player) {
      BlockEntity blockEntity = level.getBlockEntity(pos);
      return this.getCloneItemStack(blockEntity);
   }

   public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
      super.onRemove(state, level, pos, newState, isMoving);
      if (!level.isClientSide) {
         BlockPos npos = getNeighbourPos(state, pos);
         BlockState blockstate = level.getBlockState(npos);
         if (blockstate.is(this)) {
            level.removeBlock(npos, false);
         }
      }
   }
}
