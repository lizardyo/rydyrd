package com.robertsworks.robertsbuildingpack.block.furniture;

import com.robertsworks.robertsbuildingpack.util.properties.RBPProperties;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.phys.shapes.VoxelShape;

public class Downlight extends AbstractLamp {
   @Override
   public VoxelShape getLampShape(BlockState state) {
      Direction facing = state.getValue(RBPProperties.FACING);
      AttachFace face = state.getValue(RBPProperties.FACE);
      if (face == AttachFace.FLOOR) {
         return box(6.0, 0.0, 6.0, 10.0, 1.0, 10.0);
      } else if (face == AttachFace.CEILING) {
         return box(6.0, 15.0, 6.0, 10.0, 16.0, 10.0);
      } else {
         return switch (facing) {
            case NORTH -> box(6.0, 6.0, 15.0, 10.0, 10.0, 16.0);
            case EAST -> box(0.0, 6.0, 6.0, 1.0, 10.0, 10.0);
            case WEST -> box(15.0, 6.0, 6.0, 16.0, 10.0, 10.0);
            default -> box(6.0, 6.0, 0.0, 10.0, 10.0, 1.0);
         };
      }
   }
}
