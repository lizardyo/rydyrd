package com.robertsworks.robertsbuildingpack.block.disguise.bakedModels;

import com.robertsworks.robertsbuildingpack.block.disguise.DisguiseBlockEntity;
import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import com.robertsworks.robertsbuildingpack.util.other.BlockOffset;
import com.robertsworks.robertsbuildingpack.util.properties.RBPProperties;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.client.model.data.ModelData;
import net.minecraft.core.registries.BuiltInRegistries;

public class BakedDisguiseBlockModel extends AbstractBakedDisguiseBlockModel {
   public String shape = null;
   public Block normalBlock = null;
   public BlockColors blockColors;

   public BakedDisguiseBlockModel(String shape) {
      this.shape = shape;
      ResourceLocation blockId = ResourceLocation.fromNamespaceAndPath("roberts_building_pack", shape + "_normal");
      this.normalBlock = (Block)BuiltInRegistries.BLOCK.get(blockId);
      this.blockColors = Minecraft.getInstance().getBlockColors();
   }

   @Override
   public List<BakedQuad> onGetQuads(BlockState state, Direction side, RandomSource rand, ModelData data, RenderType renderType) {
      Level level = (Level)data.get(DisguiseBlockEntity.LEVEL);
      BlockPos pos = (BlockPos)data.get(DisguiseBlockEntity.POSITION);
      BlockOffset offset = (BlockOffset)data.get(DisguiseBlockEntity.OFFSET);
      BlockState disguiseState = (BlockState)data.get(DisguiseBlockEntity.DISGUISE_STATE);
      if (DisguiseBlockEntity.isDisguised(disguiseState)) {
         Direction facing = (Direction)state.getValue(RBPProperties.FACING);
         BlockState finalDisguiseState = RBPHelper.copyProperties(state, disguiseState);
         BakedModel targetModel = Minecraft.getInstance().getBlockRenderer().getBlockModel(disguiseState);
         BlockState normalState = RBPHelper.copyProperties(state, this.normalBlock.defaultBlockState());
         RenderType targetRenderType = ItemBlockRenderTypes.getChunkRenderType(disguiseState);
         List<BakedQuad> normalQuads = this.getModelQuads(normalState, side, rand, data, targetRenderType);
         if (side == null) {
            return RBPHelper.processQuads(normalQuads, quadInfo -> {
               List<BakedQuad> targetQuadsx = targetModel.getQuads(finalDisguiseState, quadInfo.direction, rand, data, renderType);
               TextureAtlasSprite targetSpritex = !targetQuadsx.isEmpty() ? targetQuadsx.get(0).getSprite() : targetModel.getParticleIcon(data);
               int tintIndexx = !targetQuadsx.isEmpty() ? targetQuadsx.get(0).getTintIndex() : -1;
               int colorx = tintIndexx != -1 ? this.blockColors.getColor(finalDisguiseState, level, pos, tintIndexx) : -1;
               if (colorx != -1) {
                  quadInfo.setColor(colorx);
               }

               quadInfo.offset(offset);
               quadInfo.resetSprite(targetSpritex, quadInfo.direction, facing);
            });
         } else {
            List<BakedQuad> targetQuads = targetModel.getQuads(finalDisguiseState, side, rand, data, renderType);
            TextureAtlasSprite targetSprite = !targetQuads.isEmpty() ? targetQuads.get(0).getSprite() : targetModel.getParticleIcon(data);
            int tintIndex = !targetQuads.isEmpty() ? targetQuads.get(0).getTintIndex() : -1;
            int color = tintIndex != -1 ? this.blockColors.getColor(finalDisguiseState, level, pos, tintIndex) : -1;
            return RBPHelper.processQuads(normalQuads, quadInfo -> {
               if (color != -1) {
                  quadInfo.setColor(color);
               }

               quadInfo.offset(offset);
               quadInfo.resetSprite(targetSprite, side, facing);
            });
         }
      } else {
         BlockState normalState = RBPHelper.copyProperties(state, this.normalBlock.defaultBlockState());
         List<BakedQuad> normalQuads = this.getModelQuads(normalState, side, rand, data, RenderType.cutout());
         return RBPHelper.processQuads(normalQuads, quadInfo -> quadInfo.offset(offset));
      }
   }
}
