package com.robertsworks.robertsbuildingpack.init;

import com.robertsworks.robertsbuildingpack.block.base.MultiTextureBlockItem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class ItemPropertyRegister {
   public static final ResourceLocation DISPLAY_TEXTURE = ResourceLocation.fromNamespaceAndPath("roberts_building_pack", "display_texture");

   public static void register() {
      registerDisplayTexture(
         new ArrayList<>(
            List.of(
               (Item)ModItems.COMMON_OAK_FLOOR.get(),
               (Item)ModItems.COMMON_SPRUCE_FLOOR.get(),
               (Item)ModItems.COMMON_BIRCH_FLOOR.get(),
               (Item)ModItems.COMMON_JUNGLE_FLOOR.get(),
               (Item)ModItems.COMMON_ACACIA_FLOOR.get(),
               (Item)ModItems.COMMON_DARK_OAK_FLOOR.get(),
               (Item)ModItems.FISHBONE_OAK_FLOOR.get(),
               (Item)ModItems.FISHBONE_SPRUCE_FLOOR.get(),
               (Item)ModItems.FISHBONE_BIRCH_FLOOR.get(),
               (Item)ModItems.FISHBONE_JUNGLE_FLOOR.get(),
               (Item)ModItems.FISHBONE_ACACIA_FLOOR.get(),
               (Item)ModItems.FISHBONE_DARK_OAK_FLOOR.get(),
               (Item)ModItems.TILE_A_006.get(),
               (Item)ModItems.TILE_A_007.get(),
               (Item)ModItems.TILE_A_008.get(),
               (Item)ModItems.TILE_A_009.get(),
               (Item)ModItems.TILE_A_010.get(),
               (Item)ModItems.TILE_A_011.get(),
               (Item)ModItems.TILE_A_012.get(),
               (Item)ModItems.TILE_A_013.get(),
               (Item)ModItems.TILE_A_014.get(),
               (Item)ModItems.TILE_A_015.get(),
               (Item)ModItems.TILE_B_011.get(),
               (Item)ModItems.TILE_B_012.get()
            )
         )
      );
   }

   public static void registerDisplayTexture(List<Item> items) {
      items.forEach(
         item -> ItemProperties.register(
               item, DISPLAY_TEXTURE, (itemStack, clientLevel, livingEntity, seed) -> (float)getDisplayTexture(itemStack, clientLevel, livingEntity, seed)
            )
      );
   }

   public static int getDisplayTexture(ItemStack itemStack, ClientLevel clientLevel, LivingEntity livingEntity, int seed) {
      int mode = MultiTextureBlockItem.getPlacementMode(itemStack);
      if (mode > 0) {
         return mode;
      } else if (mode < 0) {
         return 1;
      } else if (itemStack.getItem() instanceof MultiTextureBlockItem mitem) {
         long timeSource = clientLevel != null ? clientLevel.getGameTime() : System.currentTimeMillis() / 50L;
         return (int)(timeSource / 20L) % mitem.getTextureCount() + 1;
      } else {
         return 1;
      }
   }
}
