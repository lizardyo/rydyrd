package com.robertsworks.robertsbuildingpack.block.disguise;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import net.neoforged.neoforge.client.model.geometry.IGeometryLoader;

public class DisguiseModelLoader implements IGeometryLoader<UnbakedDisguiseModel> {
   public UnbakedDisguiseModel read(JsonObject json, JsonDeserializationContext context) {
      String shape = json.get("shape").getAsString();
      return new UnbakedDisguiseModel(shape);
   }
}
