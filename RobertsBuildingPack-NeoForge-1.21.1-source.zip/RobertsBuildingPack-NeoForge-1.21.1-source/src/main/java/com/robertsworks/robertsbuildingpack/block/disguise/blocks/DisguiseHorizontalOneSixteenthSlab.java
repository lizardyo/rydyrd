package com.robertsworks.robertsbuildingpack.block.disguise.blocks;

import com.robertsworks.robertsbuildingpack.util.enums.HorizontalSlabSide;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.shapes.VoxelShape;

public class DisguiseHorizontalOneSixteenthSlab extends AbstractDisguiseHorizontalSlab {
   protected static final VoxelShape SHAPE_BOTTOM = Block.box(0.0, 0.0, 0.0, 16.0, 1.0, 16.0);
   protected static final VoxelShape SHAPE_TOP = Block.box(0.0, 15.0, 0.0, 16.0, 16.0, 16.0);

   @Override
   public VoxelShape getSlabShape(HorizontalSlabSide side) {
      return side == HorizontalSlabSide.BOTTOM ? SHAPE_BOTTOM : SHAPE_TOP;
   }
}
