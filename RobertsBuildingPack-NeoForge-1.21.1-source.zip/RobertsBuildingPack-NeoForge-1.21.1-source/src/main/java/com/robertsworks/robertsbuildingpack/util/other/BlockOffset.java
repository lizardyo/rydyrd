package com.robertsworks.robertsbuildingpack.util.other;

import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import net.minecraft.core.Direction;

public class BlockOffset {
   private int x = 0;
   private int y = 0;
   private int z = 0;

   public BlockOffset() {
   }

   public BlockOffset(int x, int y, int z) {
      this.x = x;
      this.y = y;
      this.z = z;
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }

   public int getZ() {
      return this.z;
   }

   public void setX(int v) {
      this.x = RBPHelper.setMinMax(v, -15, 15);
   }

   public void setY(int v) {
      this.y = RBPHelper.setMinMax(v, -15, 15);
   }

   public void setZ(int v) {
      this.z = RBPHelper.setMinMax(v, -15, 15);
   }

   public boolean isMoved() {
      return this.x != 0 || this.y != 0 || this.z != 0;
   }

   public void moveDirection(Direction direction) {
      if (direction == Direction.DOWN) {
         this.y = this.y == -15 ? 0 : this.y - 1;
      } else if (direction == Direction.UP) {
         this.y = this.y == 15 ? 0 : this.y + 1;
      } else if (direction == Direction.WEST) {
         this.x = this.x == -15 ? 0 : this.x - 1;
      } else if (direction == Direction.EAST) {
         this.x = this.x == 15 ? 0 : this.x + 1;
      } else if (direction == Direction.NORTH) {
         this.z = this.z == -15 ? 0 : this.z - 1;
      } else if (direction == Direction.SOUTH) {
         this.z = this.z == 15 ? 0 : this.z + 1;
      }
   }
}
