package com.robertsworks.robertsbuildingpack.util.enums;

import net.minecraft.util.StringRepresentable;

public enum DeskPart implements StringRepresentable {
   LEFT("left"),
   RIGHT("right");

   private final String name;

   private DeskPart(String name) {
      this.name = name;
   }

   @Override
   public String toString() {
      return this.name;
   }

   public String getSerializedName() {
      return this.name;
   }
}
