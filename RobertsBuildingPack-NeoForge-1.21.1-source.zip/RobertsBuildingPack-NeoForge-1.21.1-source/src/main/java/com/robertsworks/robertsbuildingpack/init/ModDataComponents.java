package com.robertsworks.robertsbuildingpack.init;

import com.mojang.serialization.Codec;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Replaces the old item NBT tag "placement_mode" with a proper 1.21 data component. */
public class ModDataComponents {
   public static final DeferredRegister<DataComponentType<?>> REGISTRY = DeferredRegister.create(Registries.DATA_COMPONENT_TYPE, "roberts_building_pack");

   public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> PLACEMENT_MODE = REGISTRY.register(
      "placement_mode",
      () -> DataComponentType.<Integer>builder().persistent(Codec.INT).networkSynchronized(ByteBufCodecs.VAR_INT).build()
   );
}
