package com.robertsworks.robertsbuildingpack.block.tile;

import com.robertsworks.robertsbuildingpack.block.base.MultiTextureBlockItem;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.block.Block;

public class MultiTextureTile2BlockItem extends MultiTextureBlockItem {
   public MultiTextureTile2BlockItem(Block block) {
      super(block, new Properties(), 2);
   }

   @Override
   public int getDefaultPlacementMode() {
      return 0;
   }

   @Override
   public int getNextPlacementMode(int currentMode) {
      return currentMode == 2 ? 0 : currentMode + 1;
   }

   @Override
   public int getTextureForPlacement(ItemStack stack, BlockPos pos, RandomSource randomSource, Direction facing) {
      int mode = getPlacementMode(stack);
      if (mode == 0) {
         int v1 = Mth.abs(pos.getX()) % 2;
         int v2 = Mth.abs(pos.getY()) % 2;
         int v3 = Mth.abs(pos.getZ()) % 2;
         return (v1 + v2 + v3) % 2 + 1;
      } else {
         return mode;
      }
   }

   @Override
   public Component getPlacementModeName(int mode) {
      return mode == 0
         ? Component.translatable("tooltip.roberts_building_pack.item.placement_mode_auto").withStyle(ChatFormatting.BLUE)
         : Component.translatable("tooltip.roberts_building_pack.item.placement_mode_fixed", new Object[]{mode}).withStyle(ChatFormatting.BLUE);
   }

   @Override
   public Component getPlacementModeDesciption(int mode) {
      return mode == 0
         ? Component.translatable("tooltip.roberts_building_pack.item.placement_mode_auto_desc").withStyle(ChatFormatting.WHITE)
         : Component.translatable("tooltip.roberts_building_pack.item.placement_mode_fixed_desc", new Object[]{mode}).withStyle(ChatFormatting.WHITE);
   }
}
