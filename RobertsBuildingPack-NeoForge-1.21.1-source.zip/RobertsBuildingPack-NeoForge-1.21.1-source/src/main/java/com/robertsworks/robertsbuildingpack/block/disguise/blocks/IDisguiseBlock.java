package com.robertsworks.robertsbuildingpack.block.disguise.blocks;

import com.robertsworks.robertsbuildingpack.block.base.MultiTextureBlockItem;
import com.robertsworks.robertsbuildingpack.block.disguise.DisguiseBlockEntity;
import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import com.robertsworks.robertsbuildingpack.util.properties.RBPProperties;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent.RightClickBlock;

public interface IDisguiseBlock extends EntityBlock {
   default BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
      return new DisguiseBlockEntity(pos, state);
   }

   default BlockState getBaseBlockState(StateDefinition<Block, BlockState> stateDefinition) {
      return (BlockState)((BlockState)((BlockState)((BlockState)stateDefinition.any()).setValue(RBPProperties.DISGUISED, false))
            .setValue(RBPProperties.MOVED, false))
         .setValue(RBPProperties.TEXTURE, 1);
   }

   default void addDisguiseBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{RBPProperties.DISGUISED, RBPProperties.MOVED, RBPProperties.TEXTURE});
   }

   default VoxelShape offsetShape(VoxelShape shape, BlockGetter level, BlockPos pos) {
      if (level.getBlockEntity(pos) instanceof DisguiseBlockEntity be) {
         double offset_x = (double)((float)be.offset.getX()) / 16.0;
         double offset_y = (double)((float)be.offset.getY()) / 16.0;
         double offset_z = (double)((float)be.offset.getZ()) / 16.0;
         return Shapes.create(shape.bounds().move(offset_x, offset_y, offset_z));
      } else {
         return shape;
      }
   }

   default RenderShape onGetRenderShape(BlockState state) {
      return RenderShape.MODEL;
   }

   default void processBlockRightClick(RightClickBlock event, BlockState state, Level level, BlockPos pos, Player player, ItemStack stack) {
      if (level.getBlockEntity(pos) instanceof DisguiseBlockEntity disguiseBE) {
         boolean hasDisguiseState = disguiseBE.hasDisguiseState();
         boolean isCreative = player.getAbilities().instabuild;
         if (!player.isCrouching() && !stack.isEmpty() && stack.getItem() instanceof BlockItem blockItem) {
            if (hasDisguiseState) {
               return;
            }

            Block targetBlock = blockItem.getBlock();
            if (!this.isDisguiseable(targetBlock)) {
               return;
            }

            if (level.isClientSide) {
               event.setCanceled(true);
               event.setCancellationResult(InteractionResult.SUCCESS);
            } else {
               BlockState newState = (BlockState)state.setValue(RBPProperties.DISGUISED, true);
               if (blockItem instanceof MultiTextureBlockItem multiTextureBlockItem) {
                  Direction facing = (Direction)state.getValue(RBPProperties.FACING);
                  int texture = multiTextureBlockItem.getTextureForPlacement(stack, pos, level.getRandom(), facing);
                  newState = (BlockState)newState.setValue(RBPProperties.TEXTURE, texture);
               }

               disguiseBE.setDisguiseState(targetBlock.defaultBlockState());
               level.setBlock(pos, newState, 3);
               RBPHelper.playBlockSound(level, pos, SoundEvents.COMPARATOR_CLICK, 0.8F, 1.0F);
               if (!isCreative) {
                  stack.shrink(1);
               }

               event.setCanceled(true);
               event.setCancellationResult(InteractionResult.FAIL);
            }
         }
      }
   }

   default void processPlayerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
      if (!level.isClientSide && !player.getAbilities().instabuild && level.getBlockEntity(pos) instanceof DisguiseBlockEntity disguiseBE && disguiseBE.hasDisguiseState()) {
         BlockState disguiseState = disguiseBE.getDisguiseState();
         Item dropItem = disguiseState.getBlock().asItem();
         ItemStack dropItemStack = dropItem.getDefaultInstance();
         if (dropItem instanceof MultiTextureBlockItem) {
            MultiTextureBlockItem.setPlacementMode(dropItemStack, 0);
         }

         Containers.dropItemStack(level, (double)pos.getX(), (double)pos.getY(), (double)pos.getZ(), dropItemStack);
      }
   }

   default boolean isDisguiseable(Block block) {
      if (block instanceof IDisguiseBlock) {
         return false;
      } else {
         return block instanceof EntityBlock ? false : block.defaultBlockState().isCollisionShapeFullBlock(null, null);
      }
   }
}
