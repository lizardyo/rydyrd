package com.robertsworks.robertsbuildingpack.util.other;

@FunctionalInterface
public interface NullConsumer {
   void accept();
}
