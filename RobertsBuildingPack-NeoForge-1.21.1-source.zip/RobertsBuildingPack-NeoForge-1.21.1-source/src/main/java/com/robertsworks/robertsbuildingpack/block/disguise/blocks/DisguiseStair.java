package com.robertsworks.robertsbuildingpack.block.disguise.blocks;

import com.robertsworks.robertsbuildingpack.init.ModBlocks;
import java.util.Collections;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;

public class DisguiseStair extends StairBlock implements IDisguiseBlock {
   public DisguiseStair() {
      super(ModBlocks.DISGUISE_BLOCK.get().defaultBlockState(), Properties.ofFullCopy(Blocks.OAK_PLANKS).noOcclusion());
      this.registerDefaultState(this.getBaseBlockState(this.stateDefinition));
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      super.createBlockStateDefinition(builder);
      this.addDisguiseBlockStateDefinition(builder);
   }

   public RenderShape getRenderShape(BlockState state) {
      return this.onGetRenderShape(state);
   }

   @Override
   public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
      BlockState result = super.playerWillDestroy(level, pos, state, player);
      this.processPlayerWillDestroy(level, pos, state, player);
      return result;
   }

   public List<ItemStack> getDrops(BlockState state, net.minecraft.world.level.storage.loot.LootParams.Builder params) {
      return Collections.singletonList(new ItemStack(this));
   }
}
