package com.robertsworks.robertsbuildingpack.block.tile;

import com.robertsworks.robertsbuildingpack.block.base.MultiTextureBlock;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public class MultiTextureTileBlock extends MultiTextureBlock {
   private int textureCount = 1;

   public MultiTextureTileBlock(int textureCount) {
      super(Properties.ofFullCopy(Blocks.STONE));
      this.textureCount = textureCount;
   }

   @Override
   public int getTextureCount() {
      return this.textureCount;
   }

   @Override
   public int getPrevTexture(int currentTexture) {
      return currentTexture == 1 ? this.textureCount : currentTexture - 1;
   }

   @Override
   public int getNextTexture(int currentTexture) {
      return currentTexture == this.textureCount ? 1 : currentTexture + 1;
   }

   @Override
   public ItemStack getDropStack(BlockState state) {
      ItemStack stack = new ItemStack(this);
      int texture = this.getTextureValue(state);
      MultiTextureTileBlockItem.setPlacementMode(stack, texture);
      return stack;
   }
}
