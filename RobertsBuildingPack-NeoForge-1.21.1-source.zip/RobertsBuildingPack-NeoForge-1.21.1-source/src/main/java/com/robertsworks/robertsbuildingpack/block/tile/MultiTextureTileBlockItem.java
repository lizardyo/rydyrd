package com.robertsworks.robertsbuildingpack.block.tile;

import com.robertsworks.robertsbuildingpack.block.base.MultiTextureBlockItem;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.block.Block;

public class MultiTextureTileBlockItem extends MultiTextureBlockItem {
   private int textureCount = 1;

   public MultiTextureTileBlockItem(Block block, int textureCount) {
      super(block, new Properties(), textureCount);
      this.textureCount = textureCount;
   }

   @Override
   public int getDefaultPlacementMode() {
      return 0;
   }

   @Override
   public int getNextPlacementMode(int currentMode) {
      return currentMode == this.textureCount ? 0 : currentMode + 1;
   }

   @Override
   public int getTextureForPlacement(ItemStack stack, BlockPos pos, RandomSource randomSource, Direction facing) {
      int mode = getPlacementMode(stack);
      return mode == 0 ? randomSource.nextInt(this.textureCount) + 1 : mode;
   }

   @Override
   public Component getPlacementModeName(int mode) {
      return mode == 0
         ? Component.translatable("tooltip.roberts_building_pack.item.placement_mode_random").withStyle(ChatFormatting.BLUE)
         : Component.translatable("tooltip.roberts_building_pack.item.placement_mode_fixed", new Object[]{mode}).withStyle(ChatFormatting.BLUE);
   }

   @Override
   public Component getPlacementModeDesciption(int mode) {
      return mode == 0
         ? Component.translatable("tooltip.roberts_building_pack.item.placement_mode_random_desc", new Object[]{this.textureCount})
            .withStyle(ChatFormatting.WHITE)
         : Component.translatable("tooltip.roberts_building_pack.item.placement_mode_fixed_desc", new Object[]{mode}).withStyle(ChatFormatting.WHITE);
   }
}
