package com.robertsworks.robertsbuildingpack.block.disguise.blocks;

import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import com.robertsworks.robertsbuildingpack.util.enums.VerticalSlabSide;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.shapes.VoxelShape;

public class DisguiseVerticalQuarterSlab extends AbstractDisguiseVerticalSlab {
   protected static final VoxelShape SHAPE_BACK = Block.box(0.0, 0.0, 0.0, 16.0, 16.0, 4.0);
   protected static final VoxelShape SHAPE_FRONT = Block.box(0.0, 0.0, 12.0, 16.0, 16.0, 16.0);

   @Override
   public VoxelShape getSlabShape(VerticalSlabSide side, Direction facing) {
      return RBPHelper.getShapeByFacing(side == VerticalSlabSide.BACK ? SHAPE_BACK : SHAPE_FRONT, facing);
   }
}
