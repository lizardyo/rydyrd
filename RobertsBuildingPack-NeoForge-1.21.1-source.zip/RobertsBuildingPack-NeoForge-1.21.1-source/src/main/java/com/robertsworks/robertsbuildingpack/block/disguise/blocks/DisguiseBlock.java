package com.robertsworks.robertsbuildingpack.block.disguise.blocks;

import com.mojang.serialization.MapCodec;
import java.util.Collections;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.shapes.VoxelShape;

public class DisguiseBlock extends HorizontalDirectionalBlock implements IDisguiseBlock {
   public static final MapCodec<DisguiseBlock> CODEC = MapCodec.unit(DisguiseBlock::new);

   @Override
   protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
      return CODEC;
   }

   protected static final VoxelShape SHAPE = Block.box(0.0, 0.0, 0.0, 16.0, 16.0, 16.0);

   public DisguiseBlock() {
      super(Properties.ofFullCopy(Blocks.OAK_PLANKS).noOcclusion());
      this.registerDefaultState((BlockState)this.getBaseBlockState(this.stateDefinition).setValue(FACING, Direction.NORTH));
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      super.createBlockStateDefinition(builder);
      this.addDisguiseBlockStateDefinition(builder);
      builder.add(new Property[]{FACING});
   }

   public RenderShape getRenderShape(BlockState state) {
      return this.onGetRenderShape(state);
   }

   public BlockState getStateForPlacement(BlockPlaceContext context) {
      return (BlockState)super.getStateForPlacement(context).setValue(FACING, context.getHorizontalDirection());
   }

   @Override
   public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
      BlockState result = super.playerWillDestroy(level, pos, state, player);
      this.processPlayerWillDestroy(level, pos, state, player);
      return result;
   }

   public List<ItemStack> getDrops(BlockState state, net.minecraft.world.level.storage.loot.LootParams.Builder params) {
      return Collections.singletonList(new ItemStack(this));
   }
}
