package com.robertsworks.robertsbuildingpack.block.tile;

import com.robertsworks.robertsbuildingpack.block.base.MultiTextureBlock;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public class MultiTextureTile2Block extends MultiTextureBlock {
   public MultiTextureTile2Block() {
      super(Properties.ofFullCopy(Blocks.STONE));
   }

   @Override
   public int getTextureCount() {
      return 2;
   }

   @Override
   public int getPrevTexture(int currentTexture) {
      return currentTexture == 1 ? 2 : 1;
   }

   @Override
   public int getNextTexture(int currentTexture) {
      return currentTexture == 1 ? 2 : 1;
   }

   @Override
   public ItemStack getDropStack(BlockState state) {
      ItemStack stack = new ItemStack(this);
      int texture = this.getTextureValue(state);
      MultiTextureTileBlockItem.setPlacementMode(stack, texture);
      return stack;
   }
}
