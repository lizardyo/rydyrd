package com.robertsworks.robertsbuildingpack.item.tools;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item.Properties;

public class ScrewItem extends Item {
   public ScrewItem() {
      super(new Properties().stacksTo(64).rarity(Rarity.COMMON));
   }
}
