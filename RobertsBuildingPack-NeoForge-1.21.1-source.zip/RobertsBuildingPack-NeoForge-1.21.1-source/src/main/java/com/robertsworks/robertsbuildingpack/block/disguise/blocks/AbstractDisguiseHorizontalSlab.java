package com.robertsworks.robertsbuildingpack.block.disguise.blocks;

import com.robertsworks.robertsbuildingpack.util.enums.HorizontalSlabSide;
import com.robertsworks.robertsbuildingpack.util.properties.RBPProperties;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public abstract class AbstractDisguiseHorizontalSlab extends Block implements IDisguiseBlock, SimpleWaterloggedBlock {
   public AbstractDisguiseHorizontalSlab() {
      super(Properties.ofFullCopy(Blocks.OAK_PLANKS).noOcclusion());
      this.registerDefaultState(
         (BlockState)((BlockState)((BlockState)this.getBaseBlockState(this.stateDefinition).setValue(RBPProperties.FACING, Direction.NORTH))
               .setValue(RBPProperties.HORIZONTAL_SLAB_SIDE, HorizontalSlabSide.BOTTOM))
            .setValue(RBPProperties.WATERLOGGED, false)
      );
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      super.createBlockStateDefinition(builder);
      this.addDisguiseBlockStateDefinition(builder);
      builder.add(new Property[]{RBPProperties.FACING, RBPProperties.HORIZONTAL_SLAB_SIDE, RBPProperties.WATERLOGGED});
   }

   public RenderShape getRenderShape(BlockState state) {
      return this.onGetRenderShape(state);
   }

   public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
      HorizontalSlabSide side = (HorizontalSlabSide)state.getValue(RBPProperties.HORIZONTAL_SLAB_SIDE);
      return this.getSlabShape(side);
   }

   public BlockState getStateForPlacement(BlockPlaceContext context) {
      Direction direction = context.getClickedFace();
      BlockPos pos = context.getClickedPos();
      Vec3 clickLocation = context.getClickLocation().subtract((double)pos.getX(), (double)pos.getY(), (double)pos.getZ());
      Direction facing = context.getHorizontalDirection();
      FluidState fluidstate = context.getLevel().getFluidState(pos);
      HorizontalSlabSide side = HorizontalSlabSide.BOTTOM;
      if (direction == Direction.UP) {
         side = HorizontalSlabSide.BOTTOM;
      } else if (direction == Direction.DOWN) {
         side = HorizontalSlabSide.TOP;
      } else if (clickLocation.y > 0.5) {
         side = HorizontalSlabSide.TOP;
      } else {
         side = HorizontalSlabSide.BOTTOM;
      }

      return (BlockState)((BlockState)((BlockState)this.defaultBlockState().setValue(RBPProperties.FACING, facing)).setValue(RBPProperties.HORIZONTAL_SLAB_SIDE, side))
         .setValue(RBPProperties.WATERLOGGED, fluidstate.getType() == Fluids.WATER);
   }

   public FluidState getFluidState(BlockState state) {
      return state.getValue(RBPProperties.WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
   }

   public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
      if ((Boolean)state.getValue(RBPProperties.WATERLOGGED)) {
         level.scheduleTick(pos, Fluids.WATER, Fluids.WATER.getTickDelay(level));
      }

      return super.updateShape(state, direction, neighborState, level, pos, neighborPos);
   }

   public abstract VoxelShape getSlabShape(HorizontalSlabSide var1);
}
