package com.robertsworks.robertsbuildingpack.item.materials;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item.Properties;

public class BrickItem extends Item {
   public BrickItem() {
      super(new Properties().stacksTo(64).rarity(Rarity.COMMON));
   }
}
