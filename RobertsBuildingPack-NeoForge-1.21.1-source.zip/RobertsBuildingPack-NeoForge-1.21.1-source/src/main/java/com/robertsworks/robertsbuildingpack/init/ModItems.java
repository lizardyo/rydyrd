package com.robertsworks.robertsbuildingpack.init;

import com.robertsworks.robertsbuildingpack.block.disguise.DisguiseBlockItem;
import com.robertsworks.robertsbuildingpack.block.floor.FloorBlock4Item;
import com.robertsworks.robertsbuildingpack.block.floor.OldFloorBlockItem;
import com.robertsworks.robertsbuildingpack.block.furniture.DownlightItem;
import com.robertsworks.robertsbuildingpack.block.tile.MultiTextureTile2BlockItem;
import com.robertsworks.robertsbuildingpack.block.tile.MultiTextureTileBlockItem;
import com.robertsworks.robertsbuildingpack.block.woodworkingBench.WoodworkingBenchItem;
import com.robertsworks.robertsbuildingpack.item.materials.BrickItem;
import com.robertsworks.robertsbuildingpack.item.materials.QuartzItem;
import com.robertsworks.robertsbuildingpack.item.tools.ChiselBladeItem;
import com.robertsworks.robertsbuildingpack.item.tools.ChiselItem;
import com.robertsworks.robertsbuildingpack.item.tools.HammerItem;
import com.robertsworks.robertsbuildingpack.item.tools.HammerTopItem;
import com.robertsworks.robertsbuildingpack.item.tools.SawBladeItem;
import com.robertsworks.robertsbuildingpack.item.tools.SawItem;
import com.robertsworks.robertsbuildingpack.item.tools.ScrewItem;
import com.robertsworks.robertsbuildingpack.item.tools.ScrewdriverHeadItem;
import com.robertsworks.robertsbuildingpack.item.tools.ScrewdriverItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.minecraft.core.registries.BuiltInRegistries;
import net.neoforged.neoforge.registries.DeferredHolder;

public class ModItems {
   public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(BuiltInRegistries.ITEM, "roberts_building_pack");
   public static final DeferredHolder<Item, Item> SCREW = REGISTRY.register("screw", () -> new ScrewItem());
   public static final DeferredHolder<Item, Item> IRON_SAW_BLADE = REGISTRY.register("iron_saw_blade", () -> new SawBladeItem());
   public static final DeferredHolder<Item, Item> GOLDEN_SAW_BLADE = REGISTRY.register("golden_saw_blade", () -> new SawBladeItem());
   public static final DeferredHolder<Item, Item> DIAMOND_SAW_BLADE = REGISTRY.register("diamond_saw_blade", () -> new SawBladeItem());
   public static final DeferredHolder<Item, Item> IRON_CHISEL_BLADE = REGISTRY.register("iron_chisel_blade", () -> new ChiselBladeItem());
   public static final DeferredHolder<Item, Item> GOLDEN_CHISEL_BLADE = REGISTRY.register("golden_chisel_blade", () -> new ChiselBladeItem());
   public static final DeferredHolder<Item, Item> DIAMOND_CHISEL_BLADE = REGISTRY.register("diamond_chisel_blade", () -> new ChiselBladeItem());
   public static final DeferredHolder<Item, Item> IRON_HAMMER_TOP = REGISTRY.register("iron_hammer_top", () -> new HammerTopItem());
   public static final DeferredHolder<Item, Item> GOLDEN_HAMMER_TOP = REGISTRY.register("golden_hammer_top", () -> new HammerTopItem());
   public static final DeferredHolder<Item, Item> DIAMOND_HAMMER_TOP = REGISTRY.register("diamond_hammer_top", () -> new HammerTopItem());
   public static final DeferredHolder<Item, Item> IRON_SCREWDRIVER_HEAD = REGISTRY.register("iron_screwdriver_head", () -> new ScrewdriverHeadItem());
   public static final DeferredHolder<Item, Item> GOLDEN_SCREWDRIVER_HEAD = REGISTRY.register("golden_screwdriver_head", () -> new ScrewdriverHeadItem());
   public static final DeferredHolder<Item, Item> DIAMOND_SCREWDRIVER_HEAD = REGISTRY.register("diamond_screwdriver_head", () -> new ScrewdriverHeadItem());
   public static final DeferredHolder<Item, Item> IRON_SAW = REGISTRY.register("iron_saw", () -> new SawItem(Tiers.IRON));
   public static final DeferredHolder<Item, Item> GOLDEN_SAW = REGISTRY.register("golden_saw", () -> new SawItem(Tiers.GOLD));
   public static final DeferredHolder<Item, Item> DIAMOND_SAW = REGISTRY.register("diamond_saw", () -> new SawItem(Tiers.DIAMOND));
   public static final DeferredHolder<Item, Item> NETHERITE_SAW = REGISTRY.register("netherite_saw", () -> new SawItem(Tiers.NETHERITE));
   public static final DeferredHolder<Item, Item> IRON_CHISEL = REGISTRY.register("iron_chisel", () -> new ChiselItem(Tiers.IRON));
   public static final DeferredHolder<Item, Item> GOLDEN_CHISEL = REGISTRY.register("golden_chisel", () -> new ChiselItem(Tiers.GOLD));
   public static final DeferredHolder<Item, Item> DIAMOND_CHISEL = REGISTRY.register("diamond_chisel", () -> new ChiselItem(Tiers.DIAMOND));
   public static final DeferredHolder<Item, Item> NETHERITE_CHISEL = REGISTRY.register("netherite_chisel", () -> new ChiselItem(Tiers.NETHERITE));
   public static final DeferredHolder<Item, Item> IRON_HAMMER = REGISTRY.register("iron_hammer", () -> new HammerItem(Tiers.IRON));
   public static final DeferredHolder<Item, Item> GOLDEN_HAMMER = REGISTRY.register("golden_hammer", () -> new HammerItem(Tiers.GOLD));
   public static final DeferredHolder<Item, Item> DIAMOND_HAMMER = REGISTRY.register("diamond_hammer", () -> new HammerItem(Tiers.DIAMOND));
   public static final DeferredHolder<Item, Item> NETHERITE_HAMMER = REGISTRY.register("netherite_hammer", () -> new HammerItem(Tiers.NETHERITE));
   public static final DeferredHolder<Item, Item> IRON_SCREWDRIVER = REGISTRY.register("iron_screwdriver", () -> new ScrewdriverItem(Tiers.IRON));
   public static final DeferredHolder<Item, Item> GOLDEN_SCREWDRIVER = REGISTRY.register("golden_screwdriver", () -> new ScrewdriverItem(Tiers.GOLD));
   public static final DeferredHolder<Item, Item> DIAMOND_SCREWDRIVER = REGISTRY.register("diamond_screwdriver", () -> new ScrewdriverItem(Tiers.DIAMOND));
   public static final DeferredHolder<Item, Item> NETHERITE_SCREWDRIVER = REGISTRY.register("netherite_screwdriver", () -> new ScrewdriverItem(Tiers.NETHERITE));
   public static final DeferredHolder<Item, Item> WHITE_BRICK = REGISTRY.register("white_brick", () -> new BrickItem());
   public static final DeferredHolder<Item, Item> RED_BRICK = REGISTRY.register("red_brick", () -> new BrickItem());
   public static final DeferredHolder<Item, Item> YELLOW_BRICK = REGISTRY.register("yellow_brick", () -> new BrickItem());
   public static final DeferredHolder<Item, Item> CYAN_BRICK = REGISTRY.register("cyan_brick", () -> new BrickItem());
   public static final DeferredHolder<Item, Item> BROWN_BRICK = REGISTRY.register("brown_brick", () -> new BrickItem());
   public static final DeferredHolder<Item, Item> SIMPLE_WOODWORKING_BENCH = REGISTRY.register(
      "simple_woodworking_bench", () -> new WoodworkingBenchItem((Block)ModBlocks.SIMPLE_WOODWORKING_BENCH.get())
   );
   public static final DeferredHolder<Item, Item> WHITE_BRICK_WALL = block(ModBlocks.WHITE_BRICK_WALL);
   public static final DeferredHolder<Item, Item> RED_BRICK_WALL = block(ModBlocks.RED_BRICK_WALL);
   public static final DeferredHolder<Item, Item> YELLOW_BRICK_WALL = block(ModBlocks.YELLOW_BRICK_WALL);
   public static final DeferredHolder<Item, Item> CYAN_BRICK_WALL = block(ModBlocks.CYAN_BRICK_WALL);
   public static final DeferredHolder<Item, Item> BROWN_BRICK_WALL = block(ModBlocks.BROWN_BRICK_WALL);
   public static final DeferredHolder<Item, Item> DISGUISE_BLOCK = REGISTRY.register(
      "disguise_block", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_BLOCK.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_STAIR = REGISTRY.register(
      "disguise_stair", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_STAIR.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_HORIZONTAL_HALF_SLAB = REGISTRY.register(
      "disguise_horizontal_half_slab", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_HORIZONTAL_HALF_SLAB.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_VERTICAL_HALF_SLAB = REGISTRY.register(
      "disguise_vertical_half_slab", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_VERTICAL_HALF_SLAB.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_HORIZONTAL_QUARTER_SLAB = REGISTRY.register(
      "disguise_horizontal_quarter_slab", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_HORIZONTAL_QUARTER_SLAB.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_VERTICAL_QUARTER_SLAB = REGISTRY.register(
      "disguise_vertical_quarter_slab", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_VERTICAL_QUARTER_SLAB.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_HORIZONTAL_ONE_EIGHTH_SLAB = REGISTRY.register(
      "disguise_horizontal_one_eighth_slab", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_HORIZONTAL_ONE_EIGHTH_SLAB.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_VERTICAL_ONE_EIGHTH_SLAB = REGISTRY.register(
      "disguise_vertical_one_eighth_slab", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_VERTICAL_ONE_EIGHTH_SLAB.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_HORIZONTAL_ONE_SIXTEENTH_SLAB = REGISTRY.register(
      "disguise_horizontal_one_sixteenth_slab", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_HORIZONTAL_ONE_SIXTEENTH_SLAB.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_VERTICAL_ONE_SIXTEENTH_SLAB = REGISTRY.register(
      "disguise_vertical_one_sixteenth_slab", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_VERTICAL_ONE_SIXTEENTH_SLAB.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_PILLAR_12_12_16 = REGISTRY.register(
      "disguise_pillar_12_12_16", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_PILLAR_12_12_16.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_PILLAR_8_8_16 = REGISTRY.register(
      "disguise_pillar_8_8_16", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_PILLAR_8_8_16.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_PILLAR_4_4_16 = REGISTRY.register(
      "disguise_pillar_4_4_16", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_PILLAR_4_4_16.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_PILLAR_2_2_16 = REGISTRY.register(
      "disguise_pillar_2_2_16", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_PILLAR_2_2_16.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_BLOCK_NORMAL = REGISTRY.register(
      "disguise_block_normal", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_BLOCK_NORMAL.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_STAIR_NORMAL = REGISTRY.register(
      "disguise_stair_normal", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_STAIR_NORMAL.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_HORIZONTAL_HALF_SLAB_NORMAL = REGISTRY.register(
      "disguise_horizontal_half_slab_normal", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_HORIZONTAL_HALF_SLAB_NORMAL.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_VERTICAL_HALF_SLAB_NORMAL = REGISTRY.register(
      "disguise_vertical_half_slab_normal", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_VERTICAL_HALF_SLAB_NORMAL.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_HORIZONTAL_QUARTER_SLAB_NORMAL = REGISTRY.register(
      "disguise_horizontal_quarter_slab_normal", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_HORIZONTAL_QUARTER_SLAB_NORMAL.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_VERTICAL_QUARTER_SLAB_NORMAL = REGISTRY.register(
      "disguise_vertical_quarter_slab_normal", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_VERTICAL_QUARTER_SLAB_NORMAL.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_HORIZONTAL_ONE_EIGHTH_SLAB_NORMAL = REGISTRY.register(
      "disguise_horizontal_one_eighth_slab_normal", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_HORIZONTAL_ONE_EIGHTH_SLAB_NORMAL.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_VERTICAL_ONE_EIGHTH_SLAB_NORMAL = REGISTRY.register(
      "disguise_vertical_one_eighth_slab_normal", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_VERTICAL_ONE_EIGHTH_SLAB_NORMAL.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_HORIZONTAL_ONE_SIXTEENTH_SLAB_NORMAL = REGISTRY.register(
      "disguise_horizontal_one_sixteenth_slab_normal", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_HORIZONTAL_ONE_SIXTEENTH_SLAB_NORMAL.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_VERTICAL_ONE_SIXTEENTH_SLAB_NORMAL = REGISTRY.register(
      "disguise_vertical_one_sixteenth_slab_normal", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_VERTICAL_ONE_SIXTEENTH_SLAB_NORMAL.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_PILLAR_12_12_16_NORMAL = REGISTRY.register(
      "disguise_pillar_12_12_16_normal", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_PILLAR_12_12_16_NORMAL.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_PILLAR_8_8_16_NORMAL = REGISTRY.register(
      "disguise_pillar_8_8_16_normal", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_PILLAR_8_8_16_NORMAL.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_PILLAR_4_4_16_NORMAL = REGISTRY.register(
      "disguise_pillar_4_4_16_normal", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_PILLAR_4_4_16_NORMAL.get())
   );
   public static final DeferredHolder<Item, Item> DISGUISE_PILLAR_2_2_16_NORMAL = REGISTRY.register(
      "disguise_pillar_2_2_16_normal", () -> new DisguiseBlockItem((Block)ModBlocks.DISGUISE_PILLAR_2_2_16_NORMAL.get())
   );
   public static final DeferredHolder<Item, Item> COMMON_OAK_FLOOR = makeFloorBlock4(ModBlocks.COMMON_OAK_FLOOR);
   public static final DeferredHolder<Item, Item> COMMON_SPRUCE_FLOOR = makeFloorBlock4(ModBlocks.COMMON_SPRUCE_FLOOR);
   public static final DeferredHolder<Item, Item> COMMON_BIRCH_FLOOR = makeFloorBlock4(ModBlocks.COMMON_BIRCH_FLOOR);
   public static final DeferredHolder<Item, Item> COMMON_JUNGLE_FLOOR = makeFloorBlock4(ModBlocks.COMMON_JUNGLE_FLOOR);
   public static final DeferredHolder<Item, Item> COMMON_ACACIA_FLOOR = makeFloorBlock4(ModBlocks.COMMON_ACACIA_FLOOR);
   public static final DeferredHolder<Item, Item> COMMON_DARK_OAK_FLOOR = makeFloorBlock4(ModBlocks.COMMON_DARK_OAK_FLOOR);
   public static final DeferredHolder<Item, Item> FISHBONE_OAK_FLOOR = makeFloorBlock4(ModBlocks.FISHBONE_OAK_FLOOR);
   public static final DeferredHolder<Item, Item> FISHBONE_SPRUCE_FLOOR = makeFloorBlock4(ModBlocks.FISHBONE_SPRUCE_FLOOR);
   public static final DeferredHolder<Item, Item> FISHBONE_BIRCH_FLOOR = makeFloorBlock4(ModBlocks.FISHBONE_BIRCH_FLOOR);
   public static final DeferredHolder<Item, Item> FISHBONE_JUNGLE_FLOOR = makeFloorBlock4(ModBlocks.FISHBONE_JUNGLE_FLOOR);
   public static final DeferredHolder<Item, Item> FISHBONE_DARK_OAK_FLOOR = makeFloorBlock4(ModBlocks.FISHBONE_DARK_OAK_FLOOR);
   public static final DeferredHolder<Item, Item> FISHBONE_ACACIA_FLOOR = makeFloorBlock4(ModBlocks.FISHBONE_ACACIA_FLOOR);
   public static final DeferredHolder<Item, Item> BASE_TILE = block(ModBlocks.BASE_TILE);
   public static final DeferredHolder<Item, Item> TILE_A_001 = block(ModBlocks.TILE_A_001);
   public static final DeferredHolder<Item, Item> TILE_A_002 = block(ModBlocks.TILE_A_002);
   public static final DeferredHolder<Item, Item> TILE_A_003 = block(ModBlocks.TILE_A_003);
   public static final DeferredHolder<Item, Item> TILE_A_004 = block(ModBlocks.TILE_A_004);
   public static final DeferredHolder<Item, Item> TILE_A_005 = block(ModBlocks.TILE_A_005);
   public static final DeferredHolder<Item, Item> TILE_A_006 = makeMultiTextureTileBlock(ModBlocks.TILE_A_006, 8);
   public static final DeferredHolder<Item, Item> TILE_A_007 = makeMultiTextureTileBlock(ModBlocks.TILE_A_007, 8);
   public static final DeferredHolder<Item, Item> TILE_A_008 = makeMultiTextureTileBlock(ModBlocks.TILE_A_008, 2);
   public static final DeferredHolder<Item, Item> TILE_A_009 = makeMultiTextureTileBlock(ModBlocks.TILE_A_009, 6);
   public static final DeferredHolder<Item, Item> TILE_A_010 = makeMultiTextureTileBlock(ModBlocks.TILE_A_010, 8);
   public static final DeferredHolder<Item, Item> TILE_A_011 = makeMultiTextureTileBlock(ModBlocks.TILE_A_011, 8);
   public static final DeferredHolder<Item, Item> TILE_A_012 = makeMultiTextureTileBlock(ModBlocks.TILE_A_012, 6);
   public static final DeferredHolder<Item, Item> TILE_A_013 = makeMultiTextureTileBlock(ModBlocks.TILE_A_013, 2);
   public static final DeferredHolder<Item, Item> TILE_A_014 = makeMultiTextureTileBlock(ModBlocks.TILE_A_014, 2);
   public static final DeferredHolder<Item, Item> TILE_A_015 = makeMultiTextureTileBlock(ModBlocks.TILE_A_015, 6);
   public static final DeferredHolder<Item, Item> TILE_B_001 = block(ModBlocks.TILE_B_001);
   public static final DeferredHolder<Item, Item> TILE_B_002 = block(ModBlocks.TILE_B_002);
   public static final DeferredHolder<Item, Item> TILE_B_003 = block(ModBlocks.TILE_B_003);
   public static final DeferredHolder<Item, Item> TILE_B_004 = block(ModBlocks.TILE_B_004);
   public static final DeferredHolder<Item, Item> TILE_B_005 = block(ModBlocks.TILE_B_005);
   public static final DeferredHolder<Item, Item> TILE_B_006 = block(ModBlocks.TILE_B_006);
   public static final DeferredHolder<Item, Item> TILE_B_007 = block(ModBlocks.TILE_B_007);
   public static final DeferredHolder<Item, Item> TILE_B_008 = block(ModBlocks.TILE_B_008);
   public static final DeferredHolder<Item, Item> TILE_B_009 = block(ModBlocks.TILE_B_009);
   public static final DeferredHolder<Item, Item> TILE_B_010 = block(ModBlocks.TILE_B_010);
   public static final DeferredHolder<Item, Item> TILE_B_011 = makeMultiTextureTile2Block(ModBlocks.TILE_B_011);
   public static final DeferredHolder<Item, Item> TILE_B_012 = makeMultiTextureTile2Block(ModBlocks.TILE_B_012);
   public static final DeferredHolder<Item, Item> TILE_B_013 = block(ModBlocks.TILE_B_013);
   public static final DeferredHolder<Item, Item> TILE_B_014 = block(ModBlocks.TILE_B_014);
   public static final DeferredHolder<Item, Item> TILE_B_015 = block(ModBlocks.TILE_B_015);
   public static final DeferredHolder<Item, Item> TILE_C_001 = block(ModBlocks.TILE_C_001);
   public static final DeferredHolder<Item, Item> TILE_C_002 = block(ModBlocks.TILE_C_002);
   public static final DeferredHolder<Item, Item> TILE_C_003 = block(ModBlocks.TILE_C_003);
   public static final DeferredHolder<Item, Item> TILE_C_004 = block(ModBlocks.TILE_C_004);
   public static final DeferredHolder<Item, Item> TILE_D_001 = block(ModBlocks.TILE_D_001);
   public static final DeferredHolder<Item, Item> TILE_D_002 = block(ModBlocks.TILE_D_002);
   public static final DeferredHolder<Item, Item> TILE_D_003 = block(ModBlocks.TILE_D_003);
   public static final DeferredHolder<Item, Item> TILE_D_004 = block(ModBlocks.TILE_D_004);
   public static final DeferredHolder<Item, Item> YELLOW_QUARTZ = REGISTRY.register("yellow_quartz", () -> new QuartzItem());
   public static final DeferredHolder<Item, Item> BROWN_QUARTZ = REGISTRY.register("brown_quartz", () -> new QuartzItem());
   public static final DeferredHolder<Item, Item> YELLOW_SMOOTH_QUARTZ = block(ModBlocks.YELLOW_SMOOTH_QUARTZ);
   public static final DeferredHolder<Item, Item> YELLOW_QUARTZ_BRICK = block(ModBlocks.YELLOW_QUARTZ_BRICK);
   public static final DeferredHolder<Item, Item> YELLOW_CHISELED_QUARTZ_BLOCK = block(ModBlocks.YELLOW_CHISELED_QUARTZ_BLOCK);
   public static final DeferredHolder<Item, Item> YELLOW_QUARTZ_PILLAR = block(ModBlocks.YELLOW_QUARTZ_PILLAR);
   public static final DeferredHolder<Item, Item> YELLOW_QUARTZ_BLOCK = block(ModBlocks.YELLOW_QUARTZ_BLOCK);
   public static final DeferredHolder<Item, Item> BROWN_QUARTZ_BLOCK = block(ModBlocks.BROWN_QUARTZ_BLOCK);
   public static final DeferredHolder<Item, Item> BROWN_SMOOTH_QUARTZ = block(ModBlocks.BROWN_SMOOTH_QUARTZ);
   public static final DeferredHolder<Item, Item> BROWN_QUARTZ_BRICK = block(ModBlocks.BROWN_QUARTZ_BRICK);
   public static final DeferredHolder<Item, Item> BROWN_CHISELED_QUARTZ_BLOCK = block(ModBlocks.BROWN_CHISELED_QUARTZ_BLOCK);
   public static final DeferredHolder<Item, Item> BROWN_QUARTZ_PILLAR = block(ModBlocks.BROWN_QUARTZ_PILLAR);
   public static final DeferredHolder<Item, Item> GROUT = block(ModBlocks.GROUT);
   public static final DeferredHolder<Item, Item> WHITE_PAINTED_WALL = block(ModBlocks.WHITE_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> LIGHT_GRAY_PAINTED_WALL = block(ModBlocks.LIGHT_GRAY_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> GRAY_PAINTED_WALL = block(ModBlocks.GRAY_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> BLACK_PAINTED_WALL = block(ModBlocks.BLACK_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> BROWN_PAINTED_WALL = block(ModBlocks.BROWN_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> RED_PAINTED_WALL = block(ModBlocks.RED_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> ORANGE_PAINTED_WALL = block(ModBlocks.ORANGE_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> YELLOW_PAINTED_WALL = block(ModBlocks.YELLOW_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> LIME_PAINTED_WALL = block(ModBlocks.LIME_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> GREEN_PAINTED_WALL = block(ModBlocks.GREEN_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> CYAN_PAINTED_WALL = block(ModBlocks.CYAN_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> LIGHT_BLUE_PAINTED_WALL = block(ModBlocks.LIGHT_BLUE_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> BLUE_PAINTED_WALL = block(ModBlocks.BLUE_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> PURPLE_PAINTED_WALL = block(ModBlocks.PURPLE_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> MAGENTA_PAINTED_WALL = block(ModBlocks.MAGENTA_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> PINK_PAINTED_WALL = block(ModBlocks.PINK_PAINTED_WALL);
   public static final DeferredHolder<Item, Item> OFFICE_CHAIR_WHITE = block(ModBlocks.OFFICE_CHAIR_WHITE);
   public static final DeferredHolder<Item, Item> OFFICE_CHAIR_GRAY = block(ModBlocks.OFFICE_CHAIR_GRAY);
   public static final DeferredHolder<Item, Item> OFFICE_CHAIR_BLACK = block(ModBlocks.OFFICE_CHAIR_BLACK);
   public static final DeferredHolder<Item, Item> DOWNLIGHT = REGISTRY.register("downlight", () -> new DownlightItem((Block)ModBlocks.DOWNLIGHT.get()));
   public static final DeferredHolder<Item, Item> OLD_OAK_FLOOR_1 = makeOldFloorBlock(ModBlocks.OLD_OAK_FLOOR_1);
   public static final DeferredHolder<Item, Item> OLD_OAK_FLOOR_2 = makeOldFloorBlock(ModBlocks.OLD_OAK_FLOOR_2);
   public static final DeferredHolder<Item, Item> OLD_OAK_FLOOR_3 = makeOldFloorBlock(ModBlocks.OLD_OAK_FLOOR_3);
   public static final DeferredHolder<Item, Item> OLD_OAK_FLOOR_4 = makeOldFloorBlock(ModBlocks.OLD_OAK_FLOOR_4);
   public static final DeferredHolder<Item, Item> OLD_SPRUCE_FLOOR_1 = makeOldFloorBlock(ModBlocks.OLD_SPRUCE_FLOOR_1);
   public static final DeferredHolder<Item, Item> OLD_SPRUCE_FLOOR_2 = makeOldFloorBlock(ModBlocks.OLD_SPRUCE_FLOOR_2);
   public static final DeferredHolder<Item, Item> OLD_SPRUCE_FLOOR_3 = makeOldFloorBlock(ModBlocks.OLD_SPRUCE_FLOOR_3);
   public static final DeferredHolder<Item, Item> OLD_SPRUCE_FLOOR_4 = makeOldFloorBlock(ModBlocks.OLD_SPRUCE_FLOOR_4);
   public static final DeferredHolder<Item, Item> OLD_BIRCH_FLOOR_1 = makeOldFloorBlock(ModBlocks.OLD_BIRCH_FLOOR_1);
   public static final DeferredHolder<Item, Item> OLD_BIRCH_FLOOR_2 = makeOldFloorBlock(ModBlocks.OLD_BIRCH_FLOOR_2);
   public static final DeferredHolder<Item, Item> OLD_BIRCH_FLOOR_3 = makeOldFloorBlock(ModBlocks.OLD_BIRCH_FLOOR_3);
   public static final DeferredHolder<Item, Item> OLD_BIRCH_FLOOR_4 = makeOldFloorBlock(ModBlocks.OLD_BIRCH_FLOOR_4);
   public static final DeferredHolder<Item, Item> OLD_JUNGLE_FLOOR_1 = makeOldFloorBlock(ModBlocks.OLD_JUNGLE_FLOOR_1);
   public static final DeferredHolder<Item, Item> OLD_JUNGLE_FLOOR_2 = makeOldFloorBlock(ModBlocks.OLD_JUNGLE_FLOOR_2);
   public static final DeferredHolder<Item, Item> OLD_JUNGLE_FLOOR_3 = makeOldFloorBlock(ModBlocks.OLD_JUNGLE_FLOOR_3);
   public static final DeferredHolder<Item, Item> OLD_JUNGLE_FLOOR_4 = makeOldFloorBlock(ModBlocks.OLD_JUNGLE_FLOOR_4);
   public static final DeferredHolder<Item, Item> OLD_ACACIA_FLOOR_1 = makeOldFloorBlock(ModBlocks.OLD_ACACIA_FLOOR_1);
   public static final DeferredHolder<Item, Item> OLD_ACACIA_FLOOR_2 = makeOldFloorBlock(ModBlocks.OLD_ACACIA_FLOOR_2);
   public static final DeferredHolder<Item, Item> OLD_ACACIA_FLOOR_3 = makeOldFloorBlock(ModBlocks.OLD_ACACIA_FLOOR_3);
   public static final DeferredHolder<Item, Item> OLD_ACACIA_FLOOR_4 = makeOldFloorBlock(ModBlocks.OLD_ACACIA_FLOOR_4);
   public static final DeferredHolder<Item, Item> OLD_DARK_OAK_FLOOR_1 = makeOldFloorBlock(ModBlocks.OLD_DARK_OAK_FLOOR_1);
   public static final DeferredHolder<Item, Item> OLD_DARK_OAK_FLOOR_2 = makeOldFloorBlock(ModBlocks.OLD_DARK_OAK_FLOOR_2);
   public static final DeferredHolder<Item, Item> OLD_DARK_OAK_FLOOR_3 = makeOldFloorBlock(ModBlocks.OLD_DARK_OAK_FLOOR_3);
   public static final DeferredHolder<Item, Item> OLD_DARK_OAK_FLOOR_4 = makeOldFloorBlock(ModBlocks.OLD_DARK_OAK_FLOOR_4);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_OAK_FLOOR_1 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_OAK_FLOOR_1);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_OAK_FLOOR_2 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_OAK_FLOOR_2);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_OAK_FLOOR_3 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_OAK_FLOOR_3);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_OAK_FLOOR_4 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_OAK_FLOOR_4);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_SPRUCE_FLOOR_1 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_SPRUCE_FLOOR_1);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_SPRUCE_FLOOR_2 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_SPRUCE_FLOOR_2);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_SPRUCE_FLOOR_3 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_SPRUCE_FLOOR_3);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_SPRUCE_FLOOR_4 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_SPRUCE_FLOOR_4);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_BIRCH_FLOOR_1 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_BIRCH_FLOOR_1);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_BIRCH_FLOOR_2 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_BIRCH_FLOOR_2);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_BIRCH_FLOOR_3 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_BIRCH_FLOOR_3);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_BIRCH_FLOOR_4 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_BIRCH_FLOOR_4);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_JUNGLE_FLOOR_1 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_JUNGLE_FLOOR_1);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_JUNGLE_FLOOR_2 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_JUNGLE_FLOOR_2);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_JUNGLE_FLOOR_3 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_JUNGLE_FLOOR_3);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_JUNGLE_FLOOR_4 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_JUNGLE_FLOOR_4);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_ACACIA_FLOOR_1 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_ACACIA_FLOOR_1);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_ACACIA_FLOOR_2 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_ACACIA_FLOOR_2);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_ACACIA_FLOOR_3 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_ACACIA_FLOOR_3);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_ACACIA_FLOOR_4 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_ACACIA_FLOOR_4);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_DARK_OAK_FLOOR_1 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_DARK_OAK_FLOOR_1);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_DARK_OAK_FLOOR_2 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_DARK_OAK_FLOOR_2);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_DARK_OAK_FLOOR_3 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_DARK_OAK_FLOOR_3);
   public static final DeferredHolder<Item, Item> OLD_FISHBONE_DARK_OAK_FLOOR_4 = makeOldFloorBlock(ModBlocks.OLD_FISHBONE_DARK_OAK_FLOOR_4);

   private static DeferredHolder<Item, Item> block(DeferredHolder<Block, Block> block) {
      return REGISTRY.register(block.getId().getPath(), () -> new BlockItem((Block)block.get(), new Properties()));
   }

   private static DeferredHolder<Item, Item> makeFloorBlock4(DeferredHolder<Block, Block> block) {
      return REGISTRY.register(block.getId().getPath(), () -> new FloorBlock4Item((Block)block.get()));
   }

   private static DeferredHolder<Item, Item> makeOldFloorBlock(DeferredHolder<Block, Block> block) {
      return REGISTRY.register(block.getId().getPath(), () -> new OldFloorBlockItem((Block)block.get()));
   }

   private static DeferredHolder<Item, Item> makeMultiTextureTileBlock(DeferredHolder<Block, Block> block, int textureCount) {
      return REGISTRY.register(block.getId().getPath(), () -> new MultiTextureTileBlockItem((Block)block.get(), textureCount));
   }

   private static DeferredHolder<Item, Item> makeMultiTextureTile2Block(DeferredHolder<Block, Block> block) {
      return REGISTRY.register(block.getId().getPath(), () -> new MultiTextureTile2BlockItem((Block)block.get()));
   }
}
