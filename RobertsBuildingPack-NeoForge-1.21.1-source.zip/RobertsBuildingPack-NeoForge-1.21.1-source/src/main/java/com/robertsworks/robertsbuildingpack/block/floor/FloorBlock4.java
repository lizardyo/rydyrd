package com.robertsworks.robertsbuildingpack.block.floor;

import com.robertsworks.robertsbuildingpack.block.base.MultiTextureBlock;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;

public class FloorBlock4 extends MultiTextureBlock {
   public FloorBlock4() {
      super(Properties.ofFullCopy(Blocks.OAK_PLANKS));
   }

   @Override
   public int getTextureCount() {
      return 4;
   }

   @Override
   public int getPrevTexture(int currentTexture) {
      return currentTexture == 1 ? 4 : currentTexture - 1;
   }

   @Override
   public int getNextTexture(int currentTexture) {
      return currentTexture == 4 ? 1 : currentTexture + 1;
   }

   @Override
   public ItemStack getDropStack(BlockState state) {
      ItemStack stack = new ItemStack(this);
      int texture = this.getTextureValue(state);
      FloorBlock4Item.setPlacementMode(stack, texture);
      return stack;
   }
}
