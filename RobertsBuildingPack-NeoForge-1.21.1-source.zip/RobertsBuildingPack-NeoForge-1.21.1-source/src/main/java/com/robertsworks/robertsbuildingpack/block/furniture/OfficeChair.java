package com.robertsworks.robertsbuildingpack.block.furniture;

import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.VoxelShape;

public class OfficeChair extends AbstractChair {
   public static final MapCodec<OfficeChair> CODEC = MapCodec.unit(OfficeChair::new);

   @Override
   protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
      return CODEC;
   }

   @Override
   public VoxelShape getChairShape(BlockState state) {
      Direction facing = (Direction)state.getValue(FACING);
      return RBPHelper.getShapeByFacing(box(2.0, 0.0, 3.0, 13.0, 9.0, 13.0), facing);
   }
}
