package com.robertsworks.robertsbuildingpack.util.other;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.crafting.Ingredient;

public record IngredientWithCount(Ingredient ingredient, int count) {
   public static final Codec<IngredientWithCount> CODEC = RecordCodecBuilder.create(
      instance -> instance.group(
            Ingredient.CODEC.fieldOf("ingredient").forGetter(IngredientWithCount::ingredient),
            Codec.INT.optionalFieldOf("count", 1).forGetter(IngredientWithCount::count)
         )
         .apply(instance, IngredientWithCount::new)
   );

   public static final StreamCodec<RegistryFriendlyByteBuf, IngredientWithCount> STREAM_CODEC = StreamCodec.composite(
      Ingredient.CONTENTS_STREAM_CODEC,
      IngredientWithCount::ingredient,
      ByteBufCodecs.VAR_INT,
      IngredientWithCount::count,
      IngredientWithCount::new
   );
}
