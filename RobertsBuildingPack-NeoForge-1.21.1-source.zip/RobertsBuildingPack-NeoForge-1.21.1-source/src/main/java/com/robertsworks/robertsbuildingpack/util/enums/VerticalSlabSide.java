package com.robertsworks.robertsbuildingpack.util.enums;

import net.minecraft.util.StringRepresentable;

public enum VerticalSlabSide implements StringRepresentable {
   FRONT("front"),
   BACK("back");

   private final String name;

   private VerticalSlabSide(String name) {
      this.name = name;
   }

   @Override
   public String toString() {
      return this.name;
   }

   public String getSerializedName() {
      return this.name;
   }
}
