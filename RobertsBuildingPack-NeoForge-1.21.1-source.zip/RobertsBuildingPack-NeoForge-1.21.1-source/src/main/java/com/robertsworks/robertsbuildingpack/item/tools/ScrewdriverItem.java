package com.robertsworks.robertsbuildingpack.item.tools;

import net.minecraft.world.entity.LivingEntity;
import com.robertsworks.robertsbuildingpack.block.disguise.DisguiseBlockEntity;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.IDisguiseBlock;
import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import com.robertsworks.robertsbuildingpack.util.properties.RBPProperties;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

public class ScrewdriverItem extends AbstractBuildingTool {
   public static float DURABILITY_RATE = 1.0F;
   public static final int BASE_DAMAGE = 1;
   public static final float BASE_ATTACK_SPEED = 1.6F;

   public ScrewdriverItem(Tier tier, float damage, float attackSpeed) {
      super(tier, DURABILITY_RATE, damage, attackSpeed, new Properties());
   }

   public ScrewdriverItem(Tier tier) {
      this(tier, 1.0F, 1.6F);
   }

   public InteractionResult useOn(UseOnContext context) {
      Level level = context.getLevel();
      BlockPos pos = context.getClickedPos();
      BlockState state = level.getBlockState(pos);
      Block block = state.getBlock();
      boolean used = false;
      if (block instanceof IDisguiseBlock) {
         Boolean disguised = (Boolean)state.getValue(RBPProperties.DISGUISED);
         if (disguised && level.getBlockEntity(pos) instanceof DisguiseBlockEntity disguiseBE) {
            Player player = context.getPlayer();
            BlockState disguiseState = disguiseBE.getDisguiseState();
            RBPHelper.returnDisguiseItem(disguiseState, player, level);
            disguiseBE.setDisguiseState(null);
            BlockState newState = (BlockState)state.setValue(RBPProperties.DISGUISED, false);
            level.setBlock(pos, newState, 3);
            RBPHelper.playBlockSound(level, pos, SoundEvents.COMPARATOR_CLICK, 0.8F, 1.0F);
            used = true;
         }
      }

      if (used) {
         Player player = context.getPlayer();
         if (player != null) {
            context.getItemInHand().hurtAndBreak(1, player, LivingEntity.getSlotForHand(context.getHand()));
         }

         return InteractionResult.sidedSuccess(level.isClientSide);
      } else {
         return InteractionResult.PASS;
      }
   }

   public void appendHoverText(ItemStack stack, net.minecraft.world.item.Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
      super.appendHoverText(stack, context, tooltip, flag);
      if (!RBPHelper.isShiftKeyDown()) {
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.woodwork_tools_tip").withStyle(ChatFormatting.GRAY));
         tooltip.add(Component.literal(" "));
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.show_more_info").withStyle(ChatFormatting.GRAY));
      } else {
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.screwdriver_desc").withStyle(ChatFormatting.WHITE));
      }
   }

}
