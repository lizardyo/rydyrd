package com.robertsworks.robertsbuildingpack.util.other;

@FunctionalInterface
public interface DoubleConsumer<A, B> {
   void accept(A var1, B var2);
}
