package com.robertsworks.robertsbuildingpack.util.other;

import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class CustomResultSlot extends Slot {
   private DoubleConsumer<Player, ItemStack> beforeTake = null;

   public CustomResultSlot(Container container, int index, int x, int y) {
      super(container, index, x, y);
   }

   public CustomResultSlot(Container container, int index, int x, int y, DoubleConsumer<Player, ItemStack> beforeTake) {
      super(container, index, x, y);
      this.beforeTake = beforeTake;
   }

   public boolean mayPlace(ItemStack stack) {
      return false;
   }

   public void setBeforeTake(DoubleConsumer<Player, ItemStack> beforeTake) {
      this.beforeTake = beforeTake;
   }

   public void onTake(Player player, ItemStack stack) {
      if (this.beforeTake != null) {
         this.beforeTake.accept(player, stack);
      }

      super.onTake(player, stack);
   }
}
