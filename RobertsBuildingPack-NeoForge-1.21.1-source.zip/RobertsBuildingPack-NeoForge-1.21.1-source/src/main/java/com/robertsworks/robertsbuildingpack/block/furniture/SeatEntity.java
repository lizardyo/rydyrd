package com.robertsworks.robertsbuildingpack.block.furniture;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

public class SeatEntity extends Entity {
   public SeatEntity(EntityType<?> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public void tick() {
      super.tick();
      if (!this.level().isClientSide && this.getPassengers().isEmpty()) {
         this.discard();
      }
   }

   public boolean isPickable() {
      return false;
   }

   public boolean isInvisible() {
      return true;
   }

   protected void defineSynchedData(SynchedEntityData.Builder builder) {
   }

   protected void readAdditionalSaveData(CompoundTag p_20052_) {
   }

   protected void addAdditionalSaveData(CompoundTag p_20139_) {
   }
}
