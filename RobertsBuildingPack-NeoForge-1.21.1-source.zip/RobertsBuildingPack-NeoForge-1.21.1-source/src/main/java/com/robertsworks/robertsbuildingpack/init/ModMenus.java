package com.robertsworks.robertsbuildingpack.init;

import com.robertsworks.robertsbuildingpack.gui.WoodworkingBenchMenu;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModMenus {
   public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(BuiltInRegistries.MENU, "roberts_building_pack");

   public static final DeferredHolder<MenuType<?>, MenuType<WoodworkingBenchMenu>> WOODWORKING_BENCH = REGISTRY.register(
      "woodworking_bench", () -> IMenuTypeExtension.create((windowId, inv, data) -> {
            Level level = inv.player.level();
            BlockPos pos = data.readBlockPos();
            return new WoodworkingBenchMenu(windowId, inv, level, pos);
         })
   );
}
