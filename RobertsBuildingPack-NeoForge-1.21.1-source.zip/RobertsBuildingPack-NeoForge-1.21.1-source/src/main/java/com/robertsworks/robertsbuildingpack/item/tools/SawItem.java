package com.robertsworks.robertsbuildingpack.item.tools;

import net.minecraft.world.entity.LivingEntity;
import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import java.util.List;
import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.gameevent.GameEvent.Context;
import net.neoforged.neoforge.common.ItemAbility;
import net.neoforged.neoforge.common.ItemAbilities;

public class SawItem extends AbstractBuildingTool {
   public static float DURABILITY_RATE = 0.8F;
   public static final int BASE_DAMAGE = 3;
   public static final float BASE_ATTACK_SPEED = 1.6F;

   public SawItem(Tier tier, float damage, float attackSpeed) {
      super(tier, DURABILITY_RATE, damage, attackSpeed, new Properties());
   }

   public SawItem(Tier tier) {
      this(tier, 3.0F, 1.6F);
   }

   public InteractionResult useOn(UseOnContext context) {
      Level level = context.getLevel();
      BlockPos blockpos = context.getClickedPos();
      Player player = context.getPlayer();
      BlockState blockstate = level.getBlockState(blockpos);
      Optional<BlockState> optional = Optional.ofNullable(blockstate.getToolModifiedState(context, ItemAbilities.AXE_STRIP, false));
      ItemStack itemstack = context.getItemInHand();
      Optional<BlockState> optional3 = Optional.empty();
      if (optional.isPresent()) {
         level.playSound(player, blockpos, SoundEvents.AXE_STRIP, SoundSource.BLOCKS, 1.0F, 1.0F);
         optional3 = optional;
      }

      if (optional3.isPresent()) {
         if (player instanceof ServerPlayer) {
            CriteriaTriggers.ITEM_USED_ON_BLOCK.trigger((ServerPlayer)player, blockpos, itemstack);
         }

         level.setBlock(blockpos, optional3.get(), 11);
         level.gameEvent(GameEvent.BLOCK_CHANGE, blockpos, Context.of(player, optional3.get()));
         if (player != null) {
            itemstack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(context.getHand()));
         }

         return InteractionResult.sidedSuccess(level.isClientSide);
      } else {
         return InteractionResult.PASS;
      }
   }

   public boolean canPerformAction(ItemStack stack, ItemAbility toolAction) {
      return ItemAbilities.DEFAULT_AXE_ACTIONS.contains(toolAction);
   }

   public void appendHoverText(ItemStack stack, net.minecraft.world.item.Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
      super.appendHoverText(stack, context, tooltip, flag);
      if (!RBPHelper.isShiftKeyDown()) {
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.woodwork_tools_tip").withStyle(ChatFormatting.GRAY));
         tooltip.add(Component.literal(" "));
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.show_more_info").withStyle(ChatFormatting.GRAY));
      } else {
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.saw_desc").withStyle(ChatFormatting.WHITE));
      }
   }

}
