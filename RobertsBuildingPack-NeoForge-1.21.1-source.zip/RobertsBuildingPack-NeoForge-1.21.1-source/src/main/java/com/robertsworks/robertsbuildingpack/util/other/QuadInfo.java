package com.robertsworks.robertsbuildingpack.util.other;

import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.Direction;

public class QuadInfo {
   public VertexInfo[] vertices = new VertexInfo[]{new VertexInfo(), new VertexInfo(), new VertexInfo(), new VertexInfo()};
   public int tintIndex;
   public Direction direction;
   public TextureAtlasSprite sprite;
   public boolean shade;

   public void loadFromIntList(int[] vertexData) {
      if (vertexData.length != 32) {
         throw new IllegalArgumentException("\u9876\u70b9\u6570\u636e\u5f02\u5e38");
      } else {
         for (int i = 0; i < 4; i++) {
            int index = i * 8;
            this.vertices[i]
               .loadFromInt8(
                  vertexData[index],
                  vertexData[index + 1],
                  vertexData[index + 2],
                  vertexData[index + 3],
                  vertexData[index + 4],
                  vertexData[index + 5],
                  vertexData[index + 6],
                  vertexData[index + 7]
               );
         }
      }
   }

   public void loadFromBakedQuad(BakedQuad bakedQuad) {
      this.loadFromIntList(bakedQuad.getVertices());
      this.tintIndex = bakedQuad.getTintIndex();
      this.direction = bakedQuad.getDirection();
      this.sprite = bakedQuad.getSprite();
      this.shade = bakedQuad.isShade();
   }

   public int[] makeToIntList() {
      int[] res = new int[32];

      for (int i = 0; i < 4; i++) {
         int index = i * 8;
         int[] int8 = this.vertices[i].makeToInt8();

         for (int j = 0; j < 8; j++) {
            res[index + j] = int8[j];
         }
      }

      return res;
   }

   public BakedQuad makeBakedQuad() {
      return new BakedQuad(this.makeToIntList(), this.tintIndex, this.direction, this.sprite, this.shade);
   }

   public Size getSize() {
      float width = 0.0F;
      float height = 0.0F;
      if (this.vertices[0].x == this.vertices[1].x && this.vertices[0].x == this.vertices[2].x && this.vertices[0].x == this.vertices[3].x) {
         float min_y = RBPHelper.findMin(this.vertices[0].y, this.vertices[1].y, this.vertices[2].y, this.vertices[3].y);
         float max_y = RBPHelper.findMax(this.vertices[0].y, this.vertices[1].y, this.vertices[2].y, this.vertices[3].y);
         float min_z = RBPHelper.findMin(this.vertices[0].z, this.vertices[1].z, this.vertices[2].z, this.vertices[3].z);
         float max_z = RBPHelper.findMax(this.vertices[0].z, this.vertices[1].z, this.vertices[2].z, this.vertices[3].z);
         width = max_z - min_z;
         height = max_y - min_y;
      }

      if (this.vertices[0].y == this.vertices[1].y && this.vertices[0].y == this.vertices[2].y && this.vertices[0].y == this.vertices[3].y) {
         float min_x = RBPHelper.findMin(this.vertices[0].x, this.vertices[1].x, this.vertices[2].x, this.vertices[3].x);
         float max_x = RBPHelper.findMax(this.vertices[0].x, this.vertices[1].x, this.vertices[2].x, this.vertices[3].x);
         float min_z = RBPHelper.findMin(this.vertices[0].z, this.vertices[1].z, this.vertices[2].z, this.vertices[3].z);
         float max_z = RBPHelper.findMax(this.vertices[0].z, this.vertices[1].z, this.vertices[2].z, this.vertices[3].z);
         width = max_x - min_x;
         height = max_z - min_z;
      }

      if (this.vertices[0].z == this.vertices[1].z && this.vertices[0].z == this.vertices[2].z && this.vertices[0].z == this.vertices[3].z) {
         float min_x = RBPHelper.findMin(this.vertices[0].x, this.vertices[1].x, this.vertices[2].x, this.vertices[3].x);
         float max_x = RBPHelper.findMax(this.vertices[0].x, this.vertices[1].x, this.vertices[2].x, this.vertices[3].x);
         float min_y = RBPHelper.findMin(this.vertices[0].y, this.vertices[1].y, this.vertices[2].y, this.vertices[3].y);
         float max_y = RBPHelper.findMax(this.vertices[0].y, this.vertices[1].y, this.vertices[2].y, this.vertices[3].y);
         width = max_x - min_x;
         height = max_y - min_y;
      }

      return new Size(width, height);
   }

   public void offset(float offsetX, float offsetY, float offsetZ) {
      this.vertices[0].offset(offsetX, offsetY, offsetZ);
      this.vertices[1].offset(offsetX, offsetY, offsetZ);
      this.vertices[2].offset(offsetX, offsetY, offsetZ);
      this.vertices[3].offset(offsetX, offsetY, offsetZ);
   }

   public void offset(BlockOffset offset) {
      if (offset != null && offset.isMoved()) {
         float x = (float)offset.getX() / 16.0F;
         float y = (float)offset.getY() / 16.0F;
         float z = (float)offset.getZ() / 16.0F;
         this.offset(x, y, z);
      }
   }

   public void resetSprite(TextureAtlasSprite targetSprite, Direction side, Direction facing) {
      Size quadSize = this.getSize();
      float multipleU;
      float multipleV;
      if (facing != Direction.EAST && facing != Direction.WEST || side != Direction.UP && side != Direction.DOWN) {
         multipleU = quadSize.width();
         multipleV = quadSize.height();
      } else {
         multipleU = quadSize.height();
         multipleV = quadSize.width();
      }

      float max_u = RBPHelper.findMax(this.vertices[0].u, this.vertices[1].u, this.vertices[2].u, this.vertices[3].u);
      float max_v = RBPHelper.findMax(this.vertices[0].v, this.vertices[1].v, this.vertices[2].v, this.vertices[3].v);
      float u0 = targetSprite.getU0();
      float u1 = targetSprite.getU1();
      float v0 = targetSprite.getV0();
      float v1 = targetSprite.getV1();

      for (int i = 0; i < 4; i++) {
         VertexInfo vertex = this.vertices[i];
         vertex.u = vertex.u == max_u ? u0 + multipleU * (u1 - u0) : u0;
         vertex.v = vertex.v == max_v ? v0 + multipleV * (v1 - v0) : v0;
      }

      this.sprite = targetSprite;
   }

   public void setColor(int a, int r, int g, int b) {
      for (int i = 0; i < 4; i++) {
         this.vertices[i].color_a = a;
         this.vertices[i].color_r = r;
         this.vertices[i].color_g = g;
         this.vertices[i].color_b = b;
      }
   }

   public void setColor(int newColor) {
      int a = newColor >> 24 & 0xFF;
      int r = newColor >> 16 & 0xFF;
      int g = newColor >> 8 & 0xFF;
      int b = newColor & 0xFF;
      this.setColor(a, r, g, b);
   }
}
