package com.robertsworks.robertsbuildingpack.init;

import com.robertsworks.robertsbuildingpack.block.brickWall.BrickWall;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.DisguiseBlock;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.DisguiseHorizontalHalfSlab;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.DisguiseHorizontalOneEighthSlab;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.DisguiseHorizontalOneSixteenthSlab;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.DisguiseHorizontalQuarterSlab;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.DisguisePillar_12_12_16;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.DisguisePillar_2_2_16;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.DisguisePillar_4_4_16;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.DisguisePillar_8_8_16;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.DisguiseStair;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.DisguiseVerticalHalfSlab;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.DisguiseVerticalOneEighthSlab;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.DisguiseVerticalOneSixteenthSlab;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.DisguiseVerticalQuarterSlab;
import com.robertsworks.robertsbuildingpack.block.floor.FloorBlock4;
import com.robertsworks.robertsbuildingpack.block.floor.OldFloorBlock;
import com.robertsworks.robertsbuildingpack.block.furniture.Downlight;
import com.robertsworks.robertsbuildingpack.block.furniture.OfficeChair;
import com.robertsworks.robertsbuildingpack.block.other.GroutBlock;
import com.robertsworks.robertsbuildingpack.block.paintedWall.PaintedWallBlock;
import com.robertsworks.robertsbuildingpack.block.quartz.QuartzBlock;
import com.robertsworks.robertsbuildingpack.block.tile.MultiTextureTile2Block;
import com.robertsworks.robertsbuildingpack.block.tile.MultiTextureTileBlock;
import com.robertsworks.robertsbuildingpack.block.tile.SimpleTileBlock1;
import com.robertsworks.robertsbuildingpack.block.tile.SimpleTileBlock2;
import com.robertsworks.robertsbuildingpack.block.woodworkingBench.WoodworkingBench;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.minecraft.core.registries.BuiltInRegistries;
import net.neoforged.neoforge.registries.DeferredHolder;

public class ModBlocks {
   public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, "roberts_building_pack");
   public static final DeferredHolder<Block, Block> SIMPLE_WOODWORKING_BENCH = REGISTRY.register("simple_woodworking_bench", () -> new WoodworkingBench());
   public static final DeferredHolder<Block, Block> DISGUISE_BLOCK = REGISTRY.register("disguise_block", () -> new DisguiseBlock());
   public static final DeferredHolder<Block, Block> DISGUISE_STAIR = REGISTRY.register("disguise_stair", () -> new DisguiseStair());
   public static final DeferredHolder<Block, Block> DISGUISE_HORIZONTAL_HALF_SLAB = REGISTRY.register(
      "disguise_horizontal_half_slab", () -> new DisguiseHorizontalHalfSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_VERTICAL_HALF_SLAB = REGISTRY.register(
      "disguise_vertical_half_slab", () -> new DisguiseVerticalHalfSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_HORIZONTAL_QUARTER_SLAB = REGISTRY.register(
      "disguise_horizontal_quarter_slab", () -> new DisguiseHorizontalQuarterSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_VERTICAL_QUARTER_SLAB = REGISTRY.register(
      "disguise_vertical_quarter_slab", () -> new DisguiseVerticalQuarterSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_HORIZONTAL_ONE_EIGHTH_SLAB = REGISTRY.register(
      "disguise_horizontal_one_eighth_slab", () -> new DisguiseHorizontalOneEighthSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_VERTICAL_ONE_EIGHTH_SLAB = REGISTRY.register(
      "disguise_vertical_one_eighth_slab", () -> new DisguiseVerticalOneEighthSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_HORIZONTAL_ONE_SIXTEENTH_SLAB = REGISTRY.register(
      "disguise_horizontal_one_sixteenth_slab", () -> new DisguiseHorizontalOneSixteenthSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_VERTICAL_ONE_SIXTEENTH_SLAB = REGISTRY.register(
      "disguise_vertical_one_sixteenth_slab", () -> new DisguiseVerticalOneSixteenthSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_PILLAR_12_12_16 = REGISTRY.register("disguise_pillar_12_12_16", () -> new DisguisePillar_12_12_16());
   public static final DeferredHolder<Block, Block> DISGUISE_PILLAR_8_8_16 = REGISTRY.register("disguise_pillar_8_8_16", () -> new DisguisePillar_8_8_16());
   public static final DeferredHolder<Block, Block> DISGUISE_PILLAR_4_4_16 = REGISTRY.register("disguise_pillar_4_4_16", () -> new DisguisePillar_4_4_16());
   public static final DeferredHolder<Block, Block> DISGUISE_PILLAR_2_2_16 = REGISTRY.register("disguise_pillar_2_2_16", () -> new DisguisePillar_2_2_16());
   public static final DeferredHolder<Block, Block> DISGUISE_BLOCK_NORMAL = REGISTRY.register("disguise_block_normal", () -> new DisguiseBlock());
   public static final DeferredHolder<Block, Block> DISGUISE_STAIR_NORMAL = REGISTRY.register("disguise_stair_normal", () -> new DisguiseStair());
   public static final DeferredHolder<Block, Block> DISGUISE_HORIZONTAL_HALF_SLAB_NORMAL = REGISTRY.register(
      "disguise_horizontal_half_slab_normal", () -> new DisguiseHorizontalHalfSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_VERTICAL_HALF_SLAB_NORMAL = REGISTRY.register(
      "disguise_vertical_half_slab_normal", () -> new DisguiseVerticalHalfSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_HORIZONTAL_QUARTER_SLAB_NORMAL = REGISTRY.register(
      "disguise_horizontal_quarter_slab_normal", () -> new DisguiseHorizontalQuarterSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_VERTICAL_QUARTER_SLAB_NORMAL = REGISTRY.register(
      "disguise_vertical_quarter_slab_normal", () -> new DisguiseVerticalQuarterSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_HORIZONTAL_ONE_EIGHTH_SLAB_NORMAL = REGISTRY.register(
      "disguise_horizontal_one_eighth_slab_normal", () -> new DisguiseHorizontalOneEighthSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_VERTICAL_ONE_EIGHTH_SLAB_NORMAL = REGISTRY.register(
      "disguise_vertical_one_eighth_slab_normal", () -> new DisguiseVerticalOneEighthSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_HORIZONTAL_ONE_SIXTEENTH_SLAB_NORMAL = REGISTRY.register(
      "disguise_horizontal_one_sixteenth_slab_normal", () -> new DisguiseHorizontalOneSixteenthSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_VERTICAL_ONE_SIXTEENTH_SLAB_NORMAL = REGISTRY.register(
      "disguise_vertical_one_sixteenth_slab_normal", () -> new DisguiseVerticalOneSixteenthSlab()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_PILLAR_12_12_16_NORMAL = REGISTRY.register(
      "disguise_pillar_12_12_16_normal", () -> new DisguisePillar_12_12_16()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_PILLAR_8_8_16_NORMAL = REGISTRY.register(
      "disguise_pillar_8_8_16_normal", () -> new DisguisePillar_8_8_16()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_PILLAR_4_4_16_NORMAL = REGISTRY.register(
      "disguise_pillar_4_4_16_normal", () -> new DisguisePillar_4_4_16()
   );
   public static final DeferredHolder<Block, Block> DISGUISE_PILLAR_2_2_16_NORMAL = REGISTRY.register(
      "disguise_pillar_2_2_16_normal", () -> new DisguisePillar_2_2_16()
   );
   public static final DeferredHolder<Block, Block> WHITE_BRICK_WALL = REGISTRY.register("white_brick_wall", () -> new BrickWall());
   public static final DeferredHolder<Block, Block> RED_BRICK_WALL = REGISTRY.register("red_brick_wall", () -> new BrickWall());
   public static final DeferredHolder<Block, Block> YELLOW_BRICK_WALL = REGISTRY.register("yellow_brick_wall", () -> new BrickWall());
   public static final DeferredHolder<Block, Block> CYAN_BRICK_WALL = REGISTRY.register("cyan_brick_wall", () -> new BrickWall());
   public static final DeferredHolder<Block, Block> BROWN_BRICK_WALL = REGISTRY.register("brown_brick_wall", () -> new BrickWall());
   public static final DeferredHolder<Block, Block> COMMON_OAK_FLOOR = REGISTRY.register("common_oak_floor", () -> new FloorBlock4());
   public static final DeferredHolder<Block, Block> COMMON_SPRUCE_FLOOR = REGISTRY.register("common_spruce_floor", () -> new FloorBlock4());
   public static final DeferredHolder<Block, Block> COMMON_BIRCH_FLOOR = REGISTRY.register("common_birch_floor", () -> new FloorBlock4());
   public static final DeferredHolder<Block, Block> COMMON_JUNGLE_FLOOR = REGISTRY.register("common_jungle_floor", () -> new FloorBlock4());
   public static final DeferredHolder<Block, Block> COMMON_ACACIA_FLOOR = REGISTRY.register("common_acacia_floor", () -> new FloorBlock4());
   public static final DeferredHolder<Block, Block> COMMON_DARK_OAK_FLOOR = REGISTRY.register("common_dark_oak_floor", () -> new FloorBlock4());
   public static final DeferredHolder<Block, Block> FISHBONE_OAK_FLOOR = REGISTRY.register("fishbone_oak_floor", () -> new FloorBlock4());
   public static final DeferredHolder<Block, Block> FISHBONE_SPRUCE_FLOOR = REGISTRY.register("fishbone_spruce_floor", () -> new FloorBlock4());
   public static final DeferredHolder<Block, Block> FISHBONE_BIRCH_FLOOR = REGISTRY.register("fishbone_birch_floor", () -> new FloorBlock4());
   public static final DeferredHolder<Block, Block> FISHBONE_JUNGLE_FLOOR = REGISTRY.register("fishbone_jungle_floor", () -> new FloorBlock4());
   public static final DeferredHolder<Block, Block> FISHBONE_DARK_OAK_FLOOR = REGISTRY.register("fishbone_dark_oak_floor", () -> new FloorBlock4());
   public static final DeferredHolder<Block, Block> FISHBONE_ACACIA_FLOOR = REGISTRY.register("fishbone_acacia_floor", () -> new FloorBlock4());
   public static final DeferredHolder<Block, Block> BASE_TILE = REGISTRY.register("base_tile", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_A_001 = REGISTRY.register("tile_a_1", () -> new SimpleTileBlock2());
   public static final DeferredHolder<Block, Block> TILE_A_002 = REGISTRY.register("tile_a_2", () -> new SimpleTileBlock2());
   public static final DeferredHolder<Block, Block> TILE_A_003 = REGISTRY.register("tile_a_3", () -> new SimpleTileBlock2());
   public static final DeferredHolder<Block, Block> TILE_A_004 = REGISTRY.register("tile_a_4", () -> new SimpleTileBlock2());
   public static final DeferredHolder<Block, Block> TILE_A_005 = REGISTRY.register("tile_a_5", () -> new SimpleTileBlock2());
   public static final DeferredHolder<Block, Block> TILE_A_006 = REGISTRY.register("tile_a_006", () -> new MultiTextureTileBlock(8));
   public static final DeferredHolder<Block, Block> TILE_A_007 = REGISTRY.register("tile_a_007", () -> new MultiTextureTileBlock(8));
   public static final DeferredHolder<Block, Block> TILE_A_008 = REGISTRY.register("tile_a_008", () -> new MultiTextureTileBlock(2));
   public static final DeferredHolder<Block, Block> TILE_A_009 = REGISTRY.register("tile_a_009", () -> new MultiTextureTileBlock(6));
   public static final DeferredHolder<Block, Block> TILE_A_010 = REGISTRY.register("tile_a_010", () -> new MultiTextureTileBlock(8));
   public static final DeferredHolder<Block, Block> TILE_A_011 = REGISTRY.register("tile_a_011", () -> new MultiTextureTileBlock(8));
   public static final DeferredHolder<Block, Block> TILE_A_012 = REGISTRY.register("tile_a_012", () -> new MultiTextureTileBlock(6));
   public static final DeferredHolder<Block, Block> TILE_A_013 = REGISTRY.register("tile_a_013", () -> new MultiTextureTileBlock(2));
   public static final DeferredHolder<Block, Block> TILE_A_014 = REGISTRY.register("tile_a_014", () -> new MultiTextureTileBlock(2));
   public static final DeferredHolder<Block, Block> TILE_A_015 = REGISTRY.register("tile_a_015", () -> new MultiTextureTileBlock(6));
   public static final DeferredHolder<Block, Block> TILE_B_001 = REGISTRY.register("tile_b_1", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_B_002 = REGISTRY.register("tile_b_2", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_B_003 = REGISTRY.register("tile_b_3", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_B_004 = REGISTRY.register("tile_b_4", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_B_005 = REGISTRY.register("tile_b_5", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_B_006 = REGISTRY.register("tile_b_6", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_B_007 = REGISTRY.register("tile_b_7", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_B_008 = REGISTRY.register("tile_b_008", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_B_009 = REGISTRY.register("tile_b_009", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_B_010 = REGISTRY.register("tile_b_010", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_B_011 = REGISTRY.register("tile_b_011", () -> new MultiTextureTile2Block());
   public static final DeferredHolder<Block, Block> TILE_B_012 = REGISTRY.register("tile_b_012", () -> new MultiTextureTile2Block());
   public static final DeferredHolder<Block, Block> TILE_B_013 = REGISTRY.register("tile_b_013", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_B_014 = REGISTRY.register("tile_b_014", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_B_015 = REGISTRY.register("tile_b_015", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_C_001 = REGISTRY.register("tile_c_1", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_C_002 = REGISTRY.register("tile_c_002", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_C_003 = REGISTRY.register("tile_c_3", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_C_004 = REGISTRY.register("tile_c_4", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_D_001 = REGISTRY.register("tile_d_1", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_D_002 = REGISTRY.register("tile_d_2", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_D_003 = REGISTRY.register("tile_d_3", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> TILE_D_004 = REGISTRY.register("tile_d_4", () -> new SimpleTileBlock1());
   public static final DeferredHolder<Block, Block> YELLOW_SMOOTH_QUARTZ = REGISTRY.register("yellow_smooth_quartz", () -> new QuartzBlock());
   public static final DeferredHolder<Block, Block> YELLOW_QUARTZ_BRICK = REGISTRY.register("yellow_quartz_brick", () -> new QuartzBlock());
   public static final DeferredHolder<Block, Block> YELLOW_CHISELED_QUARTZ_BLOCK = REGISTRY.register("yellow_chiseled_quartz_block", () -> new QuartzBlock());
   public static final DeferredHolder<Block, Block> YELLOW_QUARTZ_PILLAR = REGISTRY.register("yellow_quartz_pillar", () -> new QuartzBlock());
   public static final DeferredHolder<Block, Block> YELLOW_QUARTZ_BLOCK = REGISTRY.register("yellow_quartz_block", () -> new QuartzBlock());
   public static final DeferredHolder<Block, Block> BROWN_QUARTZ_BLOCK = REGISTRY.register("brown_quartz_block", () -> new QuartzBlock());
   public static final DeferredHolder<Block, Block> BROWN_SMOOTH_QUARTZ = REGISTRY.register("brown_smooth_quartz", () -> new QuartzBlock());
   public static final DeferredHolder<Block, Block> BROWN_QUARTZ_BRICK = REGISTRY.register("brown_quartz_brick", () -> new QuartzBlock());
   public static final DeferredHolder<Block, Block> BROWN_CHISELED_QUARTZ_BLOCK = REGISTRY.register("brown_chiseled_quartz_block", () -> new QuartzBlock());
   public static final DeferredHolder<Block, Block> BROWN_QUARTZ_PILLAR = REGISTRY.register("brown_quartz_pillar", () -> new QuartzBlock());
   public static final DeferredHolder<Block, Block> GROUT = REGISTRY.register("grout", () -> new GroutBlock());
   public static final DeferredHolder<Block, Block> WHITE_PAINTED_WALL = REGISTRY.register("white_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> LIGHT_GRAY_PAINTED_WALL = REGISTRY.register("light_gray_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> GRAY_PAINTED_WALL = REGISTRY.register("gray_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> BLACK_PAINTED_WALL = REGISTRY.register("black_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> BROWN_PAINTED_WALL = REGISTRY.register("brown_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> RED_PAINTED_WALL = REGISTRY.register("red_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> ORANGE_PAINTED_WALL = REGISTRY.register("orange_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> YELLOW_PAINTED_WALL = REGISTRY.register("yellow_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> LIME_PAINTED_WALL = REGISTRY.register("lime_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> GREEN_PAINTED_WALL = REGISTRY.register("green_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> CYAN_PAINTED_WALL = REGISTRY.register("cyan_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> LIGHT_BLUE_PAINTED_WALL = REGISTRY.register("light_blue_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> BLUE_PAINTED_WALL = REGISTRY.register("blue_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> PURPLE_PAINTED_WALL = REGISTRY.register("purple_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> MAGENTA_PAINTED_WALL = REGISTRY.register("magenta_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> PINK_PAINTED_WALL = REGISTRY.register("pink_painted_wall", () -> new PaintedWallBlock());
   public static final DeferredHolder<Block, Block> OFFICE_CHAIR_WHITE = REGISTRY.register("office_chair_white", () -> new OfficeChair());
   public static final DeferredHolder<Block, Block> OFFICE_CHAIR_GRAY = REGISTRY.register("office_chair_gray", () -> new OfficeChair());
   public static final DeferredHolder<Block, Block> OFFICE_CHAIR_BLACK = REGISTRY.register("office_chair_black", () -> new OfficeChair());
   public static final DeferredHolder<Block, Block> DOWNLIGHT = REGISTRY.register("downlight", () -> new Downlight());
   public static final DeferredHolder<Block, Block> OLD_OAK_FLOOR_1 = REGISTRY.register("oak_floor_1", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_OAK_FLOOR_2 = REGISTRY.register("oak_floor_2", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_OAK_FLOOR_3 = REGISTRY.register("oak_floor_3", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_OAK_FLOOR_4 = REGISTRY.register("oak_floor_4", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_SPRUCE_FLOOR_1 = REGISTRY.register("spruce_floor_1", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_SPRUCE_FLOOR_2 = REGISTRY.register("spruce_floor_2", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_SPRUCE_FLOOR_3 = REGISTRY.register("spruce_floor_3", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_SPRUCE_FLOOR_4 = REGISTRY.register("spruce_floor_4", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_BIRCH_FLOOR_1 = REGISTRY.register("birch_floor_1", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_BIRCH_FLOOR_2 = REGISTRY.register("birch_floor_2", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_BIRCH_FLOOR_3 = REGISTRY.register("birch_floor_3", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_BIRCH_FLOOR_4 = REGISTRY.register("birch_floor_4", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_JUNGLE_FLOOR_1 = REGISTRY.register("jungle_floor_1", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_JUNGLE_FLOOR_2 = REGISTRY.register("jungle_floor_2", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_JUNGLE_FLOOR_3 = REGISTRY.register("jungle_floor_3", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_JUNGLE_FLOOR_4 = REGISTRY.register("jungle_floor_4", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_ACACIA_FLOOR_1 = REGISTRY.register("acacia_floor_1", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_ACACIA_FLOOR_2 = REGISTRY.register("acacia_floor_2", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_ACACIA_FLOOR_3 = REGISTRY.register("acacia_floor_3", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_ACACIA_FLOOR_4 = REGISTRY.register("acacia_floor_4", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_DARK_OAK_FLOOR_1 = REGISTRY.register("dark_oak_floor_1", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_DARK_OAK_FLOOR_2 = REGISTRY.register("dark_oak_floor_2", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_DARK_OAK_FLOOR_3 = REGISTRY.register("dark_oak_floor_3", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_DARK_OAK_FLOOR_4 = REGISTRY.register("dark_oak_floor_4", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_OAK_FLOOR_1 = REGISTRY.register("fishbone_oak_floor_1", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_OAK_FLOOR_2 = REGISTRY.register("fishbone_oak_floor_2", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_OAK_FLOOR_3 = REGISTRY.register("fishbone_oak_floor_3", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_OAK_FLOOR_4 = REGISTRY.register("fishbone_oak_floor_4", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_SPRUCE_FLOOR_1 = REGISTRY.register("fishbone_spruce_floor_1", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_SPRUCE_FLOOR_2 = REGISTRY.register("fishbone_spruce_floor_2", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_SPRUCE_FLOOR_3 = REGISTRY.register("fishbone_spruce_floor_3", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_SPRUCE_FLOOR_4 = REGISTRY.register("fishbone_spruce_floor_4", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_BIRCH_FLOOR_1 = REGISTRY.register("fishbone_birch_floor_1", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_BIRCH_FLOOR_2 = REGISTRY.register("fishbone_birch_floor_2", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_BIRCH_FLOOR_3 = REGISTRY.register("fishbone_birch_floor_3", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_BIRCH_FLOOR_4 = REGISTRY.register("fishbone_birch_floor_4", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_JUNGLE_FLOOR_1 = REGISTRY.register("fishbone_jungle_floor_1", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_JUNGLE_FLOOR_2 = REGISTRY.register("fishbone_jungle_floor_2", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_JUNGLE_FLOOR_3 = REGISTRY.register("fishbone_jungle_floor_3", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_JUNGLE_FLOOR_4 = REGISTRY.register("fishbone_jungle_floor_4", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_ACACIA_FLOOR_1 = REGISTRY.register("fishbone_acacia_floor_1", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_ACACIA_FLOOR_2 = REGISTRY.register("fishbone_acacia_floor_2", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_ACACIA_FLOOR_3 = REGISTRY.register("fishbone_acacia_floor_3", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_ACACIA_FLOOR_4 = REGISTRY.register("fishbone_acacia_floor_4", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_DARK_OAK_FLOOR_1 = REGISTRY.register("fishbone_dark_oak_floor_1", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_DARK_OAK_FLOOR_2 = REGISTRY.register("fishbone_dark_oak_floor_2", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_DARK_OAK_FLOOR_3 = REGISTRY.register("fishbone_dark_oak_floor_3", () -> new OldFloorBlock());
   public static final DeferredHolder<Block, Block> OLD_FISHBONE_DARK_OAK_FLOOR_4 = REGISTRY.register("fishbone_dark_oak_floor_4", () -> new OldFloorBlock());
}
