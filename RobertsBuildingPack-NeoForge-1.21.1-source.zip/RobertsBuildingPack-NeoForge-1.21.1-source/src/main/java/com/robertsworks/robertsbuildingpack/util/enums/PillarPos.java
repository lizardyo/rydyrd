package com.robertsworks.robertsbuildingpack.util.enums;

import net.minecraft.util.StringRepresentable;

public enum PillarPos implements StringRepresentable {
   CENTER("center"),
   TOP_LEFT("top_left"),
   TOP_RIGHT("top_right"),
   BOTTOM_LEFT("bottom_left"),
   BOTTOM_RIGHT("bottom_right");

   private final String name;

   private PillarPos(String name) {
      this.name = name;
   }

   @Override
   public String toString() {
      return this.name;
   }

   public String getSerializedName() {
      return this.name;
   }
}
