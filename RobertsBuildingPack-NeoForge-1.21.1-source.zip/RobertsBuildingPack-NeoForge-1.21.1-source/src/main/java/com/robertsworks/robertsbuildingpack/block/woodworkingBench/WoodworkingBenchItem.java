package com.robertsworks.robertsbuildingpack.block.woodworkingBench;

import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

public class WoodworkingBenchItem extends BlockItem {
   public WoodworkingBenchItem(Block block) {
      super(block, new Properties());
   }

   public void appendHoverText(ItemStack stack, net.minecraft.world.item.Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
      super.appendHoverText(stack, context, tooltip, flag);
      tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.simple_woodworking_bench_1").withStyle(ChatFormatting.GRAY));
      tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.simple_woodworking_bench_2").withStyle(ChatFormatting.GRAY));
      tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.simple_woodworking_bench_3").withStyle(ChatFormatting.GRAY));
      ItemContainerContents contents = stack.get(DataComponents.CONTAINER);
      if (contents != null) {
         int count = (int)contents.nonEmptyStream().count();
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.simple_woodworking_bench_4", new Object[]{count}).withStyle(ChatFormatting.AQUA));
      }
   }
}
