package com.robertsworks.robertsbuildingpack.block.floor;

import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

public class OldFloorBlockItem extends BlockItem {
   public OldFloorBlockItem(Block block) {
      super(block, new Properties());
   }

   public void appendHoverText(ItemStack stack, net.minecraft.world.item.Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
      tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.old_version_alert_1").withStyle(ChatFormatting.RED));
      tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.old_version_alert_2").withStyle(ChatFormatting.RED));
   }
}
