package com.robertsworks.robertsbuildingpack.block.base;

import com.robertsworks.robertsbuildingpack.util.properties.RBPProperties;
import java.util.Collections;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.Property;

public abstract class MultiTextureBlock extends Block {
   public MultiTextureBlock(Properties properties) {
      super(properties);
      this.registerDefaultState(
         (BlockState)((BlockState)((BlockState)this.stateDefinition.any()).setValue(RBPProperties.TEXTURE, 1)).setValue(RBPProperties.FACING, Direction.NORTH)
      );
   }

   public abstract int getTextureCount();

   public abstract int getPrevTexture(int var1);

   public abstract int getNextTexture(int var1);

   public abstract ItemStack getDropStack(BlockState var1);

   public int getTextureValue(BlockState state) {
      return (Integer)state.getValue(RBPProperties.TEXTURE);
   }

   public List<ItemStack> getDrops(BlockState state, net.minecraft.world.level.storage.loot.LootParams.Builder builder) {
      ItemStack stack = this.getDropStack(state);
      return Collections.singletonList(stack);
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      super.createBlockStateDefinition(builder);
      builder.add(new Property[]{RBPProperties.FACING, RBPProperties.TEXTURE});
   }

   public BlockState getStateForPlacement(BlockPlaceContext context) {
      BlockState state = this.defaultBlockState();
      BlockPos pos = context.getClickedPos();
      Direction facing = context.getHorizontalDirection();
      state = (BlockState)state.setValue(RBPProperties.FACING, facing);
      ItemStack stack = context.getItemInHand();
      if (stack.getItem() instanceof MultiTextureBlockItem cyclingBlockItem) {
         RandomSource randomSource = context.getLevel().getRandom();
         int textureValue = cyclingBlockItem.getTextureForPlacement(stack, pos, randomSource, facing);
         state = (BlockState)state.setValue(RBPProperties.TEXTURE, textureValue);
      }

      return state;
   }
}
