package com.robertsworks.robertsbuildingpack.item.tools;

import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.block.Block;

/**
 * Wraps a vanilla tier and scales its durability. In 1.21 the item durability is taken from the
 * tier by the tool base classes, so the mod's per-tool durability rate is applied here.
 */
public class ScaledTier implements Tier {
   private final Tier base;
   private final float durabilityRate;

   public ScaledTier(Tier base, float durabilityRate) {
      this.base = base;
      this.durabilityRate = durabilityRate;
   }

   @Override
   public int getUses() {
      return (int)((float)this.base.getUses() * this.durabilityRate);
   }

   @Override
   public float getSpeed() {
      return this.base.getSpeed();
   }

   @Override
   public float getAttackDamageBonus() {
      return this.base.getAttackDamageBonus();
   }

   @Override
   public TagKey<Block> getIncorrectBlocksForDrops() {
      return this.base.getIncorrectBlocksForDrops();
   }

   @Override
   public int getEnchantmentValue() {
      return this.base.getEnchantmentValue();
   }

   @Override
   public Ingredient getRepairIngredient() {
      return this.base.getRepairIngredient();
   }
}
