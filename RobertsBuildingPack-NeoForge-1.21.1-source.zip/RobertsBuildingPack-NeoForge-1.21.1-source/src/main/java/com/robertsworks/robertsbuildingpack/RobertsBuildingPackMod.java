package com.robertsworks.robertsbuildingpack;

import com.mojang.logging.LogUtils;
import com.robertsworks.robertsbuildingpack.block.disguise.blocks.IDisguiseBlock;
import com.robertsworks.robertsbuildingpack.block.furniture.AbstractChair;
import com.robertsworks.robertsbuildingpack.block.furniture.SeatEntity;
import com.robertsworks.robertsbuildingpack.block.disguise.DisguiseModelLoader;
import com.robertsworks.robertsbuildingpack.gui.WoodworkingBenchScreen;
import com.robertsworks.robertsbuildingpack.init.ItemPropertyRegister;
import com.robertsworks.robertsbuildingpack.init.ModBlockEntities;
import com.robertsworks.robertsbuildingpack.init.ModBlocks;
import com.robertsworks.robertsbuildingpack.init.ModDataComponents;
import com.robertsworks.robertsbuildingpack.init.ModEntities;
import com.robertsworks.robertsbuildingpack.init.ModItems;
import com.robertsworks.robertsbuildingpack.init.ModMenus;
import com.robertsworks.robertsbuildingpack.init.ModRecipeTypes;
import com.robertsworks.robertsbuildingpack.init.ModTabs;
import com.robertsworks.robertsbuildingpack.util.renderer.EmptyEntityRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.ModelEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent.RightClickBlock;
import net.neoforged.neoforge.event.level.BlockEvent.BreakEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import org.slf4j.Logger;

@Mod("roberts_building_pack")
public class RobertsBuildingPackMod {
   public static final String MODID = "roberts_building_pack";
   public static final Logger LOGGER = LogUtils.getLogger();

   public RobertsBuildingPackMod(IEventBus modEventBus, ModContainer modContainer) {
      modEventBus.addListener(this::commonSetup);
      modEventBus.addListener(this::registerCapabilities);
      NeoForge.EVENT_BUS.register(this);
      ModDataComponents.REGISTRY.register(modEventBus);
      ModBlocks.REGISTRY.register(modEventBus);
      ModBlockEntities.REGISTRY.register(modEventBus);
      ModEntities.ENTITIES.register(modEventBus);
      ModItems.REGISTRY.register(modEventBus);
      ModTabs.REGISTRY.register(modEventBus);
      ModMenus.REGISTRY.register(modEventBus);
      ModRecipeTypes.register(modEventBus);
   }

   private void commonSetup(FMLCommonSetupEvent event) {
      LOGGER.info("RobertsBuildingPack: commonSetup");
   }

   private void registerCapabilities(RegisterCapabilitiesEvent event) {
      event.registerBlockEntity(
         Capabilities.ItemHandler.BLOCK,
         ModBlockEntities.WOODWORKING_BENCH_BLOCK_ENTITY.get(),
         (blockEntity, side) -> blockEntity.getItemHandler()
      );
   }

   @SubscribeEvent
   public void onBlockBreak(BreakEvent event) {
      LevelAccessor level = event.getLevel();
      BlockPos pos = event.getPos();
      if (event.getState().getBlock() instanceof AbstractChair) {
         level.getEntitiesOfClass(SeatEntity.class, new AABB(pos)).forEach(Entity::discard);
      }
   }

   @SubscribeEvent
   public void onPlayerTick(PlayerTickEvent.Post event) {
      Player player = event.getEntity();
      if (player.isPassenger() && player.getVehicle() instanceof SeatEntity && player.isShiftKeyDown()) {
         player.stopRiding();
      }
   }

   @SubscribeEvent(priority = EventPriority.HIGHEST)
   public void onBlockRightClick(RightClickBlock event) {
      Level level = event.getLevel();
      BlockPos pos = event.getPos();
      Player player = event.getEntity();
      ItemStack stack = event.getItemStack();
      BlockState state = level.getBlockState(pos);
      if (state.getBlock() instanceof IDisguiseBlock disguiseBlock) {
         disguiseBlock.processBlockRightClick(event, state, level, pos, player, stack);
      }
   }

   @EventBusSubscriber(modid = "roberts_building_pack", bus = EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
   public static class ModEventBusEvents {
      @SubscribeEvent
      public static void onClientSetup(FMLClientSetupEvent event) {
         RobertsBuildingPackMod.LOGGER.info("RobertsBuildingPack: onClientSetup");
         event.enqueueWork(ItemPropertyRegister::register);
      }

      @SubscribeEvent
      public static void onRegisterScreens(RegisterMenuScreensEvent event) {
         event.register(ModMenus.WOODWORKING_BENCH.get(), WoodworkingBenchScreen::new);
      }

      @SubscribeEvent
      public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
         event.registerEntityRenderer(ModEntities.SEAT.get(), context -> new EmptyEntityRenderer<>(context));
      }

      @SubscribeEvent
      public static void onModelRegistry(ModelEvent.RegisterGeometryLoaders event) {
         event.register(ResourceLocation.fromNamespaceAndPath("roberts_building_pack", "disguise_model_loader"), new DisguiseModelLoader());
      }
   }
}
