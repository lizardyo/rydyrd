package com.robertsworks.robertsbuildingpack.block.furniture;

import com.robertsworks.robertsbuildingpack.util.properties.RBPProperties;
import java.util.Collections;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour.Properties;
import net.minecraft.world.level.block.state.StateDefinition.Builder;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public abstract class AbstractLamp extends Block implements SimpleWaterloggedBlock {
   public AbstractLamp() {
      super(
         Properties.of()
            .sound(SoundType.GLASS)
            .strength(0.5F, 6.0F)
            .lightLevel(state -> state.getValue(RBPProperties.LIT) ? 15 : 0)
            .noCollission()
            .isRedstoneConductor((bs, br, bp) -> false)
      );
      this.registerDefaultState(
         (BlockState)((BlockState)((BlockState)((BlockState)((BlockState)this.stateDefinition.any()).setValue(RBPProperties.FACING, Direction.NORTH))
                  .setValue(RBPProperties.FACE, AttachFace.WALL))
               .setValue(RBPProperties.LIT, false))
            .setValue(RBPProperties.WATERLOGGED, false)
      );
   }

   protected void createBlockStateDefinition(Builder<Block, BlockState> builder) {
      builder.add(new Property[]{RBPProperties.FACING, RBPProperties.FACE, RBPProperties.LIT, RBPProperties.WATERLOGGED});
   }

   public BlockState getStateForPlacement(BlockPlaceContext context) {
      BlockPos pos = context.getClickedPos();
      FluidState fluidstate = context.getLevel().getFluidState(pos);
      return context.getClickedFace().getAxis() == Axis.Y
         ? (BlockState)((BlockState)((BlockState)super.getStateForPlacement(context)
                  .setValue(RBPProperties.FACE, context.getClickedFace().getOpposite() == Direction.UP ? AttachFace.CEILING : AttachFace.FLOOR))
               .setValue(RBPProperties.FACING, context.getHorizontalDirection()))
            .setValue(RBPProperties.WATERLOGGED, fluidstate.getType() == Fluids.WATER)
         : (BlockState)((BlockState)((BlockState)super.getStateForPlacement(context).setValue(RBPProperties.FACE, AttachFace.WALL))
               .setValue(RBPProperties.FACING, context.getClickedFace()))
            .setValue(RBPProperties.WATERLOGGED, fluidstate.getType() == Fluids.WATER);
   }

   public List<ItemStack> getDrops(BlockState state, net.minecraft.world.level.storage.loot.LootParams.Builder builder) {
      return Collections.singletonList(new ItemStack(this));
   }

   public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
      return true;
   }

   public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
      return 0;
   }

   public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
      return Shapes.empty();
   }

   public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
      return this.getLampShape(state);
   }

   @Override
   protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
      if (!level.isClientSide) {
         boolean currentLit = state.getValue(RBPProperties.LIT);
         level.setBlock(pos, state.setValue(RBPProperties.LIT, !currentLit), 3);
         return InteractionResult.SUCCESS;
      } else {
         return InteractionResult.PASS;
      }
   }

   public abstract VoxelShape getLampShape(BlockState var1);

   public FluidState getFluidState(BlockState state) {
      return state.getValue(RBPProperties.WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
   }

   public BlockState updateShape(BlockState state, Direction direction, BlockState neighborState, LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
      if ((Boolean)state.getValue(RBPProperties.WATERLOGGED)) {
         level.scheduleTick(pos, Fluids.WATER, Fluids.WATER.getTickDelay(level));
      }

      return super.updateShape(state, direction, neighborState, level, pos, neighborPos);
   }
}
