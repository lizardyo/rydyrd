package com.robertsworks.robertsbuildingpack.util.enums;

import net.minecraft.util.StringRepresentable;

public enum HorizontalSlabSide implements StringRepresentable {
   BOTTOM("bottom"),
   TOP("top");

   private final String name;

   private HorizontalSlabSide(String name) {
      this.name = name;
   }

   @Override
   public String toString() {
      return this.name;
   }

   public String getSerializedName() {
      return this.name;
   }
}
