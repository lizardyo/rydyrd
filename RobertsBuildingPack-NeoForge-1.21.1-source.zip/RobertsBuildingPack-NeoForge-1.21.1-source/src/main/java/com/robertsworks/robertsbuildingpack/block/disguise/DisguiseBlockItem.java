package com.robertsworks.robertsbuildingpack.block.disguise;

import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

public class DisguiseBlockItem extends BlockItem {
   public DisguiseBlockItem(Block block) {
      super(block, new Properties());
   }

   public void appendHoverText(ItemStack stack, net.minecraft.world.item.Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
      super.appendHoverText(stack, context, tooltip, flag);
      if (!RBPHelper.isShiftKeyDown()) {
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.disguise_block_desc").withStyle(ChatFormatting.GRAY));
         tooltip.add(Component.literal(" "));
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.show_more_info").withStyle(ChatFormatting.GRAY));
      } else {
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.interaction_methods").withStyle(ChatFormatting.GRAY));
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.disguise_block_interaction_1").withStyle(ChatFormatting.WHITE));
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.disguise_block_interaction_2").withStyle(ChatFormatting.WHITE));
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.disguise_block_interaction_3").withStyle(ChatFormatting.WHITE));
         tooltip.add(Component.translatable("tooltip.roberts_building_pack.item.disguise_block_interaction_4").withStyle(ChatFormatting.WHITE));
         tooltip.add(Component.literal(" "));
      }
   }
}
