package com.robertsworks.robertsbuildingpack.init;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public class ModTabs {
   public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, "roberts_building_pack");
   public static final DeferredHolder<CreativeModeTab, CreativeModeTab> BUILDING_MATERIALS = REGISTRY.register(
      "rbp_building_materials",
      () -> CreativeModeTab.builder()
            .title(Component.translatable("item_group.roberts_building_pack.building_materials"))
            .icon(() -> new ItemStack((ItemLike)ModBlocks.TILE_B_006.get()))
            .displayItems((parameters, tabData) -> {
               tabData.accept(((Block)ModBlocks.WHITE_BRICK_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.RED_BRICK_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.YELLOW_BRICK_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.CYAN_BRICK_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.BROWN_BRICK_WALL.get()).asItem());
               tabData.accept(((Item)ModItems.COMMON_OAK_FLOOR.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.COMMON_SPRUCE_FLOOR.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.COMMON_BIRCH_FLOOR.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.COMMON_JUNGLE_FLOOR.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.COMMON_ACACIA_FLOOR.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.COMMON_DARK_OAK_FLOOR.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.FISHBONE_OAK_FLOOR.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.FISHBONE_SPRUCE_FLOOR.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.FISHBONE_BIRCH_FLOOR.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.FISHBONE_JUNGLE_FLOOR.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.FISHBONE_ACACIA_FLOOR.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.FISHBONE_DARK_OAK_FLOOR.get()).getDefaultInstance());
               tabData.accept(((Block)ModBlocks.BASE_TILE.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_A_001.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_A_002.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_A_003.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_A_004.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_A_005.get()).asItem());
               tabData.accept(((Item)ModItems.TILE_A_006.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.TILE_A_007.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.TILE_A_008.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.TILE_A_009.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.TILE_A_010.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.TILE_A_011.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.TILE_A_012.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.TILE_A_013.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.TILE_A_014.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.TILE_A_015.get()).getDefaultInstance());
               tabData.accept(((Block)ModBlocks.TILE_B_001.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_B_002.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_B_003.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_B_004.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_B_005.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_B_006.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_B_007.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_B_008.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_B_009.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_B_010.get()).asItem());
               tabData.accept(((Item)ModItems.TILE_B_011.get()).getDefaultInstance());
               tabData.accept(((Item)ModItems.TILE_B_012.get()).getDefaultInstance());
               tabData.accept(((Block)ModBlocks.TILE_B_013.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_B_014.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_B_015.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_C_001.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_C_002.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_C_003.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_C_004.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_D_001.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_D_002.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_D_003.get()).asItem());
               tabData.accept(((Block)ModBlocks.TILE_D_004.get()).asItem());
               tabData.accept(((Block)ModBlocks.YELLOW_QUARTZ_BLOCK.get()).asItem());
               tabData.accept(((Block)ModBlocks.YELLOW_SMOOTH_QUARTZ.get()).asItem());
               tabData.accept(((Block)ModBlocks.YELLOW_QUARTZ_BRICK.get()).asItem());
               tabData.accept(((Block)ModBlocks.YELLOW_CHISELED_QUARTZ_BLOCK.get()).asItem());
               tabData.accept(((Block)ModBlocks.YELLOW_QUARTZ_PILLAR.get()).asItem());
               tabData.accept(((Block)ModBlocks.BROWN_QUARTZ_BLOCK.get()).asItem());
               tabData.accept(((Block)ModBlocks.BROWN_SMOOTH_QUARTZ.get()).asItem());
               tabData.accept(((Block)ModBlocks.BROWN_QUARTZ_BRICK.get()).asItem());
               tabData.accept(((Block)ModBlocks.BROWN_CHISELED_QUARTZ_BLOCK.get()).asItem());
               tabData.accept(((Block)ModBlocks.BROWN_QUARTZ_PILLAR.get()).asItem());
               tabData.accept(((Block)ModBlocks.GROUT.get()).asItem());
               tabData.accept(((Block)ModBlocks.WHITE_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.LIGHT_GRAY_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.GRAY_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.BLACK_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.BROWN_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.RED_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.ORANGE_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.YELLOW_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.LIME_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.GREEN_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.CYAN_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.LIGHT_BLUE_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.BLUE_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.PURPLE_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.MAGENTA_PAINTED_WALL.get()).asItem());
               tabData.accept(((Block)ModBlocks.PINK_PAINTED_WALL.get()).asItem());
            })
            .build()
   );
   public static final DeferredHolder<CreativeModeTab, CreativeModeTab> FURNITURE = REGISTRY.register(
      "rbp_furniture",
      () -> CreativeModeTab.builder()
            .title(Component.translatable("item_group.roberts_building_pack.furniture"))
            .icon(() -> new ItemStack((ItemLike)ModBlocks.OFFICE_CHAIR_WHITE.get()))
            .displayItems((parameters, tabData) -> {
               tabData.accept(((Block)ModBlocks.OFFICE_CHAIR_WHITE.get()).asItem());
               tabData.accept(((Block)ModBlocks.OFFICE_CHAIR_GRAY.get()).asItem());
               tabData.accept(((Block)ModBlocks.OFFICE_CHAIR_BLACK.get()).asItem());
               tabData.accept(((Block)ModBlocks.DOWNLIGHT.get()).asItem());
            })
            .build()
   );
   public static final DeferredHolder<CreativeModeTab, CreativeModeTab> DISGUISE_BLOCKS = REGISTRY.register(
      "rbp_disguise_blocks",
      () -> CreativeModeTab.builder()
            .title(Component.translatable("item_group.roberts_building_pack.disguise_blocks"))
            .icon(() -> new ItemStack((ItemLike)ModBlocks.DISGUISE_BLOCK.get()))
            .displayItems((parameters, tabData) -> {
               tabData.accept((ItemLike)ModBlocks.DISGUISE_BLOCK.get());
               tabData.accept((ItemLike)ModBlocks.DISGUISE_STAIR.get());
               tabData.accept((ItemLike)ModBlocks.DISGUISE_HORIZONTAL_HALF_SLAB.get());
               tabData.accept((ItemLike)ModBlocks.DISGUISE_HORIZONTAL_QUARTER_SLAB.get());
               tabData.accept((ItemLike)ModBlocks.DISGUISE_HORIZONTAL_ONE_EIGHTH_SLAB.get());
               tabData.accept((ItemLike)ModBlocks.DISGUISE_HORIZONTAL_ONE_SIXTEENTH_SLAB.get());
               tabData.accept((ItemLike)ModBlocks.DISGUISE_VERTICAL_HALF_SLAB.get());
               tabData.accept((ItemLike)ModBlocks.DISGUISE_VERTICAL_QUARTER_SLAB.get());
               tabData.accept((ItemLike)ModBlocks.DISGUISE_VERTICAL_ONE_EIGHTH_SLAB.get());
               tabData.accept((ItemLike)ModBlocks.DISGUISE_VERTICAL_ONE_SIXTEENTH_SLAB.get());
               tabData.accept((ItemLike)ModBlocks.DISGUISE_PILLAR_12_12_16.get());
               tabData.accept((ItemLike)ModBlocks.DISGUISE_PILLAR_8_8_16.get());
               tabData.accept((ItemLike)ModBlocks.DISGUISE_PILLAR_4_4_16.get());
               tabData.accept((ItemLike)ModBlocks.DISGUISE_PILLAR_2_2_16.get());
            })
            .build()
   );
   public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TOOLS = REGISTRY.register(
      "rbp_ingredients_and_tools",
      () -> CreativeModeTab.builder()
            .title(Component.translatable("item_group.roberts_building_pack.ingredients_and_tools"))
            .icon(() -> new ItemStack((ItemLike)ModItems.IRON_CHISEL.get()))
            .displayItems((parameters, tabData) -> {
               tabData.accept((ItemLike)ModItems.SCREW.get());
               tabData.accept((ItemLike)ModItems.WHITE_BRICK.get());
               tabData.accept((ItemLike)ModItems.RED_BRICK.get());
               tabData.accept((ItemLike)ModItems.YELLOW_BRICK.get());
               tabData.accept((ItemLike)ModItems.CYAN_BRICK.get());
               tabData.accept((ItemLike)ModItems.BROWN_BRICK.get());
               tabData.accept((ItemLike)ModItems.YELLOW_QUARTZ.get());
               tabData.accept((ItemLike)ModItems.BROWN_QUARTZ.get());
               tabData.accept((ItemLike)ModItems.SIMPLE_WOODWORKING_BENCH.get());
               tabData.accept((ItemLike)ModItems.IRON_SAW_BLADE.get());
               tabData.accept((ItemLike)ModItems.IRON_CHISEL_BLADE.get());
               tabData.accept((ItemLike)ModItems.IRON_HAMMER_TOP.get());
               tabData.accept((ItemLike)ModItems.IRON_SCREWDRIVER_HEAD.get());
               tabData.accept((ItemLike)ModItems.IRON_SAW.get());
               tabData.accept((ItemLike)ModItems.IRON_CHISEL.get());
               tabData.accept((ItemLike)ModItems.IRON_HAMMER.get());
               tabData.accept((ItemLike)ModItems.IRON_SCREWDRIVER.get());
               tabData.accept((ItemLike)ModItems.GOLDEN_SAW_BLADE.get());
               tabData.accept((ItemLike)ModItems.GOLDEN_CHISEL_BLADE.get());
               tabData.accept((ItemLike)ModItems.GOLDEN_HAMMER_TOP.get());
               tabData.accept((ItemLike)ModItems.GOLDEN_SCREWDRIVER_HEAD.get());
               tabData.accept((ItemLike)ModItems.GOLDEN_SAW.get());
               tabData.accept((ItemLike)ModItems.GOLDEN_CHISEL.get());
               tabData.accept((ItemLike)ModItems.GOLDEN_HAMMER.get());
               tabData.accept((ItemLike)ModItems.GOLDEN_SCREWDRIVER.get());
               tabData.accept((ItemLike)ModItems.DIAMOND_SAW_BLADE.get());
               tabData.accept((ItemLike)ModItems.DIAMOND_CHISEL_BLADE.get());
               tabData.accept((ItemLike)ModItems.DIAMOND_HAMMER_TOP.get());
               tabData.accept((ItemLike)ModItems.DIAMOND_SCREWDRIVER_HEAD.get());
               tabData.accept((ItemLike)ModItems.DIAMOND_SAW.get());
               tabData.accept((ItemLike)ModItems.DIAMOND_CHISEL.get());
               tabData.accept((ItemLike)ModItems.DIAMOND_HAMMER.get());
               tabData.accept((ItemLike)ModItems.DIAMOND_SCREWDRIVER.get());
               tabData.accept((ItemLike)ModItems.NETHERITE_SAW.get());
               tabData.accept((ItemLike)ModItems.NETHERITE_CHISEL.get());
               tabData.accept((ItemLike)ModItems.NETHERITE_HAMMER.get());
               tabData.accept((ItemLike)ModItems.NETHERITE_SCREWDRIVER.get());
            })
            .build()
   );
}
