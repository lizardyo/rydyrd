package com.robertsworks.robertsbuildingpack.init;

import com.robertsworks.robertsbuildingpack.recipe.WoodworkingBenchRecipe;
import com.robertsworks.robertsbuildingpack.recipe.WoodworkingBenchRecipeSerializer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModRecipeTypes {
   public static final DeferredRegister<RecipeType<?>> RECIPE_TYPES = DeferredRegister.create(BuiltInRegistries.RECIPE_TYPE, "roberts_building_pack");
   public static final DeferredRegister<RecipeSerializer<?>> RECIPE_SERIALIZERS = DeferredRegister.create(
      BuiltInRegistries.RECIPE_SERIALIZER, "roberts_building_pack"
   );

   public static final DeferredHolder<RecipeType<?>, RecipeType<WoodworkingBenchRecipe>> WOODWORKING_BENCH = RECIPE_TYPES.register(
      "woodworking_bench", () -> new RecipeType<WoodworkingBenchRecipe>() {
            @Override
            public String toString() {
               return "roberts_building_pack:woodworking_bench";
            }
         }
   );

   public static final DeferredHolder<RecipeSerializer<?>, RecipeSerializer<WoodworkingBenchRecipe>> WOODWORKING_BENCH_SERIALIZER = RECIPE_SERIALIZERS.register(
      "woodworking_bench", () -> new WoodworkingBenchRecipeSerializer()
   );

   public static void register(IEventBus eventBus) {
      RECIPE_TYPES.register(eventBus);
      RECIPE_SERIALIZERS.register(eventBus);
   }
}
