package com.robertsworks.robertsbuildingpack.block.disguise.bakedModels;

import com.robertsworks.robertsbuildingpack.block.disguise.DisguiseBlockEntity;
import com.robertsworks.robertsbuildingpack.util.RBPHelper;
import com.robertsworks.robertsbuildingpack.util.other.BlockOffset;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.client.model.data.ModelData;
import net.minecraft.core.registries.BuiltInRegistries;

public class BakedDisguiseCubeModel extends AbstractBakedDisguiseBlockModel {
   public String shape = null;
   public Block normalBlock = null;
   public BlockColors blockColors;

   public BakedDisguiseCubeModel() {
      this.shape = "disguise_block";
      ResourceLocation blockId = ResourceLocation.fromNamespaceAndPath("roberts_building_pack", this.shape + "_normal");
      this.normalBlock = (Block)BuiltInRegistries.BLOCK.get(blockId);
      this.blockColors = Minecraft.getInstance().getBlockColors();
   }

   @Override
   public List<BakedQuad> onGetQuads(BlockState state, Direction side, RandomSource rand, ModelData data, RenderType renderType) {
      Level level = (Level)data.get(DisguiseBlockEntity.LEVEL);
      BlockPos pos = (BlockPos)data.get(DisguiseBlockEntity.POSITION);
      BlockOffset offset = (BlockOffset)data.get(DisguiseBlockEntity.OFFSET);
      BlockState disguiseState = (BlockState)data.get(DisguiseBlockEntity.DISGUISE_STATE);
      if (DisguiseBlockEntity.isDisguised(disguiseState)) {
         BlockState finalDisguiseState = RBPHelper.copyProperties(state, disguiseState);
         RenderType targetRenderType = ItemBlockRenderTypes.getChunkRenderType(disguiseState);
         List<BakedQuad> quads = this.getModelQuads(disguiseState, side, rand, data, targetRenderType);
         return RBPHelper.processQuads(quads, quadInfo -> {
            if (quadInfo.tintIndex != -1) {
               int color = this.blockColors.getColor(finalDisguiseState, level, pos, quadInfo.tintIndex);
               quadInfo.setColor(color);
            }

            quadInfo.offset(offset);
         });
      } else {
         BlockState normalState = RBPHelper.copyProperties(state, this.normalBlock.defaultBlockState());
         List<BakedQuad> normalQuads = this.getModelQuads(normalState, side, rand, data, RenderType.cutout());
         return RBPHelper.processQuads(normalQuads, quadInfo -> quadInfo.offset(offset));
      }
   }
}
