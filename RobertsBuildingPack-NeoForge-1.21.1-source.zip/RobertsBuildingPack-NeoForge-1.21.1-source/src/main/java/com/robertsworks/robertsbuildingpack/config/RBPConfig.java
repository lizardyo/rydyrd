package com.robertsworks.robertsbuildingpack.config;

/** Placeholder kept from the original mod (it had no config options). */
public class RBPConfig {
}
