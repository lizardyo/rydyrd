package com.robertsworks.robertsbuildingpack.util.other;

import java.util.function.Consumer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;

public class CustomInputContainer extends SimpleContainer {
   private Consumer<Container> onChanged = null;

   public CustomInputContainer() {
      super(1);
   }

   public CustomInputContainer(Consumer<Container> onChanged) {
      super(1);
      this.onChanged = onChanged;
   }

   public void setOnChanged(Consumer<Container> onChanged) {
      this.onChanged = onChanged;
   }

   public void setChanged() {
      super.setChanged();
      if (this.onChanged != null) {
         this.onChanged.accept(this);
      }
   }
}
