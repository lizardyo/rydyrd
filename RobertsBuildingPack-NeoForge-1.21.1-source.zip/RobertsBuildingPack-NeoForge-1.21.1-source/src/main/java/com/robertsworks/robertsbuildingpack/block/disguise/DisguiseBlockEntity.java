package com.robertsworks.robertsbuildingpack.block.disguise;

import com.robertsworks.robertsbuildingpack.init.ModBlockEntities;
import com.robertsworks.robertsbuildingpack.util.other.BlockOffset;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.client.model.data.ModelData;
import net.neoforged.neoforge.client.model.data.ModelProperty;

public class DisguiseBlockEntity extends BlockEntity {
   public static final ModelProperty<Level> LEVEL = new ModelProperty<>();
   public static final ModelProperty<BlockPos> POSITION = new ModelProperty<>();
   public static final ModelProperty<BlockState> DISGUISE_STATE = new ModelProperty<>();
   public static final ModelProperty<BlockOffset> OFFSET = new ModelProperty<>();
   public static BlockState DEFAULT_DISGUISE = Blocks.AIR.defaultBlockState();
   private BlockState disguiseState = DEFAULT_DISGUISE;
   public BlockOffset offset = new BlockOffset();

   public DisguiseBlockEntity(BlockPos pos, BlockState state) {
      super(ModBlockEntities.DISGUISE_BLOCK_ENTITY.get(), pos, state);
   }

   public void doUpdate() {
      this.setChanged();
      if (this.level != null) {
         if (!this.level.isClientSide) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 3);
         }
         this.requestModelDataUpdate();
      }
   }

   public void setDisguiseState(BlockState state) {
      this.disguiseState = state == null ? DEFAULT_DISGUISE : state;
   }

   public BlockState getDisguiseState() {
      return this.disguiseState;
   }

   public boolean hasDisguiseState() {
      return isDisguised(this.disguiseState);
   }

   public static boolean isDisguised(BlockState blockState) {
      return blockState != null && !blockState.isAir();
   }

   @Override
   public ModelData getModelData() {
      return ModelData.builder()
         .with(LEVEL, this.level)
         .with(POSITION, this.worldPosition)
         .with(DISGUISE_STATE, this.disguiseState)
         .with(OFFSET, this.offset)
         .build();
   }

   @Override
   protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
      super.saveAdditional(tag, registries);
      tag.putString("TargetBlock", BuiltInRegistries.BLOCK.getKey(this.disguiseState.getBlock()).toString());
      tag.putInt("Offset_X", this.offset.getX());
      tag.putInt("Offset_Y", this.offset.getY());
      tag.putInt("Offset_Z", this.offset.getZ());
   }

   @Override
   protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
      super.loadAdditional(tag, registries);
      if (tag.contains("TargetBlock")) {
         try {
            String v = tag.getString("TargetBlock");
            ResourceLocation id = ResourceLocation.parse(v);
            Block block = BuiltInRegistries.BLOCK.get(id);
            this.disguiseState = block.defaultBlockState();
         } catch (Exception var4) {
            this.disguiseState = DEFAULT_DISGUISE;
         }
      }
      if (tag.contains("Offset_X")) {
         this.offset.setX(tag.getInt("Offset_X"));
      }
      if (tag.contains("Offset_Y")) {
         this.offset.setY(tag.getInt("Offset_Y"));
      }
      if (tag.contains("Offset_Z")) {
         this.offset.setZ(tag.getInt("Offset_Z"));
      }
   }

   @Override
   public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
      return this.saveWithoutMetadata(registries);
   }

   @Override
   public Packet<ClientGamePacketListener> getUpdatePacket() {
      return ClientboundBlockEntityDataPacket.create(this);
   }

   @Override
   public void onDataPacket(Connection net, ClientboundBlockEntityDataPacket pkt, HolderLookup.Provider lookupProvider) {
      super.onDataPacket(net, pkt, lookupProvider);
      if (this.level != null && this.level.isClientSide) {
         this.requestModelDataUpdate();
         this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 3);
      }
   }

   @Override
   public void handleUpdateTag(CompoundTag tag, HolderLookup.Provider lookupProvider) {
      super.handleUpdateTag(tag, lookupProvider);
      if (this.level != null && this.level.isClientSide) {
         this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 3);
      }
   }
}
