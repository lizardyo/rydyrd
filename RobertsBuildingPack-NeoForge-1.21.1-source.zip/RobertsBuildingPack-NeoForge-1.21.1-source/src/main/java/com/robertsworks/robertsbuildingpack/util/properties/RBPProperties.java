package com.robertsworks.robertsbuildingpack.util.properties;

import com.robertsworks.robertsbuildingpack.util.enums.DeskPart;
import com.robertsworks.robertsbuildingpack.util.enums.HorizontalSlabSide;
import com.robertsworks.robertsbuildingpack.util.enums.PillarPos;
import com.robertsworks.robertsbuildingpack.util.enums.VerticalSlabSide;
import net.minecraft.core.Direction.Plane;
import net.minecraft.world.level.block.FaceAttachedHorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

public class RBPProperties {
   public static final DirectionProperty FACING = DirectionProperty.create("facing", Plane.HORIZONTAL);
   public static final EnumProperty<AttachFace> FACE = FaceAttachedHorizontalDirectionalBlock.FACE;
   public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;
   public static final EnumProperty<HorizontalSlabSide> HORIZONTAL_SLAB_SIDE = EnumProperty.create("side", HorizontalSlabSide.class);
   public static final EnumProperty<VerticalSlabSide> VERTICAL_SLAB_SIDE = EnumProperty.create("side", VerticalSlabSide.class);
   public static final EnumProperty<PillarPos> PILLAR_POS = EnumProperty.create("pillar_pos", PillarPos.class);
   public static final BooleanProperty DISGUISED = BooleanProperty.create("disguised");
   public static final BooleanProperty MOVED = BooleanProperty.create("moved");
   public static final IntegerProperty TEXTURE = IntegerProperty.create("texture", 1, 99);
   public static final EnumProperty<DeskPart> DESKPART = EnumProperty.create("part", DeskPart.class);
   public static final BooleanProperty LIT = BooleanProperty.create("lit");
}
