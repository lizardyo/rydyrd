package com.robertsworks.robertsbuildingpack.recipe;

import com.robertsworks.robertsbuildingpack.init.ModRecipeTypes;
import com.robertsworks.robertsbuildingpack.util.other.IngredientWithCount;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeInput;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;

public class WoodworkingBenchRecipe implements Recipe<RecipeInput> {
   private final ItemStack result;
   private final List<IngredientWithCount> ingredients;
   private final int sortIndex;

   public WoodworkingBenchRecipe(ItemStack result, List<IngredientWithCount> ingredients, int sortIndex) {
      this.result = result;
      this.ingredients = ingredients;
      this.sortIndex = sortIndex;
   }

   @Override
   public boolean matches(RecipeInput input, Level level) {
      List<ItemStack> availableItems = new ArrayList<>();
      for (int i = 0; i < input.size(); i++) {
         availableItems.add(input.getItem(i));
      }
      for (IngredientWithCount required : this.ingredients) {
         int remaining = required.count();
         for (ItemStack available : availableItems) {
            if (required.ingredient().test(available)) {
               int use = Math.min(available.getCount(), remaining);
               remaining -= use;
               if (remaining <= 0) {
                  break;
               }
            }
         }
         if (remaining > 0) {
            return false;
         }
      }
      return true;
   }

   public ItemStack assemble() {
      return this.result.copy();
   }

   @Override
   public ItemStack assemble(RecipeInput input, HolderLookup.Provider registries) {
      return this.result.copy();
   }

   @Override
   public boolean canCraftInDimensions(int width, int height) {
      return true;
   }

   public ItemStack getResult() {
      return this.result;
   }

   @Override
   public ItemStack getResultItem(HolderLookup.Provider registries) {
      return this.result;
   }

   @Override
   public RecipeSerializer<?> getSerializer() {
      return ModRecipeTypes.WOODWORKING_BENCH_SERIALIZER.get();
   }

   @Override
   public RecipeType<?> getType() {
      return ModRecipeTypes.WOODWORKING_BENCH.get();
   }

   @Override
   public NonNullList<Ingredient> getIngredients() {
      NonNullList<Ingredient> list = NonNullList.create();
      for (IngredientWithCount ing : this.ingredients) {
         list.add(ing.ingredient());
      }
      return list;
   }

   public List<IngredientWithCount> getIngredientWithCounts() {
      return this.ingredients;
   }

   public int getSortIndex() {
      return this.sortIndex;
   }
}
