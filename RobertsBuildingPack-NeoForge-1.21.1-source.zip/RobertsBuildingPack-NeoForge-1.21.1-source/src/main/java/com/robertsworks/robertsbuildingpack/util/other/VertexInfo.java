package com.robertsworks.robertsbuildingpack.util.other;

public class VertexInfo {
   public float x = 0.0F;
   public float y = 0.0F;
   public float z = 0.0F;
   public int color_r = 0;
   public int color_g = 0;
   public int color_b = 0;
   public int color_a = 0;
   public float u = 0.0F;
   public float v = 0.0F;
   public int blockLight = 0;
   public int skyLight = 0;
   public int normal = 0;

   public void loadFromInt8(int int1, int int2, int int3, int int4, int int5, int int6, int int7, int int8) {
      this.x = Float.intBitsToFloat(int1);
      this.y = Float.intBitsToFloat(int2);
      this.z = Float.intBitsToFloat(int3);
      this.color_a = int4 >> 24 & 0xFF;
      this.color_b = int4 >> 16 & 0xFF;
      this.color_g = int4 >> 8 & 0xFF;
      this.color_r = int4 & 0xFF;
      this.u = Float.intBitsToFloat(int5);
      this.v = Float.intBitsToFloat(int6);
      this.blockLight = int7 & 65535;
      this.skyLight = int7 >> 16 & 65535;
      this.normal = int8;
   }

   public int[] makeToInt8() {
      return new int[]{
         Float.floatToRawIntBits(this.x),
         Float.floatToRawIntBits(this.y),
         Float.floatToRawIntBits(this.z),
         this.color_a << 24 | this.color_b << 16 | this.color_g << 8 | this.color_r,
         Float.floatToRawIntBits(this.u),
         Float.floatToRawIntBits(this.v),
         this.skyLight << 16 | this.blockLight,
         this.normal
      };
   }

   public void offset(float offsetX, float offsetY, float offsetZ) {
      this.x += offsetX;
      this.y += offsetY;
      this.z += offsetZ;
   }

   public static VertexInfo fromInt8(int int1, int int2, int int3, int int4, int int5, int int6, int int7, int int8) {
      VertexInfo vertex = new VertexInfo();
      vertex.loadFromInt8(int1, int2, int3, int4, int5, int6, int7, int8);
      return vertex;
   }
}
