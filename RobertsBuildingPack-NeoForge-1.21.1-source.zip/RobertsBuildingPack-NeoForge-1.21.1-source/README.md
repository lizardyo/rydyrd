# Robert's Building Pack – NeoForge 1.21.1 personal port

Credits: **Robert's Building Pack** and all original code, models and textures belong to the
**Robert's Building Pack team** (original mod: https://www.curseforge.com/minecraft/mc-mods/roberts-building-pack).
This is an unofficial port of version 0.7.2 (Forge 1.20.1) to NeoForge 1.21.1, made with the team's
permission **for personal use only**. If it is ever released publicly, credit the team on the mod page.
Please keep the source private and do not redistribute it.

## Build
Needs JDK 21 and internet access:

    ./gradlew build

The jar is written to `build/libs/`. Install it in a NeoForge 1.21.1 instance (no other mods required).
See PORTING_NOTES.md for what changed and what is untested.
