# Porting notes (Forge 1.20.1 -> NeoForge 1.21.1)

STATUS: this port was written by hand from the decompiled 1.20.1 jar. It could NOT be compiled or
run where it was written (no access to Minecraft/NeoForge libraries), so the first build may show
compile errors that need small fixes. Nothing here has been tested in-game yet.

## What was changed
* Build: ModDevGradle (NeoForge 21.1.21), Java 21. `META-INF/neoforge.mods.toml` replaces `mods.toml`.
* Registries: Forge `RegistryObject/ForgeRegistries` -> NeoForge `DeferredHolder/BuiltInRegistries`.
* Item NBT -> data components: the texture "placement_mode" is now a data component
  (`roberts_building_pack:placement_mode`); items stored in a workbench item use the vanilla `container` component.
  Old items from 1.20.1 worlds will just start in "auto" placement mode.
* Block entities: `load/saveAdditional/getUpdateTag/onDataPacket` now take the registry provider. The saved
  keys (TargetBlock, Offset_X/Y/Z, ...) are unchanged. The block-entity registry namespace is still
  `yourmodid` (a quirk of the original mod) so ids stay identical to 1.20.1.
* Blocks: `use()` -> `useWithoutItem()`, `playerWillDestroy` returns the state, `codec()` added to
  `HorizontalDirectionalBlock` subclasses, `Properties.copy` -> `ofFullCopy`, `getCloneItemStack(LevelReader,...)`.
* Workbench recipe type: new Codec/StreamCodec serializer. Recipe JSON format changed to
  `{"ingredients":[{"ingredient":{...},"count":n}], "result":{"id":...,"count":n}}`.
* All vanilla recipes/advancements/tags were moved to the 1.21 folder names (`recipe`, `advancement`, `tags/block`)
  and result formats were converted.
* Disguise model loader/baked models: NeoForge `IGeometryLoader/IUnbakedGeometry` API.
* Tools: the hard-coded enchantment whitelists became item tags in `data/minecraft/tags/item/enchantable/`
  (Unbreaking+Mending, Sharpness on saws/chisels, Silk Touch on all four tool types). Tool durability is
  preserved through a scaled tier. Vanilla may now also allow Fortune on these tools.
* Registered via events: capability for the workbench inventory (hoppers), menu screen, entity renderer, model loader.

## Left out
* JEI plugin (recipe category for the workbench) - not ported.
* Data generators and the unused "migration action" helper classes - not needed at runtime
  (the generated JSON is already included).

## Uncertain points (check in game)
* A few vanilla constants had to be identified from context because the original jar is obfuscated:
  the click sound used when applying/adjusting disguises (set to `COMPARATOR_CLICK`), chair sound type
  (`STONE`), lamp sound type (`GLASS`), and the enchantment set per tool. These are cosmetic.
